<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\MaildispositionModel;
use App\Models\MailModel;
use App\Models\MailreceiverModel;
use App\Models\PositionModel;
use Config\Services;
use setasign\Fpdi\Fpdi;

class Disposition extends BaseController
{
	protected $mailModel, $mailreceiverModel, $maildispositionModel, $positionModel;
	protected $url          = 'admin/disposition';
	protected $allowedRoles = [2, 3];

	public function __construct()
	{
		$this->mailModel            = new MailModel();
		$this->mailreceiverModel    = new MailreceiverModel();
		$this->maildispositionModel = new MaildispositionModel();
		$this->positionModel        = new PositionModel();

		if (!in_array(session('user_role'), $this->allowedRoles)) {
			echo view('templates/layouts/access_denied', [
				'title' => 'Access Denied'
			]);
			exit;
		}
	}

	/**
	 * Regenerate page title by category
	 * 
	 * @param 	string	$category
	 * @return	string	$title
	 */

	public function regenerateTitle($category)
	{
		if ($category == 'out') {
			$title = 'Surat Keluar SKPD';
		} elseif ($category == 'out_nonskpd') {
			$title = 'Surat Keluar Non-SKPD';
		} elseif ($category == 'in') {
			$title = 'Surat Masuk SKPD';
		} elseif ($category == 'in_nonskpd') {
			$title = 'Surat Masuk Non-SKPD';
		}

		return $title;
	}

	/**
	 * Check disposition action
	 * For mail with category :: out & out_nonskpd
	 * 
	 * @param	string 	$mail_id
	 * @param	int 	$leader
	 * @param	int		$skpd
	 * 
	 * @return string $stateButton (forward,forward_to_staff, tte)
	 * @return string $btnName
	 */

	public function checkDispositionAction($mail_id, $leader, $skpd)
	{
		$sign    = $this->mailModel->where('id', $mail_id)->find();
		$btnName = [
			'forward'          => 'Teruskan ke Pimpinan',
			'forward_to_staff' => 'Teruskan ke Staff Pimpinan',
			'tte'              => 'TTE Surat',
		];

		if ($sign[0]['sign'] == 'skpd') {
			if ($leader != 1) {
				$stateButton = 'forward';
			} else {
				$stateButton = 'tte';
			}
		} elseif ($sign[0]['sign'] == 'sekretariat') {
			if ($leader != 1) {
				$stateButton = 'forward';
			} else {
				if ($skpd == 3) {
					$stateButton = 'tte';
				} else {
					$stateButton = 'forward_to_staff';
				}
			}
		} elseif ($sign[0]['sign'] == 'gubernur') {
			if ($leader != 1) {
				$stateButton = 'forward';
			} else {
				if ($skpd == 3) {
					$stateButton = 'forward_to_staff';
				} elseif ($skpd == 1) {
					$stateButton = 'tte';
				} else {
					$stateButton = 'forward_to_staff';
				}
			}
		}

		$data = [
			'stateButton' => $stateButton,
			'btnName'     => $btnName[$stateButton]
		];

		return $data;
	}

	/**
	 * Show disposition list by Mail category, Mail status
	 * Mail category : out, out_nonskpd, in, in_nonskpd
	 * Mail status : proses, selesai, perbaikan
	 * 
	 * @param	string	$category
	 * @param	string	$status
	 */
	public function index($category = null, $status = null)
	{
		$mail = ['out', 'out_nonskpd', 'in', 'in_nonskpd'];

		if (!in_array($category, $mail)) {
			return redirect()->to('admin/dashboard');
		} else {
			session()->remove('sess_disposition');

			$currentPage = ($this->request->getVar('page')) ? $this->request->getVar('page') : 1;

			return view('admin/disposition/' . $category . '/index', [
				'title'       => $this->regenerateTitle($category),
				'setting'     => getSetting(),
				'validation'  => Services::validation(),
				'data'        => $this->maildispositionModel->fetchData(false, $category, $status, session('user_id'))->paginate(10, 'default'),
				'pager'       => $this->maildispositionModel->pager,
				'currentPage' => $currentPage,
				'totalData'   => $this->maildispositionModel->fetchData(false, $category, $status, session('user_id'))->countAllResults(),
			]);
		}
	}

	/**
	 * Show disposition list by Mail category, Mail status, Keyword
	 * Mail category : out, out_nonskpd, in, in_nonskpd
	 * Mail status : proses, selesai, perbaikan
	 * 
	 * @param	string	$category
	 * @param	string	$status
	 */
	public function search($category = null, $status)
	{
		$currentPage = ($this->request->getVar('page')) ? $this->request->getVar('page') : 1;

		if ($this->request->getVar('keyword')) {
			$keyword = xssprint($this->request->getVar('keyword'));
			session()->set('sess_disposition', $keyword);
		} else {
			$keyword = xssprint(session()->get('sess_disposition'));
		}

		$mail = ['out', 'out_nonskpd', 'in', 'in_nonskpd'];

		if (!in_array($category, $mail)) {
			return redirect()->to('admin/dashboard');
		} else {
			return view('admin/disposition/' . $category . '/index', [
				'title'       => $this->regenerateTitle($category),
				'setting'     => getSetting(),
				'validation'  => Services::validation(),
				'data'        => $this->maildispositionModel->fetchData(false, $category, $status, session('user_id'), $keyword)->paginate(10, 'default'),
				'pager'       => $this->maildispositionModel->pager,
				'currentPage' => $currentPage,
				'totalData'   => $this->maildispositionModel->fetchData(false, $category, $status, session('user_id'), $keyword)->countAllResults(),
			]);
		}
	}

	/**
	 * Show detail disposition by Mail category, Mail status, Mail ID
	 * Mail category : out, out_nonskpd, in, in_nonskpd
	 * Mail status : proses, selesai, perbaikan
	 * 
	 * @param	string	$category
	 * @param	string	$status
	 * @param	string	$mail_id
	 */
	public function detail($category, $status, $mail_id)
	{
		$mail = ['out', 'out_nonskpd', 'in', 'in_nonskpd'];

		$file = $this->mailModel->where('id', $mail_id)->find();

		if (!in_array($category, $mail)) {
			return redirect()->to('admin/dashboard');
		} else {
			if ($category == 'out' or $category == 'out_nonskpd') {
				return view('admin/disposition/' . $category . '/_detail', [
					'title'           => $this->regenerateTitle($category),
					'setting'         => getSetting(),
					'validation'      => Services::validation(),
					'data'            => $this->maildispositionModel->fetchData($mail_id, $category, $status, session('user_id'))->find(),
					'dataReceiver'    => $this->mailreceiverModel->fetchData($mail_id)->findAll(),
					'dataDisposition' => $this->maildispositionModel->fetchData($mail_id)->findAll(),
					'action'          => $this->checkDispositionAction($mail_id, session('user_leader'), session('user_skpd')),
				]);
			} elseif ($category == 'in' or $category == 'in_nonskpd') {
				return view('admin/disposition/' . $category . '/_detail', [
					'title'           => $this->regenerateTitle($category),
					'setting'         => getSetting(),
					'validation'      => Services::validation(),
					'data'            => $this->maildispositionModel->fetchData($mail_id, $category, $status, session('user_id'))->find(),
					'dataReceiver'    => $this->mailreceiverModel->fetchData($mail_id)->findAll(),
					'dataDisposition' => $this->maildispositionModel->fetchData($mail_id)->findAll(),
					'totalChild'      => $this->positionModel->getBottomPosition(session('user_position'))->countAllResults(),
					'tteStatus'       => ($category == 'in') ? $this->verificationFile('./upload/mail/' . $file[0]['file']) : '',
				]);
			}
		}
	}

	/**
	 * Forward mail to top position
	 * Mail category : out, out_nonskpd, in, in_nonskpd
	 * Mail status : proses, selesai, perbaikan
	 * 
	 * @param	string	$category
	 * @param	string	$status
	 */
	public function forward($category, $status)
	{

		$mail = ['out', 'out_nonskpd'];

		if (!in_array($category, $mail)) {
			return redirect()->to('admin/dashboard');
		} else {
			$action = $this->request->getVar('action');

			if ($action == 'forward') {
				if ($status != 'perbaikan') {
					$getTop            = $this->positionModel->getTopPosition(session('user_position'))->find();
					$dispositionCreate = [
						'from_user'     => session('user_id'),
						'from_position' => session('user_position'),
						'to_user'       => $getTop[0]['id'],
						'to_position'   => $getTop[0]['parent'],
						'message'       => $this->request->getVar('message'),
						'status'        => 'proses',
						'category'      => $category,
						'mail_id'       => $this->request->getVar('mail_id'),
					];
				} else {
					$getLastDisposition = $this->maildispositionModel->where('id', $this->request->getVar('id'))->find();
					$dispositionCreate  = [
						'from_user'     => session('user_id'),
						'from_position' => session('user_position'),
						'to_user'       => $getLastDisposition[0]['from_user'],
						'to_position'   => $getLastDisposition[0]['from_position'],
						'message'       => $this->request->getVar('message'),
						'status'        => 'proses',
						'category'      => $category,
						'mail_id'       => $this->request->getVar('mail_id'),
					];
				}

				$this->maildispositionModel->save($dispositionCreate);

				// disposition update 
				$dispositionUpdate = [
					'id'     => $this->request->getVar('id'),
					'status' => 'selesai',
				];

				$this->maildispositionModel->save($dispositionUpdate);

				// create alert and log
				$message = session('user_name') . " berhasil melakukan forward disposisi data surat ke pimpinan";
				setAlert('success', $message);
				createLog($message, $this->request->getIPAddress(), session('user_id'));

				// redirect based on mail category [out, out_nonskpd, in_skpd]
				return redirect()->to($this->url . '/index/' . $category . '/' . $status);
			} elseif ($action == 'forward_to_staff') {
				// check staff from top position skpd
				$getTop     = $this->positionModel->getTopPosition(session('user_position'))->find();
				$getSkpdTop = $this->positionModel->where('id', $getTop[0]['parent'])->find();
				$getStaff   = $this->positionModel->getStaff($getSkpdTop[0]['skpd_id'])->find();

				$dispositionCreate  = [
					'from_user'     => session('user_id'),
					'from_position' => session('user_position'),
					'to_user'       => $getStaff[0]['id'],
					'to_position'   => $getStaff[0]['position_id'],
					'message'       => $this->request->getVar('message'),
					'status'        => 'proses',
					'category'      => $category,
					'mail_id'       => $this->request->getVar('mail_id'),
				];

				$this->maildispositionModel->save($dispositionCreate);

				// disposition update 
				$dispositionUpdate = [
					'id'     => $this->request->getVar('id'),
					'status' => 'selesai',
				];

				$this->maildispositionModel->save($dispositionUpdate);

				// create alert and log
				$message = session('user_name') . " berhasil melakukan forward disposisi data surat ke pimpinan";
				setAlert('success', $message);
				createLog($message, $this->request->getIPAddress(), session('user_id'));

				// redirect based on mail category [out, out_nonskpd, in_skpd]
				return redirect()->to($this->url . '/index/' . $category . '/' . $status);
			} elseif ($action == 'tte') {

				$username_tte = $this->request->getVar('username_tte');
				$password_tte = $this->request->getVar('password_tte');
				$file         = './upload/mail/' . $this->request->getVar('file');
				$qrName       = $this->request->getVar('mail_id') . '.png';

				// force image to PDF File
				$qrPath 	= './upload/mail/qrcode/'.$qrName;
				$countPage 	= $this->countPageFile($file); 


				$this->generatePDF($file,$file,$qrPath,$countPage,'atas','kanan');

				// check is user valid
				$checkUser = $this->accountValidity($username_tte);

				if ($checkUser['status'] == 'ISSUE') {

					$result =  $this->signFile($username_tte, $password_tte, $file, $qrName);
					if ($result['status'] == 'error') {
						// create alert
						$message = 'Gagal TTE, ' . $result['message'];
						setAlert('failed', $message);
						createLog($message, $this->request->getIPAddress(), session('user_id'));

						// redirect based on mail category [out, out_nonskpd, in_skpd]
						return redirect()->to($this->url . '/detail/' . $category . '/' . $status . '/' . $this->request->getVar('mail_id'));
					} else {

						unlink($file);
						rename('./file-sign/SIGNED/' . $result['message'], $file);

						// unlink EMPTY-SIGN & PDF
						unlink('./file-sign/PDF/'.$result['message']);
						unlink('./file-sign/EMPTY_SIG/'.$result['message']);

						// SUCCESS TTE
						$mailUpdate = [
							'id'     => $this->request->getVar('mail_id'),
							'status' => 'selesai',
						];

						$this->mailModel->save($mailUpdate);

						// disposition update 
						$dispositionUpdate = [
							'id'     => $this->request->getVar('id'),
							'status' => 'selesai',
						];

						$this->maildispositionModel->save($dispositionUpdate);

						// create alert and log
						$message = session('user_name') . ' Surat Berhasil Di TTE';
						setAlert('success', $message);
						createLog($message, $this->request->getIPAddress(), session('user_id'));

						// redirect based on mail category [out, out_nonskpd, in_skpd]
						return redirect()->to($this->url . '/index/' . $category . '/' . $status);
					}
				} else {

					// create alert
					$message = 'Gagal TTE, ' . $checkUser['message'];
					setAlert('failed', $message);
					createLog($message, $this->request->getIPAddress(), session('user_id'));

					// redirect based on mail category [out, out_nonskpd, in_skpd]
					return redirect()->to($this->url . '/detail/' . $category . '/' . $status . '/' . $this->request->getVar('mail_id'));
				}
			}
		}
	}

	/**
	 * Create repair mail to staff
	 * Mail category : out, out_nonskpd, in, in_nonskpd
	 * Mail status : proses, selesai, perbaikan
	 * 
	 * @param	string	$category
	 * @param	string	$status
	 * @param	string	$mail_id
	 */

	public function repair($category, $status)
	{
		$mail = ['out', 'out_nonskpd'];

		if (!in_array($category, $mail)) {
			return redirect()->to('admin/dashboard');
		} else {
			// $getStaff          = $this->positionModel->getStaff(session('user_skpd'))->find();
			$getFirstDisposition = $this->maildispositionModel->where('mail_id', $this->request->getVar('mail_id'))
				->where('category', $category)
				->orderBy('id', 'ASC')
				->limit(1)
				->find();

			$dispositionCreate = [
				'from_user'     => session('user_id'),
				'from_position' => session('user_position'),
				'to_user'       => $getFirstDisposition[0]['from_user'],
				'to_position'   => $getFirstDisposition[0]['from_position'],
				'message'       => $this->request->getVar('message'),
				'status'        => 'perbaikan',
				'category'      => $category,
				'mail_id'       => $this->request->getVar('mail_id'),
			];

			$this->maildispositionModel->save($dispositionCreate);

			// disposition update 
			$dispositionUpdate = [
				'id'     => $this->request->getVar('id'),
				'status' => 'selesai',
			];

			$this->maildispositionModel->save($dispositionUpdate);

			// create alert and log
			$message = session('user_name') . " berhasil request perbaikan ke staff";
			setAlert('success', $message);
			createLog($message, $this->request->getIPAddress(), session('user_id'));

			// redirect based on mail category [out, out_nonskpd, in_skpd]
			return redirect()->to($this->url . '/index/' . $category . '/' . $status);
		}
	}


	// ===================================================
	// ================== FOR INBOX ======================
	// ===================================================

	/**
	 * Set finish state for inbox mail
	 * Mail category : out, out_nonskpd, in, in_nonskpd
	 * Mail status : proses, selesai, perbaikan
	 * 
	 * @param	string	$category
	 * @param	string	$status
	 */

	public function finish($category, $status)
	{
		$mail = ['in', 'in_nonskpd'];

		if (!in_array($category, $mail)) {
			return redirect()->to('admin/dashboard');
		} else {
			// disposition update 
			$dispositionUpdate = [
				'id'     => $this->request->getVar('id'),
				'status' => 'selesai',
			];

			$this->maildispositionModel->save($dispositionUpdate);

			// check if all state finish
			$checkAllDisposition = $this->maildispositionModel->countFinishState($this->request->getVar('mail_id'), 'selesai')->countAllResults();

			if ($checkAllDisposition == 0) {
				if ($category == 'in_nonskpd') {
					// Update mail status 
					$mailUpdate = [
						'id'     => $this->request->getVar('mail_id'),
						'status' => 'selesai',
					];

					$this->mailModel->save($mailUpdate);
				} else {
					$getReceiverID = $this->mailreceiverModel->where('mail_id', $this->request->getVar('mail_id'))->where('skpd_id', session('user_skpd'))->find();
					// Update mail receiver status 
					$mailUpdate = [
						'id'     => $getReceiverID[0]['id'],
						'status' => 'selesai',
					];

					$this->mailreceiverModel->save($mailUpdate);
				}
			}

			// create alert and log
			$message = session('user_name') . " berhasil melakukan penyelesaian disposisi data surat dari pimpinan";
			setAlert('success', $message);
			createLog($message, $this->request->getIPAddress(), session('user_id'));

			// redirect based on mail category [out, out_nonskpd, in_skpd]
			return redirect()->to($this->url . '/index/' . $category . '/' . $status);
		}
	}

	/**
	 * Create disposition page
	 * Mail category : out, out_nonskpd, in, in_nonskpd
	 * Mail status : proses, selesai, perbaikan
	 * 
	 * @param	string	$category
	 * @param	string	$status
	 * @param	string	$mail_id
	 */
	public function create($category, $status, $mail_id)
	{
		$mail = ['in', 'in_nonskpd'];
		if (!in_array($category, $mail)) {
			return redirect()->to('admin/dashboard');
		} else {
			return view('admin/disposition/' . $category . '/_create', [
				'title'      => $this->regenerateTitle($category),
				'setting'    => getSetting(),
				'validation' => Services::validation(),
				'data'       => $this->maildispositionModel->fetchData($mail_id, $category, $status, session('user_id'))->find(),
				'dataChild'  => $this->positionModel->getBottomPosition(session('user_position'))->findAll(),
			]);
		}
	}

	/**
	 * Save disposition (for create and update)
	 * Mail category : out, out_nonskpd, in, in_nonskpd
	 * Mail status : proses, selesai, perbaikan
	 * 
	 * @param	string	$category
	 * @param	string	$status
	 */
	public function save($category, $status)
	{
		foreach ($this->request->getVar('receiver') as $key => $value) {
			$dispositionCreate = [
				'from_user'     => session('user_id'),
				'from_position' => session('user_position'),
				'to_user'       => $this->request->getVar('receiver')[$key],
				'to_position'   => $this->request->getVar('position')[$key],
				'message'       => $this->request->getVar('instruksi')[$key] . ' - ' . $this->request->getVar('message')[$key],
				'status'        => 'proses',
				'category'      => $category,
				'mail_id'       => $this->request->getVar('mail_id'),
			];

			$this->maildispositionModel->save($dispositionCreate);
		}

		// disposition update 
		$dispositionUpdate = [
			'id'     => $this->request->getVar('id'),
			'status' => 'selesai',
		];

		$this->maildispositionModel->save($dispositionUpdate);

		// create alert and log
		$message = session('user_name') . " berhasil melakukan forward disposisi data surat ke bawahan";
		setAlert('success', $message);
		createLog($message, $this->request->getIPAddress(), session('user_id'));

		// redirect based on mail category [out, out_nonskpd, in_skpd]
		return redirect()->to($this->url . '/index/' . $category . '/' . $status);
	}


	// ===================================================
	// ================== FOR TTE ========================
	// ===================================================

	public function accountValidity($nik)
	{
		$exec   = shell_exec("java -jar esign_client.jar -m cek_status_user -nik $nik");
		$output = json_decode($exec, TRUE);
		var_dump($exec);
		return $output;
	}

	public function signFile($nik, $password, $path, $qrName)
	{
		$pathSign  = './file-sign';
		$pathImage = './upload/mail/qrcode/' . $qrName;

		$exec   = shell_exec("java -jar esign_client.jar -m sign -f $path -p '$password' -nik $nik -t invisible -d $pathSign");

		// Sign Visible
		if (preg_match('/error/i', $exec)) {
			$output = json_decode($exec, TRUE);

			$data = [
				'message' => $output['error'],
				'status' => 'error'
			];
		} else {
			$output    = json_decode($exec, TRUE);
			$delimiter = $_SERVER['DOCUMENT_ROOT'] . '/./file-sign/SIGNED/';
			$data      = [
				'message' => str_replace($delimiter, '', $output),
				'status' => 'success'
			];
		}

		return $data;
	}

	public function verificationFile($path)
	{
		$exec   = shell_exec("java -jar esign_client.jar -m verifikasi -f $path");
		$output = json_decode($exec, TRUE);

		return $output;
	}

	// update 06-02-2022
	/**
     * This function for get number of page
     */
    function countPageFile($pathFile)
	{

        $cmd = "pdfinfo";
		
		// Parse entire output
		// Surround with double quotes if file name has spaces
		exec("$cmd \"$pathFile\"", $output);

		// Iterate through lines
		$pagecount = 0;
		foreach($output as $op)
		{
			// Extract the number
			if(preg_match("/Pages:\s*(\d+)/i", $op, $matches) === 1)
			{
				$pagecount = intval($matches[1]);
				break;
			}
		}
		
		return $pagecount;
    }

	// update 06-02-2022
	/**
	 * This function to insert image to each page
	 */ 
    function generatePDF($source, $output, $image, $page, $position, $align)
	{

		$pdf = new Fpdi();
        $pdf->setSourceFile($source);

        for ($i=1; $i <= $page ; $i++) { 
            
            $tppl 	= $pdf->importPage($i);
            $specs 	= $pdf->getTemplateSize($tppl);

            $pdf->addPage($specs['height'] > $specs['width'] ? 'P' : 'L');
            $pdf->useTemplate($tppl, 0, 0, $specs['width'], $specs['height']);

            if ($position == 'atas') {
                if ($align == 'kiri') {
					// Atas - Kiri
                    if ($specs['height'] > $specs['width']) {
                        $pdf->Image($image,0,0,25,25); // potrait
                    } else {
                        $pdf->Image($image,0,0,25,25); // landscape
                    }
                } else {
					// Atas Kanan
                    if ($specs['height'] > $specs['width']) {
                        $pdf->Image($image,($specs['width'] - 25),0,25,25); // potrait
                    } else {
                        $pdf->Image($image,($specs['width'] - 25),0,25,25); // landscape
                    }
                }
                
            } else {
				
                if ($align == 'kiri') {
					// Bawah Kiri
                    if ($specs['height'] > $specs['width']) {
                        $pdf->Image($image,0,($specs['height'] - 50),25,25); // potrait
                    } else {
                        $pdf->Image($image,0,($specs['height'] - 50),25,25); // landscape
                    }
                }else {
					// Bawah Kanan
                    if ($specs['height'] > $specs['width']) {
                        $pdf->Image($image,($specs['width'] - 50),($specs['height'] - 50),25,25); // potrait
                    } else {
                        $pdf->Image($image,($specs['width'] - 50),($specs['height'] - 50),25,25); // landscape
                    }
                }
                
            }
        }
        
        $pdf->Output($output, "F");
    }

}
