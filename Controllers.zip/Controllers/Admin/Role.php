<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\RoleModel;
use Config\Services;

class Role extends BaseController
{
	protected $roleModel;
	protected $url             = 'admin/role/';
	protected $allowedRoles    = [1];
	protected $validationRules = [
		'role' => [
			'rules'  => 'required|min_length[3]|max_length[30]',
			'errors' => [
				'required'   => 'Field ini tidak boleh kosong',
				'min_length' => 'Inputan terlalu pendek, pastikan tidak kurang dari 3 karakter',
				'max_length' => 'Inputan terlalu panjang, pastikan tidak lebih dari 30 karakter',
			]
		]
	];

	public function __construct()
	{
		$this->roleModel = new RoleModel();
		
		if (!in_array(session('user_role'), $this->allowedRoles)) {
			echo view('templates/layouts/access_denied', [
				'title' => 'Access Denied'
			]);
			exit;
		}
	}
	
	public function index()
	{
		session()->remove('sess_role');
		$currentPage = ($this->request->getVar('page')) ? $this->request->getVar('page') : 1;

		return view('admin/role/index',[
			'title'       => 'Role',
			'setting'     => getSetting(),
			'data'        => $this->roleModel->fetchData()->paginate(10,'default'),
			'pager'       => $this->roleModel->pager,
			'currentPage' => $currentPage,
			'totalData'   => $this->roleModel->countAllResults(),

		]);
	}

	public function search()
	{
		$currentPage = ($this->request->getVar('page')) ? $this->request->getVar('page') : 1;

		if($this->request->getVar('keyword')) {
            $keyword = xssprint($this->request->getVar('keyword'));
            session()->set('sess_role', $keyword);
        }else{
            $keyword = xssprint(session()->get('sess_role'));
        }

		return view('admin/role/index',[
			'title'       => 'Role',
			'setting'     => getSetting(),
			'data'        => $this->roleModel->fetchData($keyword)->paginate(10,'default'),
			'pager'       => $this->roleModel->pager,
			'currentPage' => $currentPage,
			'totalData'   => $this->roleModel->fetchData($keyword)->countAllResults(),
		]);
	}

	/**
	 * Load form by action (create & update)
	 * 
	 * @param	string	$action
	 * @param	int		$id
	 */
	public function form($action = null, $id = null){
		if ($action == 'create') {
			return view('admin/role/_create',[
				'title'      => 'Role',
				'setting'    => getSetting(),
				'validation' => Services::validation()
			]);
		} elseif($action == 'update') {
			return view('admin/role/_update', [
				'title'      => 'Role',
				'setting'    => getSetting(),
				'validation' => Services::validation(),
				'data'       => $this->roleModel->where('id', $id)->first()
			]);
		} else {
			return redirect()->to($this->url);
		}
	}

	/**
	 * Save data by action (create & update)
	 * 
	 * @param	string	$action
	 * @param	int		$id
	 */
	public function save($action = null)
	{
		if (!$this->validate($this->validationRules)) {
			$valueUrl = ($action == 'create') ? '': $this->request->getVar('id');
			return redirect()->to($this->url."form/$action/$valueUrl")->withInput();
		} else {
			$data = [
				'role' => xssprint($this->request->getVar('role'))
			];
			
			// if action update, push id
			($action == 'update') ? $data += ['id' => $this->request->getVar('id')] : '';
			
			// save data
			$this->roleModel->save($data);

			// create alert and log
			$message = session('user_name') ." berhasil melakukan $action data role";
			setAlert('success', $message);
			createLog($message, $this->request->getIPAddress(), session('user_id'));

			return redirect()->to($this->url);
		}
	}


	public function delete()
	{
		// delete data
		$this->roleModel->delete($this->request->getVar('id'));
		
		// create alert and log
		$message = session('user_name') ." berhasil melakukan delete data role";
		setAlert('success', $message);
		createLog($message, $this->request->getIPAddress(), session('user_id'));

		return redirect()->to($this->url);
	}

	
}
