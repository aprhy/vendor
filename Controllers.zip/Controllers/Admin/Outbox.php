<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\MaildispositionModel;
use App\Models\MailModel;
use App\Models\MailreceiverModel;
use App\Models\PositionModel;
use Config\Services;

class Outbox extends BaseController
{
	protected $mailModel, $mailreceiverModel, $maildispositionModel, $positionModel;
	protected $url          = 'admin/outbox';
	protected $allowedRoles = [1,2,3];
	
	public function __construct()
	{
		$this->mailModel            = new MailModel();
		$this->mailreceiverModel    = new MailreceiverModel();
		$this->maildispositionModel = new MaildispositionModel();
		$this->positionModel        = new PositionModel();

		if (!in_array(session('user_role') , $this->allowedRoles)) {
			echo view('templates/layouts/access_denied',[
				'title' => 'Access Denied'
			]);
			exit;
		}
	}

	public function index($category = null, $status = null)
	{
		$mail = ['out','out_nonskpd'];
		if (!in_array($category , $mail)) {
			return redirect()->to('admin/dashboard');
		}else{
			
			($category == 'out') ? session()->remove('sess_outbox_out') : session()->remove('sess_outbox_out_nonskpd');

			$currentPage = ($this->request->getVar('page')) ? $this->request->getVar('page') : 1;

			return view('admin/mail/list_outbox',[
				'title'       => 'Data Surat Keluar',
				'setting'     => getSetting(),
				'validation'  => Services::validation(),
				'data'        => $this->mailModel->fetchData($category, $status, session('user_skpd'))->paginate(10,'default'),
				'pager'       => $this->mailModel->pager,
				'currentPage' => $currentPage,
				'totalData'   => $this->mailModel->fetchData($category, $status, session('user_skpd'))->countAllResults()
			]);
		}
	}

	public function search($category = null, $status)
	{
		$currentPage = ($this->request->getVar('page')) ? $this->request->getVar('page') : 1;

		if($this->request->getVar('keyword')) {
            $keyword = xssprint($this->request->getVar('keyword'));
			($category == 'out') ? session()->set('sess_outbox_out', $keyword) : session()->set('sess_outbox_out_nonskpd', $keyword);
        }else{
			$keyword = ($category == 'out') ? xssprint(session()->get('sess_outbox_out')) : xssprint(session()->get('sess_outbox_out_nonskpd'));
        }


		$mail = ['out','out_nonskpd'];
		if (!in_array($category , $mail)) {
			return redirect()->to('admin/dashboard');
		}else{

			return view('admin/mail/list_outbox',[
				'title'       => 'Data Surat Keluar',
				'setting'     => getSetting(),
				'validation'  => Services::validation(),
				'data'        => $this->mailModel->fetchData($category, $status, session('user_skpd'), $keyword)->paginate(10,'default'),
				'pager'       => $this->mailModel->pager,
				'currentPage' => $currentPage,
				'totalData'   => $this->mailModel->fetchData($category, $status, session('user_skpd'), $keyword)->countAllResults(),
			]);
		}
	}

	public function detail($category, $status, $mail_id)
	{
		$mail = ['out','out_nonskpd'];
		if (!in_array($category , $mail)) {
			return redirect()->to('admin/dashboard');
		}else{
			
			return view('admin/mail/'.$category.'/_detail',[
				'title'           => 'Detail Surat Keluar',
				'setting'         => getSetting(),
				'validation'      => Services::validation(),
				'data'            => $this->mailModel->fetchData($category, $status, session('user_skpd'), false, $mail_id)->find(),
				'dataReceiver'    => $this->mailreceiverModel->fetchData($mail_id)->findAll(),
				'dataDisposition' => $this->maildispositionModel->fetchData($mail_id)->findAll(),
			]);
		}
	}

	public function delete($category, $status)
	{
		// delete data
		$this->mailModel->delete($this->request->getVar('id'));
		$this->mailreceiverModel->where('mail_id', $this->request->getVar('id'))->delete();
		$this->maildispositionModel->where('mail_id', $this->request->getVar('id'))->delete();
		
		//delete file
        if($this->request->getVar('file') != ""){
            unlink('upload/mail/'.$this->request->getVar('file'));
			if (file_exists('upload/mail/qrcode/'.$this->request->getVar('id').'.png')) {
				unlink('upload/mail/qrcode/'.$this->request->getVar('id').'.png');
			}
        }
		// create alert and log
		$message = session('user_name') ." berhasil melakukan delete data Surat Keluar";
		setAlert('success', $message);
		createLog($message, $this->request->getIPAddress(), session('user_id'));

		return redirect()->to($this->url.'/index/'.$category.'/'.$status);
	}

	public function forward($category = null, $status = null)
	{
		$mail = ['out','out_nonskpd'];
		if (!in_array($category , $mail)) {
			return redirect()->to('admin/dashboard');
		}else{
			$data = [
				'id'     => $this->request->getVar('id'),
				'status' => 'disposisi',
			];

			$this->mailModel->save($data);

			// create disposition
			$getTop = $this->positionModel->getTopPosition(session('user_position'))->find();

			$dataDisposition = [
				'from_user'     => session('user_id'),
				'from_position' => session('user_position'),
				'to_user'       => $getTop[0]['id'],
				'to_position'   => $getTop[0]['parent'],
				'message'       => 'Review Surat Keluar',
				'status'        => 'proses',
				'category'      => $category,
				'mail_id'       => $this->request->getVar('id'),
			];

			$this->maildispositionModel->save($dataDisposition);

			// create alert and log
			$message = session('user_name') ." berhasil melakukan forward data surat ke pimpinan";
			setAlert('success', $message);
			createLog($message, $this->request->getIPAddress(), session('user_id'));

			// redirect based on mail category [out, out_nonskpd, in_skpd]
			return redirect()->to($this->url.'/index/'.$category.'/'.$status);
		}
	}
}
