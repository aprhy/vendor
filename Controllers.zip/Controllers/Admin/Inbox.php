<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\MaildispositionModel;
use App\Models\MailModel;
use App\Models\MailreceiverModel;
use App\Models\PositionModel;
use Config\Services;

class Inbox extends BaseController
{
	protected $mailModel, $mailreceiverModel, $maildispositionModel, $positionModel;
	protected $url          = 'admin/inbox';
	protected $allowedRoles = [1,2,3];

	public function __construct()
	{
		$this->mailModel            = new MailModel();
		$this->mailreceiverModel    = new MailreceiverModel();
		$this->maildispositionModel = new MaildispositionModel();
		$this->positionModel        = new PositionModel();

		if (!in_array(session('user_role'), $this->allowedRoles)) {
			echo view('templates/layouts/access_denied', [
				'title' => 'Access Denied'
			]);
			exit;
		}
	}
	
	public function index($category = null, $status = null)
	{
		$mail = ['in', 'in_nonskpd'];

		if (!in_array($category, $mail)) {
			return redirect()->to('admin/dashboard');
		} else {
			
			($category == 'in') ? session()->remove('sess_inbox_in') : session()->remove('sess_inbox_in_nonskpd');

			$currentPage = ($this->request->getVar('page')) ? $this->request->getVar('page') : 1 ;

			if ($category == 'in') {

				return view('admin/mail/list_inbox', [
					'title'       => 'Data Surat Masuk',
					'setting'     => getSetting(),
					'data'        => $this->mailModel->fetchDataInbox($status, session('user_skpd'))->paginate(10,'default'),
					'pager'       => $this->mailModel->pager,
					'currentPage' => $currentPage,
					'totalData'   => $this->mailModel->fetchDataInbox($status, session('user_skpd'))->countAllResults()
				]);

			} else {

				return view('admin/mail/list_inbox_nonskpd', [
					'title'       => 'Data Surat Masuk',
					'setting'     => getSetting(),
					'data'        => $this->mailModel->fetchData($category, $status, session('user_skpd'))->paginate(10,'default'),
					'pager'       => $this->mailModel->pager,
					'currentPage' => $currentPage,
					'totalData'   => $this->mailModel->fetchData($category, $status, session('user_skpd'))->countAllResults()
				]);

			}
		}
	}

	public function search($category = null, $status)
	{
		

		$mail = ['in','in_nonskpd'];

		if (!in_array($category, $mail)) {
			return redirect()->to('admin/dashboard');
		} else {

			$currentPage = ($this->request->getVar('page')) ? $this->request->getVar('page') : 1 ;

			if ($this->request->getVar('keyword')) {
				$keyword = xssprint($this->request->getVar('keyword'));
				($category == 'in') ? session()->set('sess_inbox_in', $keyword) : session()->set('sess_inbox_in_nonskpd', $keyword);
			} else {
				$keyword = ($category == 'in') ? xssprint(session()->set('sess_inbox_in')) : xssprint(session()->set('sess_inbox_in_nonskpd'));
			}
			
			if ($category == 'in') {
				
				return view('admin/mail/list_inbox', [
					'title'   => 'Data Surat Masuk',
					'setting' => getSetting(),
					'data'        => $this->mailModel->fetchDataInbox($status, session('user_skpd'), $keyword)->paginate(10,'default'),
					'pager'       => $this->mailModel->pager,
					'currentPage' => $currentPage,
					'totalData'   => $this->mailModel->fetchDataInbox($status, session('user_skpd'), $keyword)->countAllResults()
				]);

			} else {

				return view('admin/mail/list_inbox_nonskpd', [
					'title'   => 'Data Surat Masuk',
					'setting' => getSetting(),
					'data'        => $this->mailModel->fetchData($category, $status, session('user_skpd'), $keyword)->paginate(10,'default'),
					'pager'       => $this->mailModel->pager,
					'currentPage' => $currentPage,
					'totalData'   => $this->mailModel->fetchData($category, $status, session('user_skpd'), $keyword)->countAllResults()
				]);
			}
		}
	}

	public function detail($category, $status, $mail_id)
	{
		$mail = ['in', 'in_nonskpd'];
		$file = $this->mailModel->where('id', $mail_id)->find();

		if (!in_array($category, $mail)) {
			return redirect()->to('admin/dashboard');
		} else {
			
			if ($category == 'in') {
				return view('admin/mail/'.$category.'/_detail', [
					'title'           => 'Detail Surat Masuk',
					'setting'         => getSetting(),
					'validation'      => Services::validation(),
					'data'            => $this->mailModel->fetchDataInbox($status, session('user_skpd'), false, $mail_id)->find(),
					'dataReceiver'    => $this->mailreceiverModel->fetchData($mail_id)->findAll(),
					'dataDisposition' => $this->maildispositionModel->fetchData($mail_id)->findAll(),
					'tteStatus'       => $this->verificationFile('./upload/mail/'.$file[0]['file']),
				]);
			} else {
				return view('admin/mail/'.$category.'/_detail', [
					'title'           => 'Detail Surat Masuk',
					'setting'         => getSetting(),
					'validation'      => Services::validation(),
					'data'            => $this->mailModel->fetchData($category, $status, session('user_skpd'), false, $mail_id)->find(),
					'dataReceiver'    => $this->mailreceiverModel->fetchData($mail_id)->findAll(),
					'dataDisposition' => $this->maildispositionModel->fetchData($mail_id)->findAll(),
				]);
			}
		}
	}

	/**
	 * Just for category = in_nonskpd
	 * because it created manually
	 */
	public function delete($category, $status)
	{
		if ($category != 'in_nonskpd') {
			return redirect()->to('admin/dashboard');
		} else {
			
			// delete data
			$this->mailModel->delete($this->request->getVar('id'));
			$this->maildispositionModel->where('mail_id', $this->request->getVar('id'))->delete();

			// delete files
			if ($this->request->getVar('file') != "") {
				unlink('upload/mail/'. $this->request->getVar('file'));
			}

			// create alert and log
			$message = session('user_name') ." berhasil melakukan delete data Surat Masuk";
			setAlert('success', $message);
			createLog($message, $this->request->getIPAddress(), session('user_id'));

			return redirect()->to($this->url.'/index/'.$category.'/'.$status);
		}
	}

	public function forward($category = null, $status = null)
	{
		$mail = ['in','in_nonskpd'];

		if (!in_array($category, $mail)) {
			return redirect()->to('admin/dashboard');
		} else {
			
			if ($category == 'in_nonskpd') {
				$data = [
					'id' => $this->request->getVar('id'),
					'status' => 'disposisi'
				];

				$this->mailModel->save($data);
			} else {

				$data = [
					'id' => $this->request->getVar('id'),
					'status' => 'disposisi'
				];

				$this->mailreceiverModel->save($data);
			}

			// create disposition
			$getTop = $this->positionModel->getLeader(session('user_skpd'))->find();

			$dataDisposition = [
				'from_user'     => session('user_id'),
				'from_position' => session('user_position'),
				'to_user'       => $getTop[0]['id'],
				'to_position'   => $getTop[0]['position_id'],
				'message'       => 'Disposisi Surat Masuk',
				'status'        => 'proses',
				'category'      => $category, 
				'mail_id'       => ($category == 'in_nonskpd') ? $this->request->getVar('id') : $this->request->getVar('mail_id'),
			];

			$this->maildispositionModel->save($dataDisposition);

			// create alert and log
			$message = session('user_name') ." berhasil melakukan forward data surat ke pimpinan";
			setAlert('success', $message);
			createLog($message, $this->request->getIPAddress(), session('user_id'));

			// redirect based on mail category [out, out_nonskpd, in_skpd]
			return redirect()->to($this->url.'/index/'.$category.'/'.$status);
		}
	}

	public function verificationFile($path)
	{
        $exec   = shell_exec("java -jar esign_client.jar -m verifikasi -f $path");
        $output = json_decode($exec, TRUE);

        return $output;
	}
}
