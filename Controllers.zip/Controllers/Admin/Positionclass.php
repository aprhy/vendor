<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\PositionclassModel;
use Config\Services;

class Positionclass extends BaseController
{
	protected $positionclassModel;
	protected $url             = 'admin/positionclass/';
	protected $allowedRoles    = [1];
	protected $validationRules = [
		'name' => [
			'rules'  => 'required|min_length[5]|max_length[50]',
			'errors' => [
				'required'   => 'Field ini tidak boleh kosong',
				'min_length' => 'Inputan terlalu pendek, pastikan tidak kurang dari 5 karakter',
				'max_length' => 'Inputan terlalu panjang, pastikan tidak lebih dari 50 karakter',
			]
		]
	];

	public function __construct()
	{
		$this->positionclassModel = new PositionclassModel();
		
		if (!in_array(session('user_role'), $this->allowedRoles)) {
			echo view('templates/layouts/access_denied', [
				'title' => 'Access Denied'
			]);
			exit;
		}
	}
	
	public function index()
	{
		session()->remove('sess_positionclass');
		$currentPage = ($this->request->getVar('page')) ? $this->request->getVar('page') : 1;

		return view('admin/positionclass/index',[
			'title'       => 'Kelas Jabatan',
			'setting'     => getSetting(),
			'data'        => $this->positionclassModel->fetchData()->paginate(10,'default'),
			'pager'       => $this->positionclassModel->pager,
			'currentPage' => $currentPage,
			'totalData'   => $this->positionclassModel->countAllResults(),

		]);
	}

	public function search()
	{
		$currentPage = ($this->request->getVar('page')) ? $this->request->getVar('page') : 1;

		if($this->request->getVar('keyword')) {
            $keyword = xssprint($this->request->getVar('keyword'));
            session()->set('sess_positionclass', $keyword);
        }else{
            $keyword = xssprint(session()->get('sess_positionclass'));
        }

		return view('admin/positionclass/index',[
			'title'       => 'Kelas Jabatan',
			'setting'     => getSetting(),
			'data'        => $this->positionclassModel->fetchData($keyword)->paginate(10,'default'),
			'pager'       => $this->positionclassModel->pager,
			'currentPage' => $currentPage,
			'totalData'   => $this->positionclassModel->fetchData($keyword)->countAllResults(),
		]);
	}

	/**
	 * Load form by action (create & update)
	 * 
	 * @param	string	$action
	 * @param	int		$id
	 */
	public function form($action = null, $id = null){
		if ($action == 'create') {
			return view('admin/positionclass/_create',[
				'title'      => 'Kelas Jabatan',
				'setting'    => getSetting(),
				'validation' => Services::validation()
			]);
		} elseif($action == 'update') {
			return view('admin/positionclass/_update', [
				'title'      => 'Kelas Jabatan',
				'setting'    => getSetting(),
				'validation' => Services::validation(),
				'data'       => $this->positionclassModel->where('id', $id)->first()
			]);
		} else {
			return redirect()->to($this->url);
		}
	}

	/**
	 * Save data by action (create & update)
	 * 
	 * @param	string	$action
	 */
	public function save($action = null)
	{
		if (!$this->validate($this->validationRules)) {
			$valueUrl = ($action == 'create') ? '': $this->request->getVar('id');
			return redirect()->to($this->url."form/$action/$valueUrl")->withInput();
		} else {
			$data = [
				'name' => xssprint($this->request->getVar('name'))
			];
			
			// if action update, push id
			($action == 'update') ? $data += ['id' => $this->request->getVar('id')] : '';
			
			// save data
			$this->positionclassModel->save($data);

			// create alert and log
			$message = session('user_name') ." berhasil melakukan $action data kelas jabatan";
			setAlert('success', $message);
			createLog($message, $this->request->getIPAddress(), session('user_id'));

			return redirect()->to($this->url);
		}
	}

	public function delete()
	{
		// delete data
		$this->positionclassModel->delete($this->request->getVar('id'));
		
		// create alert and log
		$message = session('user_name') ." berhasil melakukan delete data kelas jabatan";
		setAlert('success', $message);
		createLog($message, $this->request->getIPAddress(), session('user_id'));

		return redirect()->to($this->url);
	}

	
}
