<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\SettingModel;
use Config\Services;

class Setting extends BaseController
{
	protected $settingModel;
	protected $allowedRoles    = [1];
	protected $validationRules = [
		'appname' => [
			'rules'  => 'required|min_length[10]|max_length[50]',
			'errors' => [
				'required' => 'Field ini tidak boleh kosong',
				'min_lenght' =>'Inputan terlalu pendek, pastikan tidak kurang dari 10 karakter',
				'max_lenght' =>'Inputan terlalu panjang, pastikan tidak lebih dari 50 karakter',
			]
		],
		'appname_short' => [
			'rules'  => 'required|min_length[3]|max_length[15]',
			'errors' => [
				'required' => 'Field ini tidak boleh kosong',
				'min_lenght' =>'Inputan terlalu pendek, pastikan tidak kurang dari 3 karakter',
				'max_lenght' =>'Inputan terlalu panjang, pastikan tidak lebih dari 15 karakter',
			]
		],
		'email' => [
			'rules'  => 'required|valid_email',
			'errors' => [
				'required'    => 'Field ini tidak boleh kosong',
				'valid_email' => 'Format email harus valid'
			]
		],
		'phone' => [
			'rules'  => 'required|min_length[12]|max_length[30]',
			'errors' => [
				'required' => 'Field ini tidak boleh kosong',
				'min_lenght' =>'Inputan terlalu pendek, pastikan tidak kurang dari 12 karakter',
				'max_lenght' =>'Inputan terlalu panjang, pastikan tidak lebih dari 30 karakter',
			]
		],
		'owner' => [
			'rules'  => 'required|min_length[5]|max_length[100]',
			'errors' => [
				'required' => 'Field ini tidak boleh kosong',
				'min_lenght' =>'Inputan terlalu pendek, pastikan tidak kurang dari 5 karakter',
				'max_lenght' =>'Inputan terlalu panjang, pastikan tidak lebih dari 100 karakter',
			]
		],
		'origin' => [
			'rules'  => 'required|min_length[5]|max_length[30]',
			'errors' => [
				'required' => 'Field ini tidak boleh kosong',
				'min_lenght' =>'Inputan terlalu pendek, pastikan tidak kurang dari 5 karakter',
				'max_lenght' =>'Inputan terlalu panjang, pastikan tidak lebih dari 100 karakter',
			]
		],
		'logo' => [
			'rules'  => 'max_size[logo,1024]|is_image[logo]|mime_in[logo,image/jpg,image/jpeg,image/png]',
			'errors' => [
				'max_size' => 'File tidak boleh lebih besar dari 1 MB',
				'is_image' => 'File yang diupload hanya boleh gambar (JPG,JPEG,PNG)',
				'mime_in'  => 'File yang diupload hanya boleh gambar (JPG,JPEG,PNG)'
			]
		],
	];
	
	public function __construct()
	{
		$this->settingModel = new SettingModel();

		if (!in_array(session('user_role'), $this->allowedRoles)) {
			echo view('templates/layouts/access_denied', [
				'title'	=> 'Access Denied',
			]);
			exit;
		}
	}

	public function index()
	{
		return view('admin/setting', [
			'title'      => 'Setting',
			'setting'    => getSetting(),
			'validation' => Services::validation(),
		]);
	}

	public function save()
	{
		if (!$this->validate($this->validationRules)) {
			return redirect()->to($this->url)->withInput();
		} else {
			$file           = $this->request->getFile('logo');
			$oldFile        = $this->request->getVar('old_logo');
			$path           = 'upload/setting/';
			$finalFilesName = fileUploader($file, $oldFile, 'images', $path, 'update');
			
			$this->settingModel->save([
				'id'            => $this->request->getVar('id'),
				'appname'       => xssprint($this->request->getVar('appname')),
				'appname_short' => xssprint($this->request->getVar('appname_short')),
				'owner'         => xssprint($this->request->getVar('owner')),
				'origin'        => xssprint($this->request->getVar('origin')),
				'phone'         => xssprint($this->request->getVar('phone')),
				'email'         => xssprint($this->request->getVar('email')),
				'logo'          => xssprint($finalFilesName),
			]);

			$message = session('user_name') ." berhasil melakukan update data pengaturan website";
			setAlert('success', $message);
			createLog($message, $this->request->getIPAddress(), session('user_id'));

			return redirect()->to($this->url);
		}
	}
}