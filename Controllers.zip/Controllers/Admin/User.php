<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\PositionModel;
use App\Models\RoleModel;
use App\Models\SkpdModel;
use App\Models\UserModel;
use Config\Services;

class User extends BaseController
{
	protected $userModel, $roleModel, $positionModel, $skpdModel;
	protected $url             = 'admin/user/';
	protected $allowedRoles    = [1, 3];
	protected $validationRules = [
		'fullname' => [
			'rules'  => 'required',
			'errors' => ['required' => 'Field ini tidak boleh kosong']
		],
		'username' => [
			'rules'  => 'required|is_unique[tbl_user.username]',
			'errors' => [
				'required' => 'Field ini tidak boleh kosong',
				'is_unique' => 'Nilai yang diinput sudah terdaftar di database, silahkan gunakan yang lain'
			]
		],
		'email' => [
			'rules'  => 'required|valid_email|is_unique[tbl_user.email]',
			'errors' => [
				'required'    => 'Field ini tidak boleh kosong',
				'is_unique'   => 'Nilai yang diinput sudah terdaftar di database, silahkan gunakan yang lain',
				'valid_email' => 'Format email harus valid'
			]
		],
		'password' => [
			'rules'  => 'required|min_length[8]',
			'errors' => [
				'required'   => 'Field ini tidak boleh kosong',
				'min_length' => 'Panjang password minimal 8 karakter'
			]
		],
		'role_id' => [
			'rules'  => 'required',
			'errors' => ['required' => 'Field ini tidak boleh kosong']
		],
		'position_id' => [
			'rules'  => 'required',
			'errors' => ['required' => 'Field ini tidak boleh kosong']
		]
	];


	public function __construct()
	{
		$this->userModel     = new UserModel();
		$this->roleModel     = new RoleModel();
		$this->positionModel = new PositionModel();
		$this->skpdModel     = new SkpdModel();

		if (!in_array(session('user_role'), $this->allowedRoles)) {
			echo view('templates/layouts/access_denied', [
				'title' => 'Access Denied'
			]);
			exit;
		}
	}

	public function index()
	{
		session()->remove('sess_user');
		$currentPage = ($this->request->getVar('page')) ? $this->request->getVar('page') : 1;
		if (session('user_role') == 3) {
			$result =  $this->userModel->fetchData(session('user_name'))->first();
			return view('admin/user/index', [
				'title'       => 'User',
				'setting'     => getSetting(),
				'data'        => $this->userModel->fetchDataSkpd($result['skpd_id'])->paginate(10, 'default'),
				'pager'       => $this->userModel->pager,
				'currentPage' => $currentPage,
				'totalData'   => count($this->userModel->fetchDataSkpd($result['skpd_id'])->find())
			]);
		} else {
			return view('admin/user/index', [
				'title'       => 'User',
				'setting'     => getSetting(),
				'data'        => $this->userModel->fetchData()->paginate(10, 'default'),
				'pager'       => $this->userModel->pager,
				'currentPage' => $currentPage,
				'totalData'   => $this->userModel->countAllResults()
			]);
		}
	}

	public function search()
	{
		$currentPage = ($this->request->getVar('page')) ? $this->request->getVar('page') : 1;

		if ($this->request->getVar('keyword')) {
			$keyword = xssprint($this->request->getVar('keyword'));
			session()->set('sess_user', $keyword);
		} else {
			$keyword = xssprint(session()->get('sess_user'));
		}

		return view('admin/user/index', [
			'title'       => 'User',
			'setting'     => getSetting(),
			'data'        => $this->userModel->fetchData(false, $keyword)->paginate(10, 'default'),
			'pager'       => $this->userModel->pager,
			'currentPage' => $currentPage,
			'totalData'   => $this->userModel->fetchData(false, $keyword)->countAllResults()
		]);
	}

	/**
	 * Load form by action (create & update)
	 * 
	 * @param	string	$action
	 * @param	int		$id
	 * @param	int		$skpd
	 */
	public function form($action = null, $id = null, $skpd = null)
	{
		if ($action == 'create') {
			return view('admin/user/_create', [
				'title'        => 'User',
				'setting'      => getSetting(),
				'validation'   => Services::validation(),
				'dataRole'     => $this->roleModel->findAll(),
				'dataSkpd'     => $this->skpdModel->findAll(),
			]);
		} elseif ($action == 'update') {
			return view('admin/user/_update', [
				'title'        => 'User',
				'setting'      => getSetting(),
				'validation'   => Services::validation(),
				'data'         => $this->userModel->where('id', $id)->first(),
				'dataRole'     => $this->roleModel->findAll(),
				'dataPosition' => $this->positionModel->fetchData($skpd)->findAll(),
				'dataSkpd'     => $this->skpdModel->findAll(),
			]);
		} else {
			return redirect()->to($this->url);
		}
	}

	/**
	 * Save data by action (create & update)
	 * 
	 * @param	string	$action
	 * @param	int		$id
	 */
	public function save($action = null)
	{
		// this validation used if data have uniqe value ::just on updates cases
		$validationRulesUpdate = [
			'fullname' => [
				'rules'  => 'required',
				'errors' => ['required' => 'Field ini tidak boleh kosong']
			],
			'username' => [
				'rules'  => 'required|is_unique[tbl_user.username,id,' . $this->request->getVar('id') . ']',
				'errors' => [
					'required' => 'Field ini tidak boleh kosong',
					'is_unique' => 'Nilai yang diinput sudah terdaftar di database, silahkan gunakan yang lain'
				]
			],
			'email' => [
				'rules'  => 'required|valid_email|is_unique[tbl_user.email,id,' . $this->request->getVar('id') . ']',
				'errors' => [
					'required'    => 'Field ini tidak boleh kosong',
					'is_unique'   => 'Nilai yang diinput sudah terdaftar di database, silahkan gunakan yang lain',
					'valid_email' => 'Format email harus valid'
				]
			],
			'role_id' => [
				'rules'  => 'required',
				'errors' => ['required' => 'Field ini tidak boleh kosong']
			],
			'position_id' => [
				'rules'  => 'required',
				'errors' => ['required' => 'Field ini tidak boleh kosong']
			]
		];

		if (!$this->validate(($action == 'create') ? $this->validationRules : $validationRulesUpdate)) {
			$valueUrl = ($action == 'create') ? '' : $this->request->getVar('id');
			return redirect()->to($this->url . "form/$action/$valueUrl")->withInput();
		} else {
			$data = [
				'username'    => xssprint($this->request->getVar('username')),
				'fullname'    => xssprint($this->request->getVar('fullname')),
				'email'       => xssprint($this->request->getVar('email')),
				'nip'         => xssprint(trim($this->request->getVar('nip'))),
				'unit'        => xssprint($this->request->getVar('unit')),
				'status'      => xssprint($this->request->getVar('status')),
				'role_id'     => xssprint($this->request->getVar('role_id')),
				'position_id' => xssprint($this->request->getVar('position_id')),
				'password'    => password_hash($this->request->getVar('password'), PASSWORD_BCRYPT)
			];

			// if password empty, pop item password (make sure password in end of array)
			($this->request->getVar('password')) ? '' : array_pop($data);

			// if action update, push id
			($action == 'update') ? $data += ['id' => $this->request->getVar('id')] : '';

			// save data
			$this->userModel->save($data);

			// create alert and log
			$message = session('user_name') . " berhasil melakukan $action data user";
			setAlert('success', $message);
			createLog($message, $this->request->getIPAddress(), session('user_id'));

			return redirect()->to($this->url);
		}
	}

	public function delete()
	{
		// delete data
		$this->userModel->delete($this->request->getVar('id'));

		//delete image
		if ($this->request->getVar('photo') != 'noimage.jpeg' && $this->request->getVar('photo') != "") {
			unlink('upload/profile/' . $this->request->getVar('photo'));
		}

		// create alert and log
		$message = session('user_name') . " berhasil melakukan delete data user";
		setAlert('success', $message);
		createLog($message, $this->request->getIPAddress(), session('user_id'));

		return redirect()->to($this->url);
	}

	/**
	 * Change status users (acitve or nonactive)
	 * 
	 * @param	string	$state
	 * @param	int		$id
	 */
	public function status($state, $id)
	{
		$data = [
			'id'     => $id,
			'status' => $state,
		];

		// save data
		$this->userModel->save($data);

		// create alert and log
		$message = session('user_name') . " berhasil melakukan perubahan status data user";
		setAlert('success', $message);
		createLog($message, $this->request->getIPAddress(), session('user_id'));

		return redirect()->to($this->url);
	}
}
