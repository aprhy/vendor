<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\PositionclassModel;
use App\Models\PositionModel;
use App\Models\SkpdModel;

class Position extends BaseController
{
	protected $positionModel, $positionclassModel, $skpdModel;
	protected $url             = 'admin/position/';
	protected $allowedRoles    = [1];
	
	public function __construct()
	{
		$this->positionModel      = new PositionModel();
		$this->positionclassModel = new PositionclassModel();
		$this->skpdModel          = new SkpdModel();

		if (!in_array(session('user_role'), $this->allowedRoles)) {
			echo view('templates/layouts/access_denied', [
				'title' => 'Access Denied'
			]);
			exit;
		}
	}
	
	/**
	 * Show position by skpd
	 * 
	 * @param	int	$skpd
	 */
	public function index($skpd = null)
	{
		if ($skpd == null) {
			return redirect()->to('admin/skpd/');
		}

		$str = "";
		$this->generateTreeView($str, $skpd, 1, 0);
		
		return view('admin/position/index',[
			'title'             => 'Jabatan',
			'setting'           => getSetting(),
			'data'              => $str,
			'dataPositionClass' => $this->positionclassModel->fetchData()->find(),
			'dataSkpd'          => $this->skpdModel->where('id', $skpd)->first(),
		]);
	}

	/**
	 * Save data by action (create & update)
	 * 
	 * @param	string	$action
	 */
	public function save($action = null)
	{
		$data = [
			'name'             => xssprint($this->request->getVar('name')),
			'parent'           => xssprint($this->request->getVar('parent')),
			'leader'           => xssprint($this->request->getVar('leader')),
			'positionclass_id' => xssprint($this->request->getVar('positionclass_id')),
			'skpd_id'          => xssprint($this->request->getVar('skpd_id')),
		];
		
		// if action update, push id
		($action == 'update') ? $data += ['id' => $this->request->getVar('id')] : '';
		
		// save data
		$this->positionModel->save($data);

		// create alert and log
		$message = session('user_name') ." berhasil melakukan $action data jabatan";
		setAlert('success', $message);
		createLog($message, $this->request->getIPAddress(), session('user_id'));

		return redirect()->to($this->url.'/index/'.$data['skpd_id']);
		
	}

	public function delete()
	{
		// delete data
		$this->positionModel->delete($this->request->getVar('id'));
		
		// delete tree recursive
		$this->deleteTreeView($this->request->getVar('skpd_id'),0,$this->request->getVar('id'));

		// create alert and log
		$message = session('user_name') ." berhasil melakukan delete data jabatan";
		setAlert('success', $message);
		createLog($message, $this->request->getIPAddress(), session('user_id'));

		return redirect()->to($this->url.'/index/'.$this->request->getVar('skpd_id'));
	}


	/**
	 * Generate tree view / hierarki
	 * 
	 * @param	string	$str
	 * @param	int		$skpd
	 * @param	int		$leader
	 * @param	int		$paren
	 */
	public function generateTreeView(&$str, $skpd, $leader, $parent)
	{
		$getTree           = $this->positionModel->generateTree($skpd, $leader, $parent)->find();
		$positionclassData = $this->positionclassModel->fetchData()->find();
		$positionData      = $this->positionModel->fetchData($skpd)->find();
		

		(count($getTree) > 0) ? $str .='<ol style="list-style-type: initial;margin-top:5px">' : '';

		foreach ($getTree as $tree) {
			$str .= '<li style="margin-top:5px;">';
			$str .= $tree['name'] .' - 
						<button class="btn btn-xs btn-success" data-toggle="modal" data-target="#modalPosition'.$tree['id'].'">Tambah Bawahan</button>
						<button class="btn btn-xs btn-warning" data-toggle="modal" data-target="#modalUpdate'.$tree['id'].'">Edit Jabatan</button> | 
						<button class="btn btn-xs btn-danger" data-toggle="modal" data-target="#modalDelete'.$tree['id'].'">Hapus Jabatan</button>
			
						<div class="modal fade" id="modalPosition'.$tree['id'].'" data-backdrop="false" aria-labelledby="deleteModalLabel" aria-hidden="true">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header bg-success text-white">
										<h5 class="modal-title" id="deleteModalLabel">Tambah Data</h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
									</div>
									<div class="modal-body">
					';
										
			$str .=						form_open_multipart("admin/position/save/create", 'class="form-horizontal"');
			$str .=						csrf_field();
			$str .= '						
											<input type="hidden" class="form-control" name="parent" value="'.$tree['id'].'">
											<input type="hidden" class="form-control" name="leader" value="0">
											<input type="hidden" class="form-control" name="skpd_id" value="'.$skpd.'">

											<div class="mb-3">
												<label class="form-label">Nama Jabatan *</label>
												<input type="text" class="form-control" placeholder="Nama Jabatan" name="name" required>
											</div>
											<div class="mb-3">
												<label class="form-label">Kelas Jabatan *</label>
												<select class="form-control select2" name="positionclass_id" required>
													<option value="">:: Pilih Kelas Jabatan ::</option>
												
												';
												foreach ($positionclassData as $pc) {
			$str .='								<option value="'.$pc['id'].'">'.$pc['name'].'</option>';
												}	
			$str .=	'							</select>
											</div>
											<div class="mb-3">
												<label class="form-label">Atasan *</label>
												<input type="text" class="form-control" placeholder="Atasan" value="'.$tree['name'].'" required readonly>
											</div>

											<hr style="border: 0.5px dashed #d2d6de">
											<button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Batal</button>
											<button type="submit" class="btn btn-success" >Tambah</button>'.
										form_close().'
									</div>
								</div>
							</div>
						</div>
					
						<div class="modal fade" id="modalUpdate'.$tree['id'].'" data-backdrop="false" aria-labelledby="deleteModalLabel" aria-hidden="true">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header bg-warning text-white">
										<h5 class="modal-title" id="deleteModalLabel">Update Data</h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
									</div>
									<div class="modal-body">
					';
										
			$str .=						form_open_multipart("admin/position/save/update", 'class="form-horizontal"');
			$str .=						csrf_field();
			$str .= '						
											
											<input type="hidden" class="form-control" name="id" value="'.$tree['id'].'">
											<input type="hidden" class="form-control" name="leader" value="'.$tree['leader'].'">
											<input type="hidden" class="form-control" name="skpd_id" value="'.$skpd.'">

											<div class="mb-3">
												<label class="form-label">Nama Jabatan *</label>
												<input type="text" class="form-control" placeholder="Nama Jabatan" name="name" value="'.$tree['name'].'" required>
											</div>
											<div class="mb-3">
												<label class="form-label">Kelas Jabatan *</label>
												<select class="form-control select2" name="positionclass_id" required>
													<option value="">:: Pilih Kelas Jabatan ::</option>
												';
												foreach ($positionclassData as $pc) {
													if($pc['id'] == $tree['positionclass_id']){
			$str .='									<option value="'.$pc['id'].'" selected>'.$pc['name'].'</option>';
													}else{
			$str .='									<option value="'.$pc['id'].'">'.$pc['name'].'</option>';
													}
												}	
			$str .=	'							</select>
											</div>
											<div class="mb-3">
												<label class="form-label">Atasasn *</label>
												<select class="form-control select2" name="parent" required>';
												if($tree['leader'] == 1){
			$str .='								<option value="0" '.(($tree['parent'] == 0) ? "selected":"").'>Tidak Ada</option>
													<option value="1" '.(($tree['parent'] == 1) ? "selected":"").'>Gubernur</option>
													<option value="2" '.(($tree['parent'] == 2) ? "selected":"").'>Wakil Gubernur</option>
													<option value="3" '.(($tree['parent'] == 3) ? "selected":"").'>Sekretaris Daerah</option>
													';
												}else{
													foreach ($positionData as $pcd) {
														if($pcd['id'] == $tree['parent']){
			$str .='										<option value="'.$pcd['id'].'" selected>'.$pcd['name'].'</option>';
														}else{
			$str .='										<option value="'.$pcd['id'].'">'.$pcd['name'].'</option>';
														}
													}	
												}
			$str .=	'							</select>
											</div>
											
											<hr style="border: 0.5px dashed #d2d6de">
											<button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Batal</button>
											<button type="submit" class="btn btn-success" >Update</button>'.
										form_close().'
									</div>
								</div>
							</div>
						</div>
						
						<div class="modal fade" id="modalDelete'.$tree['id'].'" data-backdrop="false" aria-labelledby="deleteModalLabel" aria-hidden="true">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header bg-danger text-white">
										<h5 class="modal-title" id="deleteModalLabel">Hapus Data</h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
									</div>
									<div class="modal-body">
					';
										
			$str .=						form_open_multipart("admin/position/delete", 'class="form-horizontal"');
			$str .=						csrf_field();
			$str .= '						
											
											<input type="hidden" class="form-control" name="skpd_id" value="'.$skpd.'">
											<input type="hidden" class="form-control" name="id" value="'.$tree['id'].'">

											Apakah anda yakin akan menghapus data ini ?<br>
											<b>Jabatan : '.$tree['name'].'</b><br>
											<p class="text-red">
												catatan : jika anda menghapus jabatan ini, maka semua jabatan yang ada dibawahnya akan ikut terhapus.
											</p>
											<hr style="border: 0.5px dashed #d2d6de">

											<hr style="border: 0.5px dashed #d2d6de">
											<button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Batal</button>
											<button type="submit" class="btn btn-danger" >Ya, Hapus</button>'.
										form_close().'
									</div>
								</div>
							</div>
						</div>
						
						';

			$this->generateTreeView($str, $skpd, 0, $tree['id']);
			$str .= '</li>';
		}

		(count($getTree) > 0) ? $str .='</ol>' : '';

		return $str;
	}

	/**
	 * Delete tree view / hierarki
	 * 
	 * @param	int		$skpd
	 * @param	int		$leader
	 * @param	int		$parent
	 */
	public function deleteTreeView($skpd, $leader, $parent)
	{
		$data = $this->positionModel->generateTree($skpd, $leader, $parent)->find();
		
		foreach ($data as $key) {
			$this->positionModel->delete($key['id']);
			$this->deleteTreeView($skpd, 0, $key['id']);
		}
	}
}
