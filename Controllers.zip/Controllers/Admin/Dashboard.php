<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\PositionModel;
use App\Models\WidgetModel;

class Dashboard extends BaseController
{
	protected $widgetModel, $positionModel;

	public function __construct()
	{
		$this->widgetModel 		= new WidgetModel();
		$this->positionModel    = new PositionModel();
	}
	
	public function index()
	{
		return view('admin/dashboard', [
			'title'             => 'Dashboard',
			'basicWidget'       => $this->widgetModel->basicWidget()[0],
			'mailWidget'        => $this->widgetModel->mailWidget(session('user_skpd'))[0],
			'dispositionWidget' => $this->widgetModel->dispositionWidget(session('user_id'))[0],
			'trafficGraph'      => $this->trafficGraph(),
			'mailGraph'         => $this->mailGraph(session('user_skpd')),
			'setting'           => getSetting()
		]);
	}

	public function trafficGraph()
	{
		$result = []; 
		for ($time = 0; $time <= 23; $time++)
		{
			(strlen($time) == 1) ? $dateFormat = date('Y-m-d')." 0".$time : $dateFormat = date('Y-m-d')." ".$time ;
			$dataGraph = $this->widgetModel->trafficGraph($dateFormat)[0];

			array_push($result, $dataGraph['total']);
		}

		return $result;
	}

	public function mailGraph($skpd)
	{
		$result = [];

		for ($month=1; $month <= 12 ; $month++) { 
			
			(strlen($month) == 1) ? $dateFormat = date('Y')."-0".$month : $dateFormat = date('Y')."-".$month;
			$dataGraph = $this->widgetModel->mailGraph($dateFormat, $skpd)[0];
			$arrData   = ["sm" => $dataGraph['inboxTotal'], "sk" => $dataGraph['outboxTotal']];
			
			array_push($result, $arrData);
		}

		return $result;
	}

	public function generateTTDImage()
	{
		$dataLeader = $this->positionModel->getLeader(session('user_skpd'))->find()[0];
		
		$position 	= strtoupper('Kepala '.session('user_skpdname'));
		$name 		= $dataLeader['fullname'];
		$nip 		= $dataLeader['nip'];
		$image 		= $_SERVER['DOCUMENT_ROOT'].'/upload/file_ttd.png';

		$this->generateImage($image, $position, $name, $nip);

		return redirect()->to('admin/dashboard');
	}

	function generateImage($image, $position, $name, $nip) {
        

        $img    = imagecreatefrompng($image);
        $color  = imagecolorallocate($img, 0, 0, 0);

        // set jabatan
		$textPosition 	= $this->wordWrapText($position);
		if(count($textPosition) == 1) {
			$size = 8; $x = 100; $y = 20; $angle = 0;
			imagettftext($img, $size, $angle, $x, $y, $color, $_SERVER['DOCUMENT_ROOT'].'/upload/font-bold.ttf', $textPosition[0]);
		}else {
			$startPosition 	= 20;
			for ($tp=0; $tp < count($textPosition) ; $tp++) { 
				

				$size = 7; $x = 100; $y = $startPosition; $angle = 0;
				imagettftext($img, $size, $angle, $x, $y, $color, $_SERVER['DOCUMENT_ROOT'].'/upload/font-bold.ttf', $textPosition[$tp]);
				
				$startPosition = $startPosition + 11;
			}
		}
        

		// set nama
        $size = 8; $x = 100; $y = 70; $angle = 0;
        imagettftext($img, $size, $angle, $x, $y, $color, $_SERVER['DOCUMENT_ROOT'].'/upload/font-bold.ttf', $name);

		// set nip
        $size = 8; $x = 100; $y = 85; $angle = 0;
        imagettftext($img, $size, $angle, $x, $y, $color, $_SERVER['DOCUMENT_ROOT'].'/upload/font.ttf', $nip);

        


        imagejpeg($img, $_SERVER['DOCUMENT_ROOT'].'/upload/ttd/'.session('user_skpd').'.jpg');
    }

	function wordWrapText($string)
	{
		$line = explode("\n", wordwrap($string, 45, "\n"));
		return $line;
	}
}
