<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\LogModel;
use App\Models\UserModel;
use Config\Services;

class Profile extends BaseController
{
	protected $userModel, $logModel;
	protected $url             = 'admin/profile/';
	protected $allowedRoles    = [1,2,3];
	protected $validationRules = [
		'email' => [
			'rules'  => 'required|valid_email',
			'errors' => [
				'required'    => 'Field ini tidak boleh kosong',
				'valid_email' => 'Format email harus valid'
			]
		],
		'fullname' => [
			'rules'  => 'required',
			'errors' => ['required' => 'Field ini tidak boleh kosong']
		],
		'photo' => [
			'rules'  => 'max_size[photo,1024]|is_image[photo]|mime_in[photo,image/jpg,image/jpeg,image/png]',
			'errors' => [
				'max_size' => 'File tidak boleh lebih besar dari 1 MB',
				'is_image' => 'File yang diupload hanya boleh gambar (JPG,JPEG,PNG)',
				'mime_in'  => 'File yang diupload hanya boleh gambar (JPG,JPEG,PNG)'
			]
		],
	];

	public function __construct()
	{
		$this->userModel = new UserModel();
		$this->logModel  = new LogModel();

		if (!in_array(session('user_role'), $this->allowedRoles)) {
			echo view('templates/layouts/access_denied', [
				'title' => 'Access Denied'
			]);
			exit;
		}
	}

	/**
	 * Display profile data from url parsing
	 * 
	 * @param string	$username
	 */
	public function index($username = null)
	{
		if(empty($username)){
			$message = 'Data user tidak valid';
			setAlert('failed', $message);
			
			return redirect()->to('admin/dashboard/');
		} else {
			if($username == session('user_name')) {
				return view('admin/user/profile', [
					'title'      => 'Profile',
					'setting'    => getSetting(),
					'validation' => Services::validation(),
					'profile'    => $this->userModel->fetchData($username)->first(),
					'myLog'      => $this->logModel->fetchData(session('user_id'))->find()
				]);
			} else {
				$message = 'Data user yang diakses bukan data anda';
				setAlert('failed', $message);
				
				return redirect()->to('admin/dashboard/');
			}
		}
	}

	public function save()
	{
		if (!$this->validate($this->validationRules)) {
			return redirect()->to($this->url.'index/'.session('user_name'))->withInput();
		} else {
			// PASSWORD HANDLER
			if ($this->request->getVar('old_password') != "") {
				if (password_verify($this->request->getVar('old_password'), session('user_password'))) {
					if ($this->request->getVar('new_password') == $this->request->getVar('validate_new_password')) {
						if ($this->request->getVar('validate_new_password') != "" ) {
							$password = password_hash($this->request->getVar('validate_new_password'), PASSWORD_BCRYPT);
						} else {
							setAlert('failed', 'Password baru tidak boleh dikosongkan jika ingin mengubah password');
							return redirect()->to($this->url.'index/'.session('user_name'))->withInput();
						}
					} else {
						setAlert('failed', 'Password baru dan konfirmasi tidak cocok, silahkan masukkan nilai yang sama');
						return redirect()->to($this->url.'index/'.session('user_name'))->withInput();
					}
				} else {
					setAlert('failed', 'Password lama yang anda masukkan pada form tidak sesuai dengan yang ada pada database');
					return redirect()->to($this->url.'index/'.session('user_name'))->withInput();
				}
			}else {
				$password = session('user_password');
			}

			// FILE HANDLER
			$file           = $this->request->getFile('photo');
			$oldFile        = $this->request->getVar('old_photo');
			$path			= 'upload/profile/';
			$finalFilesName = fileUploader($file, $oldFile, 'images', $path, 'update');
			
			$this->userModel->save([
				'id'       => session('user_id'),
				'fullname' => xssprint($this->request->getVar('fullname')),
				'email'    => xssprint($this->request->getVar('email')),
				'photo'    => xssprint($finalFilesName),
				'password' => $password,
			]);

			session()->set([
				'user_fullname' => $this->request->getVar('fullname'),
				'user_email'    => $this->request->getVar('email'),
				'user_photo'    => $finalFilesName,
				'user_password' => $password,
			]);

			$message = session('user_name') ." berhasil melakukan update profile";
			setAlert('success', $message);
			createLog($message, $this->request->getIPAddress(), session('user_id'));

			return redirect()->to($this->url.'index/'.session('user_name'));
		}
		
	}
	
}
