<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\DraftModel;
use Config\Services;

class Draft extends BaseController
{
	protected $draftModel;
	protected $url             = 'admin/draft/';
	protected $allowedRoles    = [1];
	protected $validationRules = [
		'name' => [
			'rules'  => 'required|min_length[5]|max_length[50]',
			'errors' => [
				'required'   => 'Field ini tidak boleh kosong',
				'min_length' => 'Inputan terlalu pendek, pastikan tidak kurang dari 5 karakter',
				'max_length' => 'Inputan terlalu panjang, pastikan tidak lebih dari 50 karakter',
			]
		],
		'draft' => [
			'rules'  => 'required',
			'errors' => [
				'required'   => 'Field ini tidak boleh kosong',
			]
		]
	];

	public function __construct()
	{
		$this->draftModel = new DraftModel();
		if (!in_array(session('user_role'), $this->allowedRoles)) {
			echo view('templates/layouts/access_denied', [
				'title' => 'Access Denied'
			]);
			exit;
		}
	}
	
	public function index()
	{
		session()->remove('sess_draft');
		$currentPage = ($this->request->getVar('page')) ? $this->request->getVar('page') : 1;

		return view('admin/draft/index',[
			'title'       => 'Klasifikasi Surat',
			'setting'     => getSetting(),
			'data'        => $this->draftModel->fetchData()->paginate(10,'default'),
			'pager'       => $this->draftModel->pager,
			'currentPage' => $currentPage,
			'totalData'   => $this->draftModel->countAllResults(),

		]);
	}

	public function search()
	{
		$currentPage = ($this->request->getVar('page')) ? $this->request->getVar('page') : 1;

		if($this->request->getVar('keyword')) {
            $keyword = xssprint($this->request->getVar('keyword'));
            session()->set('sess_draft', $keyword);
        }else{
            $keyword = xssprint(session()->get('sess_draft'));
        }

		return view('admin/draft/index',[
			'title'       => 'Klasifikasi Surat',
			'setting'     => getSetting(),
			'data'        => $this->draftModel->fetchData($keyword)->paginate(10,'default'),
			'pager'       => $this->draftModel->pager,
			'currentPage' => $currentPage,
			'totalData'   => $this->draftModel->fetchData($keyword)->countAllResults(),
		]);
	}

	/**
	 * Load form by action (create & update)
	 * 
	 * @param	string	$action
	 * @param	int		$id
	 */
	public function form($action = null, $id = null){
		if ($action == 'create') {
			return view('admin/draft/_create',[
				'title'      => 'Klasifikasi Surat',
				'setting'    => getSetting(),
				'validation' => Services::validation()
			]);
		} elseif($action == 'update') {
			return view('admin/draft/_update', [
				'title'      => 'Klasifikasi Surat',
				'setting'    => getSetting(),
				'validation' => Services::validation(),
				'data'       => $this->draftModel->where('id', $id)->first()
			]);
		} else {
			return redirect()->to($this->url);
		}
	}

	/**
	 * Save data by action (create & update)
	 * 
	 * @param	string	$action
	 * @param	int		$id
	 */
	public function save($action = null)
	{
		if (!$this->validate($this->validationRules)) {
			$valueUrl = ($action == 'create') ? '': $this->request->getVar('id');
			return redirect()->to($this->url."form/$action/$valueUrl")->withInput();
		} else {
			$data = [
				'name'  => xssprint($this->request->getVar('name')),
				'draft' => $this->request->getVar('draft')
			];
			
			// if action update, push id
			($action == 'update') ? $data += ['id' => $this->request->getVar('id')] : '';
			
			// save data
			$this->draftModel->save($data);

			// create alert and log
			$message = session('user_name') ." berhasil melakukan $action data Klasifikasi Surat";
			setAlert('success', $message);
			createLog($message, $this->request->getIPAddress(), session('user_id'));

			return redirect()->to($this->url);
		}
	}

	public function delete()
	{
		// delete data
		$this->draftModel->delete($this->request->getVar('id'));
		
		// create alert and log
		$message = session('user_name') ." berhasil melakukan delete data Klasifikasi Surat";
		setAlert('success', $message);
		createLog($message, $this->request->getIPAddress(), session('user_id'));

		return redirect()->to($this->url);
	}

	
}
