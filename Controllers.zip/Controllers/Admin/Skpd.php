<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\SkpdModel;
use Config\Services;

class Skpd extends BaseController
{
	protected $skpdModel;
	protected $url             = 'admin/skpd/';
	protected $allowedRoles    = [1];
	protected $validationRules = [
		'name' => [
			'rules'  => 'required|min_length[5]|max_length[200]',
			'errors' => [
				'required'   => 'Field ini tidak boleh kosong',
				'min_length' => 'Inputan terlalu pendek, pastikan tidak kurang dari 5 karakter',
				'max_length' => 'Inputan terlalu panjang, pastikan tidak lebih dari 200 karakter',
			]
		],
		'address' => [
			'rules'  => 'required',
			'errors' => [
				'required'   => 'Field ini tidak boleh kosong',
			]
		],
		'category' => [
			'rules'  => 'required',
			'errors' => [
				'required'   => 'Field ini tidak boleh kosong',
			]
		]
	];

	public function __construct()
	{
		$this->skpdModel = new SkpdModel();

		if (!in_array(session('user_role'), $this->allowedRoles)) {
			echo view('templates/layouts/access_denied', [
				'title' => 'Access Denied'
			]);
			exit;
		}
	}
	
	public function index()
	{
		session()->remove('sess_skpd');
		$currentPage = ($this->request->getVar('page')) ? $this->request->getVar('page') : 1;

		return view('admin/skpd/index',[
			'title'       => 'SKPD',
			'setting'     => getSetting(),
			'data'        => $this->skpdModel->fetchData()->paginate(10,'default'),
			'pager'       => $this->skpdModel->pager,
			'currentPage' => $currentPage,
			'totalData'   => $this->skpdModel->countAllResults(),

		]);
	}

	public function search()
	{
		$currentPage = ($this->request->getVar('page')) ? $this->request->getVar('page') : 1;

		if($this->request->getVar('keyword')) {
            $keyword = xssprint($this->request->getVar('keyword'));
            session()->set('sess_skpd', $keyword);
        }else{
            $keyword = xssprint(session()->get('sess_skpd'));
        }

		return view('admin/skpd/index',[
			'title'       => 'SKPD',
			'setting'     => getSetting(),
			'data'        => $this->skpdModel->fetchData($keyword)->paginate(10,'default'),
			'pager'       => $this->skpdModel->pager,
			'currentPage' => $currentPage,
			'totalData'   => $this->skpdModel->fetchData($keyword)->countAllResults(),
		]);
	}

	/**
	 * Load form by action (create & update)
	 * 
	 * @param	string	$action
	 * @param	int		$id
	 */
	public function form($action = null, $id = null){
		if ($action == 'create') {
			return view('admin/skpd/_create',[
				'title'      => 'SKPD',
				'setting'    => getSetting(),
				'validation' => Services::validation()
			]);
		} elseif($action == 'update') {
			return view('admin/skpd/_update', [
				'title'      => 'SKPD',
				'setting'    => getSetting(),
				'validation' => Services::validation(),
				'data'       => $this->skpdModel->where('id', $id)->first()
			]);
		} else {
			return redirect()->to($this->url);
		}
	}

	/**
	 * Save data by action (create & update)
	 * 
	 * @param	string	$action
	 * @param	int		$id
	 */
	public function save($action = null)
	{
		if (!$this->validate($this->validationRules)) {
			$valueUrl = ($action == 'create') ? '': $this->request->getVar('id');
			return redirect()->to($this->url."form/$action/$valueUrl")->withInput();
		} else {
			$data = [
				'name'     => xssprint($this->request->getVar('name')),
				'address'  => xssprint($this->request->getVar('address')),
				'category' => xssprint($this->request->getVar('category')),
			];

			// if action update, push id
			($action == 'update') ? $data += ['id' => $this->request->getVar('id')] : '';
			
			// save data
			$this->skpdModel->save($data);

			// create alert and log
			$message = session('user_name') ." berhasil melakukan $action data SKPD";
			setAlert('success', $message);
			createLog($message, $this->request->getIPAddress(), session('user_id'));

			return redirect()->to($this->url);
		}
	}


	public function delete()
	{
		// delete data
		$this->skpdModel->delete($this->request->getVar('id'));
		
		// create alert and log
		$message = session('user_name') ." berhasil melakukan delete data SKPD";
		setAlert('success', $message);
		createLog($message, $this->request->getIPAddress(), session('user_id'));

		return redirect()->to($this->url);
	}

	
}
