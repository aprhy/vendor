<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\LogModel;

class Log extends BaseController
{
	
	protected $logModel;
	protected $url             = 'admin/log/';
	protected $allowedRoles    = [1];
	protected $validationRules = [];
	
	public function __construct()
	{
		$this->logModel = new LogModel();
		
		if (!in_array(session('user_role'), $this->allowedRoles)) {
			echo view('templates/layouts/access_denied',[
				'title' => 'Access Denied'
			]);
			exit;
		}
	}

	public function index()
	{
		session()->remove('sess_log');
		$currentPage = $this->request->getVar('page') ? $this->request->getVar('page') : 1;

		return view('admin/log',[
			'title'       => 'Log Sistem',
			'setting'     => getSetting(),
			'data'        => $this->logModel->fetchData()->paginate(10,'default'),
			'pager'       => $this->logModel->pager,
			'currentPage' => $currentPage,
			'totalData'   => $this->logModel->countAllResults(),
		]);
	}

	public function search()
	{
		$currentPage = $this->request->getVar('page') ? $this->request->getVar('page') : 1;
        
        if($this->request->getVar('keyword')) {
            $keyword = xssprint($this->request->getVar('keyword'));
            session()->set('sess_log', $keyword);
        }else{
            $keyword = xssprint(session()->get('sess_log'));
        }

        return view('admin/log',[
			'title'       => 'Log Sistem',
			'setting'     => getSetting(),
			'data'        => $this->logModel->fetchData(false,$keyword)->paginate(10,'default'),
			'pager'       => $this->logModel->pager,
			'currentPage' => $currentPage,
			'totalData'   => $this->logModel->fetchData(false,$keyword)->countAllResults(),
		]);
	}
}
