<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\DraftModel;
use App\Models\MailModel;
use App\Models\MailreceiverModel;
use App\Models\PositionModel;
use App\Models\SkpdModel;
use App\Models\UserModel;
use Config\Services;
use Endroid\QrCode\Color\Color;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel\ErrorCorrectionLevelHigh;
use Endroid\QrCode\ErrorCorrectionLevel\ErrorCorrectionLevelLow;
use Endroid\QrCode\Logo\Logo;
use Endroid\QrCode\QrCode;
use Endroid\QrCode\RoundBlockSizeMode\RoundBlockSizeModeMargin;
use Endroid\QrCode\Writer\PngWriter;
use Spipu\Html2Pdf\Html2Pdf;
use Treinetic\ImageArtist\lib\Image;

class Mail extends BaseController
{
	
	protected $mailModel, $mailreceiverModel, $draftModel, $skpdModel, $userModel, $positionModel;
	protected $url             = 'admin/mail';
	protected $allowedRoles    = [3];
	protected $validationRules = [
		'number' => [
			'rules'  => 'required',
			'errors' => [
				'required'   => 'Field ini tidak boleh kosong',
			]
		],
		'date' => [
			'rules'  => 'required',
			'errors' => [
				'required'   => 'Field ini tidak boleh kosong',
			]
		],
		'agenda' => [
			'rules'  => 'required',
			'errors' => [
				'required'   => 'Field ini tidak boleh kosong',
			]
		],
		'about' => [
			'rules'  => 'required',
			'errors' => [
				'required'   => 'Field ini tidak boleh kosong',
			]
		],
		'sign' => [
			'rules'  => 'required',
			'errors' => [
				'required'   => 'Field ini tidak boleh kosong',
			]
		],
		'summary' => [
			'rules'  => 'required',
			'errors' => [
				'required'   => 'Field ini tidak boleh kosong',
			]
		],
		'destination_nonskpd' => [
			'rules'  => 'required',
			'errors' => [
				'required'   => 'Field ini tidak boleh kosong',
			]
		],
	];

	public function __construct()
	{
		$this->mailModel         = new MailModel();
		$this->mailreceiverModel = new MailreceiverModel();
		$this->draftModel        = new DraftModel();
		$this->skpdModel         = new SkpdModel();
		$this->userModel         = new UserModel();
		$this->positionModel     = new PositionModel();

		if (!in_array(session('user_role') , $this->allowedRoles)) {
			echo view('templates/layouts/access_denied',[
				'title' => 'Access Denied'
			]);
			exit;
		}
	}

	public function index()
	{
		return view('admin/mail/index',[
			'title'   => 'Buat Surat',
			'setting' => getSetting(),
		]);
	}

	public function urlform()
	{
		$category = $this->request->getVar('category');
		$option   = $this->request->getVar('option');
		$draft    = $this->request->getVar('draft_id');
		return redirect()->to($this->url.'/form/create/'.$category.'/'.$option.'/'.$draft);
	}

	public function create($category)
	{
		$mail = ['out','out_nonskpd','in_nonskpd'];
		if (!in_array($category , $mail)) {
			return redirect()->to($this->url);
		}else{
			return view('admin/mail/'.$category.'/index',[
				'title'      => 'Pilih Template Surat',
				'setting'    => getSetting(),
				'validation' => Services::validation(),
				'dataDraft'  => $this->draftModel->findAll(),
			]);
		}
	}

	public function form($action = null, $category = null, $option = null, $draft = null, $mail_id = null)
	{
		if ($action == 'create') {
			return view('admin/mail/'.$category.'/_create',[
				'title'               => 'Surat',
				'setting'             => getSetting(),
				'validation'          => Services::validation(),
				'dataDraft'           => $this->draftModel->where('id', $draft)->find(),
				'dataSkpd'            => $this->skpdModel->where('id', session('user_skpd'))->find(),
				'dataLeader'          => $this->positionModel->getLeader(session('user_skpd'))->find(),
				'dataSkpdGubernur'    => $this->skpdModel->where('category','gubernur')->find(),
				'dataSkpdDinas'       => $this->skpdModel->where('category','dinas')->find(),
				'dataSkpdBadan'       => $this->skpdModel->where('category','badan')->find(),
				'dataSkpdSekretariat' => $this->skpdModel->where('category','sekretariat')->find(),
			]);

		} elseif ($action == 'update') {
			$receiver    = $this->mailreceiverModel->select('skpd_id')->where('mail_id', $mail_id)->findAll();
			$allReceiver = [];

			foreach ($receiver as $key) {
				array_push($allReceiver, $key['skpd_id']);
			}

			return view('admin/mail/'.$category.'/_update',[
				'title'               => 'Surat',
				'setting'             => getSetting(),
				'validation'          => Services::validation(),
				'data'                => $this->mailModel->where('id', $mail_id)->find(),
				'dataReceiver'        => $allReceiver,
				'dataDraft'           => $this->draftModel->where('id', $draft)->find(),
				'dataSkpd'            => $this->skpdModel->where('id', session('user_skpd'))->find(),
				'dataLeader'          => $this->positionModel->getLeader(session('user_skpd'))->find(),
				'dataSkpdGubernur'    => $this->skpdModel->where('category','gubernur')->find(),
				'dataSkpdDinas'       => $this->skpdModel->where('category','dinas')->find(),
				'dataSkpdBadan'       => $this->skpdModel->where('category','badan')->find(),
				'dataSkpdSekretariat' => $this->skpdModel->where('category','sekretariat')->find(),
			]);
		}  else {
			return redirect()->to($this->url);
		}
	}

	public function save($action = null)
	{
		if (!$this->validate($this->validationRules)) {
			if ($action == 'create') {
				return redirect()->to($this->url."/form/$action/".$this->request->getVar('category').'/'.$this->request->getVar('template_draft').'/'.$this->request->getVar('draft_id'))->withInput();
			} else {
				return redirect()->to($this->url."/form/$action/".$this->request->getVar('category').'/'.$this->request->getVar('template_draft').'/'.$this->request->getVar('draft_id').'/'.$this->request->getVar('id'))->withInput();
			}
			
		} else {
			
			if ($this->request->getFile('file')) {
				// FILE HANDLER
				$file           = $this->request->getFile('file');
				$oldFile        = $this->request->getVar('old_file');
				$path			= 'upload/mail/';
				$finalFilesName = fileUploader($file, $oldFile, 'document', $path, $action);

			} else {
				// update 06-02-2022
				if ($this->request->getVar('validate_attachment') == 'yes') {
					$templateFinal = '<page backbottom="10mm" backleft="10mm" backright="10mm" backtop="20mm" orientation="p">'.$this->request->getVar('template').'</page> <page backbottom="10mm" backleft="10mm" backright="10mm" backtop="20mm" orientation="p">'.$this->request->getVar('template_attachment').'</page>';
				} else {
					$templateFinal = '<page backbottom="10mm" backleft="10mm" backright="10mm" backtop="20mm" orientation="p">'.$this->request->getVar('template').'</page>';
				}

				$namePDF = md5($this->request->getVar('number').'-'.$this->request->getVar('skpd_id').'-'.date('YmdHis'));
				// CREATE PDF FILE FROM TEMPLATE
				$html2pdf = new Html2Pdf();
				$html2pdf->writeHTML(str_replace('https://office.sultraprov.go.id','.',$templateFinal));
				$html2pdf->output($_SERVER['DOCUMENT_ROOT'].'/upload/mail/'.$namePDF.'.pdf', 'F');
				$finalFilesName = $namePDF.'.pdf';
			}

			// data for table: mail
			$data = [
				'number'              => xssprint($this->request->getVar('number')),
				'agenda'              => xssprint($this->request->getVar('agenda')),
				'date'                => xssprint($this->request->getVar('date')),
				'about'               => xssprint($this->request->getVar('about')),
				'summary'             => xssprint($this->request->getVar('summary')),
				'template'            => $this->request->getVar('template'),
				'template_attachment' => $this->request->getVar('template_attachment'),
				'file'                => $finalFilesName,
				'category'            => xssprint($this->request->getVar('category')),
				'status'              => xssprint($this->request->getVar('status')),
				'sign'                => xssprint($this->request->getVar('sign')),
				'destination_nonskpd' => xssprint($this->request->getVar('destination_nonskpd')),
				'draft_id'            => xssprint($this->request->getVar('draft_id')),
				'skpd_id'             => xssprint($this->request->getVar('skpd_id')),
			];

			// if action update, push id
			($action == 'update') ? $data += ['id' => $this->request->getVar('id')] : '';
			
			// save data
			$this->mailModel->save($data);

			// Unlink file if update action needed
			if ($action == 'update') {
				if (file_exists('upload/mail/'.$this->request->getVar('old_file'))) {
					unlink('upload/mail/'.$this->request->getVar('old_file'));
				}
				
				$this->mailreceiverModel->where('mail_id', $this->request->getVar('id'))->delete();
			}

			
			// data for table: mail_receiver
			$mailID = ($action == 'create') ? $this->mailModel->getInsertID() : $this->request->getVar('id');
			if($this->request->getVar('receiver')) {
				for($receiver = 0; $receiver < count($this->request->getVar('receiver')); $receiver ++ ) {
					$dataReceiver = [
						'skpd_id' => xssprint($this->request->getVar('receiver')[$receiver]),
						'mail_id' => $mailID,
						'status'  => 'validasi',
					];
	
					$this->mailreceiverModel->save($dataReceiver);
				}
			}

			// QrGenerate
			// $fileURL = 'https://office.sultraprov.go.id/upload/mail/'.$finalFilesName;
			$fileURL = base_url().'/page/verification_file/'.$mailID;
			$qrName  = $mailID;

			$this->qrGenerator($fileURL, $qrName);

			// merge Qrcode
			// $this->mergeImage($qrName);
			
			// create alert and log
			$message = session('user_name') ." berhasil melakukan $action data surat";
			setAlert('success', $message);
			createLog($message, $this->request->getIPAddress(), session('user_id'));

			// redirect
			if ($action == 'create') {
				// redirect based on mail category [out, out_nonskpd, in_skpd]
				if ($this->request->getVar('category') == 'out' OR $this->request->getVar('category') == 'out_nonskpd') {
					return redirect()->to('admin/outbox/index/'.$this->request->getVar('category').'/draft');
				} else {
					return redirect()->to('admin/inbox/index/'.$this->request->getVar('category').'/draft');
				}
			} else {
				if ($this->request->getVar('category') == 'out' OR $this->request->getVar('category') == 'out_nonskpd') {
					return redirect()->to('admin/disposition/detail/'.$this->request->getVar('category').'/perbaikan/'.$this->request->getVar('id'));
				}
			}
		}
	}

	public function qrGenerator($fileURL, $qrName)
	{
		$writer = new PngWriter();

		$qrCode = QrCode::create($fileURL)
						->setEncoding(new Encoding('UTF-8'))
						->setErrorCorrectionLevel(new ErrorCorrectionLevelLow())
						->setSize(100)
						->setMargin(0)
						->setRoundBlockSizeMode(new RoundBlockSizeModeMargin())
						->setForegroundColor(new Color(0, 0, 0))
    					->setBackgroundColor(new Color(255, 255, 255));

		// Create generic logo
		$logo = Logo::create($_SERVER['DOCUMENT_ROOT'].'/upload/bsre.png')
					->setResizeToWidth(20);

		$result = $writer->write($qrCode, $logo);
		$result->saveToFile($_SERVER['DOCUMENT_ROOT'].'/upload/mail/qrcode/'.$qrName.'.png');

	}

	public function mergeImage($qrName)
	{
		$cover_tte = new Image($_SERVER['DOCUMENT_ROOT'].'/upload/tte.png');
		$qrcode    = new Image($_SERVER['DOCUMENT_ROOT'].'/upload/mail/qrcode/'.$qrName.'.png');

		$cover_tte->merge($qrcode,0,0);
		$cover_tte->save('./upload/mail/qrcode/'.$qrName.'.png', IMAGETYPE_PNG);
	}

	
}
