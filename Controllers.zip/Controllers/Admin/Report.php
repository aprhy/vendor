<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\MaildispositionModel;
use App\Models\MailModel;
use App\Models\MailreceiverModel;
use App\Models\SkpdModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Color;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use PhpOffice\PhpSpreadsheet\Writer\Xls;

class Report extends BaseController
{
	protected $mailModel, $mailreceiverModel, $maildispositionModel, $skpdModel;
	protected $spreadsheet, $objdrawing, $writer;
	protected $url          = 'admin/report';
	protected $allowedRoles = [1,3];

	public function __construct()
	{
		$this->mailModel            = new MailModel();
		$this->mailreceiverModel    = new MailreceiverModel();
		$this->maildispositionModel = new MaildispositionModel();
		$this->skpdModel            = new SkpdModel();

		
		$this->spreadsheet = new Spreadsheet();
		$this->objdrawing = new Drawing();
		$this->writer = new Xls($this->spreadsheet);

		if (!in_array(session('user_role') , $this->allowedRoles)) {
			echo view('templates/layouts/access_denied',[
				'title' => 'Access Denied'
			]);
			exit;
		}
	}

	public function index()
	{
		return view('admin/report/index',[
			'title'    => 'Laporan',
			'setting'  => getSetting(),
			'dataSkpd' => $this->skpdModel->fetchData()->findAll(),
		]);
	}

	public function regenerateTitle($category)
	{
		if ($category == 'out') {
			$title = 'Surat Keluar SKPD';
		} elseif ($category == 'out_nonskpd') {
			$title = 'Surat Keluar Non-SKPD';
		} elseif ($category == 'in') {
			$title = 'Surat Masuk SKPD';
		} elseif ($category == 'in_nonskpd') {
			$title = 'Surat Masuk Non-SKPD';
		}

		return $title;
	}

	public function print()
	{
		$category = $this->request->getVar('category');
		$skpd     = $this->request->getVar('skpd');
		$month    = $this->request->getVar('month');
		$year     = $this->request->getVar('year');
		$skpdData = $this->skpdModel->where('id', $skpd)->find();


		if ($category == 'in') {
			$data = $this->mailModel->fetchDataInbox(false, $skpd)->findAll();
		} else {
			$data = $this->mailModel->fetchData($category, false, $skpd)->findAll();
		}

		

		// FILE NAME
		$fileName ='Data.xls';

		// SPREADSHEET GENERATE
		$this->spreadsheet->getActiveSheetIndex(0);
		$this->spreadsheet->getActiveSheet()->setTitle('Tes');

		// LOGO
		$this->objdrawing
				->setName('LOGO')
				->setPath('./upload/logo.png')
				->setCoordinates('A1')
				->setHeight(60)
				->setWidth(60)
				->setWorksheet($this->spreadsheet->getActiveSheet());
		
		// TITLE
		$this->spreadsheet->getActiveSheet()->mergeCells('A1:E1');
		$this->spreadsheet->getActiveSheet()->setCellValue('A1', 'PEMERINTAH PROVINSI SULAWESI TENGGARA');

		$this->spreadsheet->getActiveSheet()->mergeCells('A2:E2');
		$this->spreadsheet->getActiveSheet()->setCellValue('A2', strtoupper($skpdData[0]['name']));

		$this->spreadsheet->getActiveSheet()->mergeCells('A3:E3');
		$this->spreadsheet->getActiveSheet()->setCellValue('A3', $skpdData[0]['address']);
		
		
		// SUB TITLE
		$this->spreadsheet->getActiveSheet()->mergeCells('A5:E5');
		$this->spreadsheet->getActiveSheet()->setCellValue('A5', strtoupper($this->regenerateTitle($category)));

		// COLUMN HEADER
		$columnWidth = ["A" => 6, "B" => 40, "C" => 30, "D" => 30, "E" => 40];
		$columnName  = [
			"A" => "NO", 
			"B" => "NO SURAT",
			"C" => "PERIHAL",
			"D" => "STATUS",
			"E" => ($category == 'in' OR $category == 'in_nonskpd') ? "PENGIRIM" : "PENANDATANGAN",
		];

		foreach ($columnName as $key => $value) {
			$this->spreadsheet->getActiveSheet()->setCellValue($key."7", $value);
			$this->spreadsheet->getActiveSheet()->getColumnDimension($key)->setWidth($columnWidth[$key]);
		}

		// COLUMN BODY
		$row = 8;
		$no  = 1;
		foreach ($data as $dt) {
			$this->spreadsheet->getActiveSheet()->setCellValue("A".$row, $no);
			$this->spreadsheet->getActiveSheet()->setCellValue("B".$row, $dt['number']);
			$this->spreadsheet->getActiveSheet()->setCellValue("C".$row, $dt['about']);
			$this->spreadsheet->getActiveSheet()->setCellValue("D".$row, ($category == 'in') ? $dt['mail_status'] : $dt['status']);
			$this->spreadsheet->getActiveSheet()->setCellValue("E".$row, ($category == 'in' OR $category == 'in_nonskpd') ? (($category == 'in') ? $dt['skpd_sender']: $dt['destination_nonskpd']) : $dt['sign']);

			$row++;
			$no++;
		}

		/**
		 * ALL STYLE HERE
		 * set title for every style generate
		 */

		// style for title
		$this->spreadsheet->getActiveSheet()->getStyle('A1:E3')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
		$this->spreadsheet->getActiveSheet()->getStyle('A1:E2')->getFont()->setBold(true)->setSize(16);
		$this->spreadsheet->getActiveSheet()->getStyle('A3:E3')->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THICK)->setColor(new Color('000'));

		// style fot sub-title
		$this->spreadsheet->getActiveSheet()->getStyle('A5:E5')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
		$this->spreadsheet->getActiveSheet()->getStyle('A5:E5')->getFont()->setBold(true)->setSize(16);

		// style for column header
		$this->spreadsheet->getActiveSheet()->getStyle('A7:E7')->getFont()->setBold(true);
		$this->spreadsheet->getActiveSheet()->getStyle('A7:E7')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

		// style for table
		$this->spreadsheet->getActiveSheet()->getStyle('A7:E' . ($row-1))->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN)->setColor(new Color('000'));
		$this->spreadsheet->getActiveSheet()->getStyle('A7:E' . ($row-1))->getAlignment()->setWrapText(true);
		ob_end_clean();

		header('Content-Type: application/vnd.ms-excel');
		header('Content-Disposition: attachment;filename="' . $fileName . '"');
		header('Cache-Control: max-age=0');
				
		$this->writer->save('php://output');

	}


}
