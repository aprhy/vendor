<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Dbutility extends BaseController
{
	protected $allowedRoles = [1];
	
	public function __construct()
	{
		if (!in_array(session('user_role') , $this->allowedRoles)) {
			echo view('templates/layouts/access_denied',[
				'title' => 'Access Denied'
			]);
			exit;
		}
	}

	public function index()
	{
		return view('admin/dbutility',[
			'title'   => 'DB Utility',
			'setting' => getSetting()
		]);
	}

	public function backupDB()
	{

	}

	public function restoreDB()
	{

	}
}
