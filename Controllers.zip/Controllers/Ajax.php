<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\MaildispositionModel;
use App\Models\MailModel;
use App\Models\PositionModel;

class Ajax extends BaseController
{
	protected $positionModel, $maildispositionModel, $mailModel;

	public function __construct()
	{
		$this->positionModel        = new PositionModel();
		$this->mailModel            = new MailModel();
		$this->maildispositionModel = new MaildispositionModel();
	}

	public function index()
	{
		//
		echo 'This Ajax Page';
	}

	public function getPositionDataBySkpd()
	{
		if ($this->request->isAJAX()) {
			$skpd = $this->request->getVar('skpd');
			$data = $this->positionModel->fetchData($skpd)->findAll();

			$result ='<option value="">:: Pilih Jabatan ::</option>';
			foreach ($data as $key) {
				$result .= '<option value="'.$key['id'].'">'.$key['name'].'</option>';
			}

			echo $result;
		}
	}


	public function getDispositionNotif($userID)
	{
		if ($this->request->isAJAX()) {
			$data = [
				'total'       => $this->maildispositionModel->fetchData(false, false, 'proses', $userID)->countAllResults(),
				'out'         => $this->maildispositionModel->fetchData(false, 'out', 'proses', $userID)->countAllResults(),
				'in'          => $this->maildispositionModel->fetchData(false, 'in', 'proses', $userID)->countAllResults(),
				'out_nonskpd' => $this->maildispositionModel->fetchData(false, 'out_nonskpd', 'proses', $userID)->countAllResults(),
				'in_nonskpd'  => $this->maildispositionModel->fetchData(false, 'in_nonskpd', 'proses', $userID)->countAllResults(),
			];

			echo json_encode($data);
		}
	}

	public function getDispositionRepair($userID)
	{
		if ($this->request->isAJAX()) {
			$data = [
				'total'       => $this->maildispositionModel->fetchData(false, false, 'perbaikan', $userID)->countAllResults(),
				'out'         => $this->maildispositionModel->fetchData(false, 'out', 'perbaikan', $userID)->countAllResults(),
				'out_nonskpd' => $this->maildispositionModel->fetchData(false, 'out_nonskpd', 'perbaikan', $userID)->countAllResults(),
			];

			echo json_encode($data);
		}
	}

	public function getInboxNotif($skpdID)
	{
		if ($this->request->isAJAX()) {
			echo json_encode($this->mailModel->fetchDataInbox('validasi', $skpdID)->countAllResults());
		}
	}

}
