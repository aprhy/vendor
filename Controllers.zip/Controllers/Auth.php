<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\AuthModel;
use Config\Services;

class Auth extends BaseController
{
	
	protected $authModel, $skpdModel;
	protected $url             = 'auth';
	protected $validationRules = [
		'username' => [
			'rules'  => 'required',
			'errors' => ['required' => 'Username tidak boleh kosong']
		],
		'password' => [
			'rules'  => 'required',
			'errors' => ['required' => 'Password tidak boleh kosong']
		]
	];

	public function __construct()
	{
		$this->authModel = new AuthModel();
	}


	public function index()
	{
		if(session()->get('user_id')){
			return redirect()->to('home');
		}else{
			return view('auth/index', [
				'title'      => 'Login',
				'setting'    => getSetting(),
				'validation' => Services::validation()
			]);
		}
	}

	public function forget_password()
	{
		return view('auth/forget_password', [
			'title'   => 'Lupa Password',
			'setting' => getSetting()
		]);
	}

	public function validate_login()
	{
		$username = xssprint(trim($this->request->getVar('username')));
		$password = xssprint(trim($this->request->getVar('password')));

		if (!$this->validate($this->validationRules)) {
			return redirect()->to($this->url)->withInput();
		} else {
			$result =  $this->authModel->getAuth($username)->first();

			if ($result) {
				if (password_verify($password, $result['password'])) {
					session()->set([
						'user_id'           => $result['id'],
						'user_name'         => $result['username'],
						'user_password'     => $result['password'],
						'user_fullname'     => $result['fullname'],
						'user_photo'        => $result['photo'],
						'user_email'        => $result['email'],
						'user_nip'          => $result['nip'],
						'user_unit'         => $result['unit'],
						'user_status'       => $result['status'],
						'user_role'         => $result['role_id'],
						'user_rolename'     => $result['role'],
						'user_skpd'         => $result['skpd_id'],
						'user_skpdname'     => $result['skpd_name'],
						'user_position'     => $result['position_id'],
						'user_positionname' => $result['position_name'],
						'user_leader'       => $result['leader'],
					]);

					$this->authModel->save([
						'id'        => $result['id'],
						'lastlogin' => date('Y-m-d H:i:s')
					]);

					$message = $result['username'] ." melakukan login ke sistem";
					createLog($message, $this->request->getIPAddress(), $result['id']);

					return redirect()->to('admin/dashboard/');
				} else {
					$message = 'username atau password anda salah !';
					setAlert('failed', $message);
					
					return redirect()->to($this->url);
				}
			} else {
				$message = 'Akun tidak valid !';
				setAlert('failed', $message);

				return redirect()->to($this->url);
			}
		}
	}

	public function logout()
	{
		session()->destroy();
		return redirect()->to($this->url);
	}
}
