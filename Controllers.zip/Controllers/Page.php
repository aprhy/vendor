<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\MailModel;
use App\Models\MailreceiverModel;

class Page extends BaseController
{
	protected $mailModel, $mailreceiverModel;

	public function __construct()
	{
		$this->mailModel            = new MailModel();
		$this->mailreceiverModel    = new MailreceiverModel();
	}
	
	public function index()
	{
		return redirect()->to('home');
	}

	public function contact()
	{
		return view('templates/page/contact', [
			'title'   => 'Kontak',
			'setting' => getSetting()
		]);
	}

	public function privacy_policy()
	{
		return view('templates/page/privacy-policy', [
			'title'   => 'Privacy Policy',
			'setting' => getSetting()
		]);
	}

	public function verification_file($id = null)
	{
		$file = $this->mailModel->where('id', $id)->find();
		
		return view('templates/page/verification_file', [
			'title' 		=> 'Verifikasi File Surat',
			'setting' 		=> getSetting(),
			'data'          => $this->mailModel->join('tbl_skpd','tbl_skpd.id=tbl_mail.skpd_id', 'left')->where('tbl_mail.id',$id)->find(),
			'dataReceiver'	=> $this->mailreceiverModel->fetchData($id)->findAll(),
			'tteStatus'     => ($file) ? $this->verificationFile('./upload/mail/'.$file[0]['file']) : '',
		]);
	}

	public function verificationFile($path)
	{
        $exec   = shell_exec("java -jar esign_client.jar -m verifikasi -f $path");
        $output = json_decode($exec, TRUE);

        return $output;
	}
}
