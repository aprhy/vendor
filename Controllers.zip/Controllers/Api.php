<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\TokenapiModel;
use App\Models\AuthModel;
use App\Models\MaildispositionModel;
use App\Models\MailModel;
use App\Models\MailreceiverModel;
use App\Models\PositionModel;

class Api extends ResourceController
{
    use ResponseTrait;
    protected $authModel;

    public function __construct()
    {
        $this->tokenapiModel        = new TokenapiModel();
        $this->authModel            = new AuthModel();
        $this->mailModel            = new MailModel();
        $this->mailreceiverModel    = new MailreceiverModel();
        $this->maildispositionModel = new MaildispositionModel();
        $this->positionModel        = new PositionModel();
    }

    public function get_access_token()
    {
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
        $client_id     = $this->request->getGet('client_id');
        $client_secret = $this->request->getGet('client_secret');
        $cek           = $this->tokenapiModel->check_token($client_id, $client_secret)->first();
        // print_r($cek);
        // die;
        if ($cek) {
            if ($cek['validity_time'] == '0000-00-00 00:00:00') {
                /* This Function Running if firstime using API */
                $token                 = sha1(mt_rand(1, 90000) . 'SALT');
                $validity              = 3600;
                $data['client_id']     = $cek['client_id'];
                $data['access_token']  = $token;
                $data['validity_time'] = date('Y-m-d H:i:s', strtotime('+1 hour', strtotime(date('Y-m-d H:i:s'))));

                $this->tokenapiModel->save($data);
            } else {
                $validity = strtotime($cek['validity_time']) - time();
                if ($validity < 0) {
                    $token                 = sha1(mt_rand(1, 90000) . 'SALT');
                    $validity              = 3600;
                    $data['client_id']     = $cek['client_id'];
                    $data['access_token']  = $token;
                    $data['validity_time'] = date('Y-m-d H:i:s', strtotime('+1 hour', strtotime(date('Y-m-d H:i:s'))));
                    $this->tokenapiModel->save($data);
                } else {
                    $token    = $cek['access_token'];
                    $validity = strtotime($cek['validity_time']) - time();
                }
            }
            $resultData = array(
                'respon_code'  => 'RC200',
                'status'       => true,
                'message'      => 'success',
                'access_token' => $token,
                'validity'     => $validity,
            );
        } else {
            $resultData = array(
                'respon_code' => 'RC200',
                'status'      => 0,
                'message'     => 'Oops. Mungkin ada yang salah dengan akun token anda',
            );
        }
        return $this->respond($resultData);
    }

    public function login_account()
    {
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
        $headers = apache_request_headers();
        if (isset($headers['Access-Token'])) {
            $cek = $this->tokenapiModel->check_token_validity($headers['Access-Token'])->first();
            if ($cek) {
                $validity = strtotime($cek['validity_time']) - time();
                if ($validity < 0) {
                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 0,
                        'message'     => 'Oops. Token Expired',
                    );
                } else {
                    $username = $this->request->getPost('username');
                    $password = $this->request->getPost('password');

                    $result =  $this->authModel->getAuth($username)->first();
                    if ($result) {
                        if (password_verify($password, $result['password'])) {

                            $resultData  = array(
                                'respon_code' => 'RC200',
                                'status'      => 1,
                                'message'     => $result['username']
                            );
                        } else {
                            $resultData = array(
                                'respon_code' => 'RC200',
                                'status'      => 1,
                                'message'     => 'Password Salah.',
                            );
                        }
                    } else {
                        $resultData = array(
                            'respon_code' => 'RC200',
                            'status'      => 0,
                            'message'     => 'Akun Tidak Ditemukan, akun belum terdaftar',
                        );
                    }
                }
            } else {
                $resultData = array(
                    'respon_code' => 'RC200',
                    'status'      => 0,
                    'message'     => 'Oops. Token Tidak Valid',
                );
            }
        } else {
            $resultData = array(
                'respon_code' => 'RC401',
                'status'      => 0,
                'message'     => 'Anda tidak menyertakan atau memiliki Access Token',
            );
        }
        return $this->respond($resultData);
    }

    public function get_profile()
    {
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
        $headers = apache_request_headers();
        if (isset($headers['Access-Token'])) {
            $cek = $this->tokenapiModel->check_token_validity($headers['Access-Token'])->first();
            if ($cek) {
                $validity = strtotime($cek['validity_time']) - time();
                if ($validity < 0) {
                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 0,
                        'message'     => 'Oops. Token Expired',
                    );
                } else {
                    $username = $this->request->getGet('username');
                    $result =  $this->authModel->getAuth($username)->first();
                    $data = $this->positionModel->getBottomPosition($result['position_id'])->find();
                    if ($data) {
                        $status_bawahan = true;
                    } else {
                        $status_bawahan = false;
                    }
                    if ($result) {
                        $resultData  = array(
                            'full_name'     => $result['fullname'],
                            'username'          => $result['nip'],
                            'opd'         => $result['skpd_name'],
                            'jabatan'       => $result['position_name'],
                            'opd_id'         => $result['skpd_id'],
                            'jabatan_id'     => $result['position_id'],
                            'status_atasan'       => $result['parent'],
                            'status_bawahan'       => $status_bawahan,
                        );
                    } else {
                        $resultData = array(
                            'respon_code' => 'RC200',
                            'status'      => 0,
                            'message'     => 'Data Kosong',
                        );
                    }
                }
            } else {
                $resultData = array(
                    'respon_code' => 'RC200',
                    'status'      => 0,
                    'message'     => 'Oops. Token Tidak Valid',
                );
            }
        } else {
            $resultData = array(
                'respon_code' => 'RC401',
                'status'      => 0,
                'message'     => 'Anda tidak menyertakan atau memiliki Access Token',
            );
        }

        return $this->respond($resultData);
    }

    public function change_password()
    {
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
        $headers = apache_request_headers();
        if (isset($headers['Access-Token'])) {
            $cek = $this->tokenapiModel->check_token_validity($headers['Access-Token'])->first();
            if ($cek) {
                $validity = strtotime($cek['validity_time']) - time();
                if ($validity < 0) {
                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 0,
                        'message'     => 'Oops. Token Expired',
                    );
                } else {
                    $username = $this->request->getGet('username');
                    $result =  $this->authModel->getAuth($username)->first();

                    $data['id']             = $result['id'];
                    $data['password']       = password_hash($result['nip'], PASSWORD_BCRYPT);
                    $this->authModel->save($data);
                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 1,
                        'message'     => 'Password Baru Terkonfirmasi dan Terupdate',
                    );
                }
            } else {
                $resultData = array(
                    'respon_code' => 'RC200',
                    'status'      => 0,
                    'message'     => 'Oops. Token Tidak Valid',
                );
            }
        } else {
            $resultData = array(
                'respon_code' => 'RC401',
                'status'      => 0,
                'message'     => 'Anda tidak menyertakan atau memiliki Access Token',
            );
        }

        return $this->respond($resultData);
    }

    public function outbox_opd()
    {
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
        $headers = apache_request_headers();
        if (isset($headers['Access-Token'])) {
            $cek = $this->tokenapiModel->check_token_validity($headers['Access-Token'])->first();
            if ($cek) {
                $validity = strtotime($cek['validity_time']) - time();
                if ($validity < 0) {
                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 0,
                        'message'     => 'Oops. Token Expired',
                    );
                } else {
                    $username = $this->request->getGet('username');
                    $result =  $this->authModel->getAuth($username)->first();

                    $surat = $this->maildispositionModel->api_fetchData(false, 'out', 'proses', $result['id'])->findAll();


                    if ($surat) {
                        foreach ($surat as $s) {
                            $suratTujuan = [];
                            $suratByNosurat    = $this->mailModel->api_fetchDataInbox($s['mail_id'])->findAll();
                            // print_r($suratByNosurat);
                            // die;
                            foreach ($suratByNosurat as $sbn) {
                                $suratTujuan[] = array(
                                    'receiver_id'       => '',
                                    'id_surat'          => $sbn['mail_id'],
                                    'opd'               => $sbn['skpd_receiver']
                                );
                            }
                            $resultData_[] = array(
                                'nomor_surat'       => $s['number'],
                                'nomor_agenda'      => $s['agenda'],
                                'opd_tujuan'        => $suratTujuan,
                                'tanggal_terima'    => $s['created_at'],
                                'tanggal_surat'     => $s['date'],
                                'file_surat'        => $s['file'],
                                'disposisi_status'  => $s['status'],
                                'surat_status'      => $s['mail_status'],
                                'disposisi_id'      => $s['id'],
                                'kategori_surat'    => 'out',
                                'tipe_surat'        => $s['sign']
                            );
                        }
                        $resultData = array(
                            'respon_code' => '200',
                            'last_update' => $s['created_at'],
                            'mails'       => $resultData_,
                        );
                    } else {
                        $resultData = array(
                            'respon_code' => '200',
                            'last_update' => "0000-00-00 00:00:00",
                            'mails'       => [],
                        );
                    }
                }
            } else {
                $resultData = array(
                    'respon_code' => 'RC200',
                    'status'      => 0,
                    'message'     => 'Oops. Token Tidak Valid',
                );
            }
        } else {
            $resultData = array(
                'respon_code' => 'RC401',
                'status'      => 0,
                'message'     => 'Anda tidak menyertakan atau memiliki Access Token',
            );
        }

        return $this->respond($resultData);
    }

    public function inbox_opd()
    {
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
        $headers = apache_request_headers();
        if (isset($headers['Access-Token'])) {
            $cek = $this->tokenapiModel->check_token_validity($headers['Access-Token'])->first();
            if ($cek) {
                $validity = strtotime($cek['validity_time']) - time();
                if ($validity < 0) {
                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 0,
                        'message'     => 'Oops. Token Expired',
                    );
                } else {
                    $username = $this->request->getGet('username');
                    $result =  $this->authModel->getAuth($username)->first();

                    $surat = $this->maildispositionModel->api_fetchData(false, 'in', 'proses', $result['id'])->findAll();
                    // print_r($result['skpd_id']);
                    // die;

                    if ($surat) {
                        foreach ($surat as $s) {
                            $suratTujuan = [];
                            $suratByNosurat    = $this->mailModel->api_fetchDataInbox($s['mail_id'], $result['skpd_id'])->findAll();
                            foreach ($suratByNosurat as $sbn) {
                                $suratTujuan[] = array(
                                    'receiver_id'       => $sbn['id'],
                                    'id_surat'          => $sbn['mail_id'],
                                    'opd'               => $sbn['skpd_sender']
                                );
                            }
                            $resultData_[] = array(
                                'nomor_surat'       => $s['number'],
                                'nomor_agenda'      => $s['agenda'],
                                'opd_tujuan'        => $suratTujuan,
                                'tanggal_terima'    => $s['created_at'],
                                'tanggal_surat'     => $s['date'],
                                'file_surat'        => $s['file'],
                                'disposisi_status'  => $s['status'],
                                'surat_status'      => $s['mail_status'],
                                'disposisi_id'      => $s['id'],
                                'kategori_surat'    => 'in',
                                'tipe_surat'        => $s['sign']
                            );
                        }
                        $resultData = array(
                            'respon_code' => '200',
                            'last_update' => $s['created_at'],
                            'mails'       => $resultData_
                        );
                    } else {
                        $resultData = array(
                            'respon_code' => '200',
                            'last_update' => "0000-00-00 00:00:00",
                            'mails'       => []
                        );
                    }
                }
            } else {
                $resultData = array(
                    'respon_code' => 'RC200',
                    'status'      => 0,
                    'message'     => 'Oops. Token Tidak Valid',
                );
            }
        } else {
            $resultData = array(
                'respon_code' => 'RC401',
                'status'      => 0,
                'message'     => 'Anda tidak menyertakan atau memiliki Access Token',
            );
        }

        return $this->respond($resultData);
    }

    public function outbox_non_opd()
    {
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
        $headers = apache_request_headers();
        if (isset($headers['Access-Token'])) {
            $cek = $this->tokenapiModel->check_token_validity($headers['Access-Token'])->first();
            if ($cek) {
                $validity = strtotime($cek['validity_time']) - time();
                if ($validity < 0) {
                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 0,
                        'message'     => 'Oops. Token Expired',
                    );
                } else {
                    $username = $this->request->getGet('username');
                    $result =  $this->authModel->getAuth($username)->first();

                    $surat = $this->maildispositionModel->api_fetchData(false, 'out_nonskpd', 'proses', $result['id'])->findAll();

                    if ($surat) {
                        foreach ($surat as $s) {

                            $suratTujuan = [];
                            $suratTujuan[] = array(
                                'receiver_id'       => '',
                                'id_surat'          => $s['mail_id'],
                                'opd'               => $s['destination_nonskpd']
                            );
                            $resultData_[] = array(
                                'nomor_surat'       => $s['number'],
                                'nomor_agenda'      => $s['agenda'],
                                'opd_tujuan'        => $suratTujuan,
                                'tanggal_terima'    => $s['created_at'],
                                'tanggal_surat'     => $s['date'],
                                'file_surat'        => $s['file'],
                                'disposisi_status'  => $s['status'],
                                'surat_status'      => $s['mail_status'],
                                'disposisi_id'      => $s['id'],
                                'kategori_surat'    => 'out_nonskpd',
                                'tipe_surat'        => $s['sign']
                            );
                        }
                        $resultData = array(
                            'respon_code' => '200',
                            'last_update' => $s['created_at'],
                            'mails'       => $resultData_,
                        );
                    } else {
                        $resultData = array(
                            'respon_code' => '200',
                            'last_update' => "0000-00-00 00:00:00",
                            'mails'       => [],
                        );
                    }
                }
            } else {
                $resultData = array(
                    'respon_code' => 'RC200',
                    'status'      => 0,
                    'message'     => 'Oops. Token Tidak Valid',
                );
            }
        } else {
            $resultData = array(
                'respon_code' => 'RC401',
                'status'      => 0,
                'message'     => 'Anda tidak menyertakan atau memiliki Access Token',
            );
        }

        return $this->respond($resultData);
    }

    public function inbox_non_opd()
    {
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
        $headers = apache_request_headers();
        if (isset($headers['Access-Token'])) {
            $cek = $this->tokenapiModel->check_token_validity($headers['Access-Token'])->first();
            if ($cek) {
                $validity = strtotime($cek['validity_time']) - time();
                if ($validity < 0) {
                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 0,
                        'message'     => 'Oops. Token Expired',
                    );
                } else {
                    $username = $this->request->getGet('username');
                    $result =  $this->authModel->getAuth($username)->first();

                    $surat = $this->maildispositionModel->api_fetchData(false, 'in_nonskpd', 'proses', $result['id'])->findAll();

                    if ($surat) {
                        foreach ($surat as $s) {
                            $suratTujuan = [];
                            $suratTujuan[] = array(
                                'receiver_id'       => '',
                                'id_surat'          => $s['mail_id'],
                                'opd'               => $s['destination_nonskpd']
                            );
                            $resultData_[] = array(
                                'nomor_surat'       => $s['number'],
                                'nomor_agenda'      => $s['agenda'],
                                'opd_tujuan'        => $suratTujuan,
                                'tanggal_terima'    => $s['created_at'],
                                'tanggal_surat'     => $s['date'],
                                'file_surat'        => $s['file'],
                                'disposisi_status'  => $s['status'],
                                'surat_status'      => $s['mail_status'],
                                'disposisi_id'      => $s['id'],
                                'kategori_surat'    => 'in_nonskpd',
                                'tipe_surat'        => $s['sign']
                            );
                        }
                        $resultData = array(
                            'respon_code' => '200',
                            'last_update' => $s['created_at'],
                            'mails'       => $resultData_,
                        );
                    } else {
                        $resultData = array(
                            'respon_code' => '200',
                            'last_update' => "0000-00-00 00:00:00",
                            'mails'       => [],
                        );
                    }
                }
            } else {
                $resultData = array(
                    'respon_code' => 'RC200',
                    'status'      => 0,
                    'message'     => 'Oops. Token Tidak Valid',
                );
            }
        } else {
            $resultData = array(
                'respon_code' => 'RC401',
                'status'      => 0,
                'message'     => 'Anda tidak menyertakan atau memiliki Access Token',
            );
        }

        return $this->respond($resultData);
    }

    public function get_monitoring()
    {
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
        $headers = apache_request_headers();
        if (isset($headers['Access-Token'])) {
            $cek = $this->tokenapiModel->check_token_validity($headers['Access-Token'])->first();
            if ($cek) {
                $validity = strtotime($cek['validity_time']) - time();
                if ($validity < 0) {
                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 0,
                        'message'     => 'Oops. Token Expired',
                    );
                } else {
                    $username = $this->request->getGet('username');
                    $result =  $this->authModel->getAuth($username)->first();

                    $category    = $this->request->getGet('category');
                    $date    = $this->request->getGet('date');
                    if ($category == 'in') {
                        $surat = $this->maildispositionModel->api_fetchData(false, 'in', false, false, false, $date)->findAll();
                        if ($surat) {
                            foreach ($surat as $s) {
                                $resultData_[] = array(
                                    'id_surat'          => $s['mail_id'],
                                    'nomor_surat'       => $s['number'],
                                    'nomor_agenda'      => $s['agenda'],
                                    'opd'               => $s['skpd_asal_nama'],
                                    'tanggal_terima'    => $s['created_at'],
                                    'tanggal_surat'     => $s['date'],
                                    'file_surat'        => $s['file'],
                                    'tujuan_disposisi'  => $s['position_receiver'],
                                    'disposisi_status'  => $s['status'],
                                    'kategori_surat'    => $category
                                );
                            }
                            $resultData = array(
                                'respon_code' => '200',
                                'last_update' => $s['created_at'],
                                'mails'       => $resultData_,
                            );
                        } else {
                            $resultData = array(
                                'respon_code' => '200',
                                'last_update' => "0000-00-00 00:00:00",
                                'mails'       => [],
                            );
                        }
                    } else if ($category == 'out') {
                        $surat = $this->maildispositionModel->api_fetchData(false, 'out', false, false, false, $date)->findAll();
                        if ($surat) {
                            foreach ($surat as $s) {
                                $resultData_[] = array(
                                    'id_surat'          => $s['mail_id'],
                                    'nomor_surat'       => $s['number'],
                                    'nomor_agenda'      => $s['agenda'],
                                    'opd'               => $s['skpd_tujuan_nama'],
                                    'tanggal_terima'    => $s['created_at'],
                                    'tanggal_surat'     => $s['date'],
                                    'file_surat'        => $s['file'],
                                    'tujuan_disposisi'  => $s['position_receiver'],
                                    'disposisi_status'  => $s['status'],
                                    'kategori_surat'    => $category
                                );
                            }
                            $resultData = array(
                                'respon_code' => '200',
                                'last_update' => $s['created_at'],
                                'mails'       => $resultData_,
                            );
                        } else {
                            $resultData = array(
                                'respon_code' => '200',
                                'last_update' => "0000-00-00 00:00:00",
                                'mails'       => [],
                            );
                        }
                    } else if ($category == 'in_nonskpd') {
                        $surat = $this->maildispositionModel->api_fetchData(false, 'in_nonskpd', false, false, false, $date)->findAll();
                        if ($surat) {
                            foreach ($surat as $s) {
                                $resultData_[] = array(
                                    'id_surat'          => $s['mail_id'],
                                    'nomor_surat'       => $s['number'],
                                    'nomor_agenda'      => $s['agenda'],
                                    'opd'               => $s['destination_nonskpd'],
                                    'tanggal_terima'    => $s['created_at'],
                                    'tanggal_surat'     => $s['date'],
                                    'file_surat'        => $s['file'],
                                    'tujuan_disposisi'  => $s['position_receiver'],
                                    'disposisi_status'  => $s['status'],
                                    'kategori_surat'    => $category
                                );
                            }
                            $resultData = array(
                                'respon_code' => '200',
                                'last_update' => $s['created_at'],
                                'mails'       => $resultData_,
                            );
                        } else {
                            $resultData = array(
                                'respon_code' => '200',
                                'last_update' => "0000-00-00 00:00:00",
                                'mails'       => [],
                            );
                        }
                    } else {
                        $surat = $this->maildispositionModel->api_fetchData(false, 'out_nonskpd', false, false, false, $date)->findAll();
                        if ($surat) {
                            foreach ($surat as $s) {
                                $resultData_[] = array(
                                    'id_surat'          => $s['mail_id'],
                                    'nomor_surat'       => $s['number'],
                                    'nomor_agenda'      => $s['agenda'],
                                    'opd'               => $s['destination_nonskpd'],
                                    'tanggal_terima'    => $s['created_at'],
                                    'tanggal_surat'     => $s['date'],
                                    'file_surat'        => $s['file'],
                                    'tujuan_disposisi'  => $s['position_receiver'],
                                    'disposisi_status'  => $s['status'],
                                    'kategori_surat'    => $category
                                );
                            }
                            $resultData = array(
                                'respon_code' => '200',
                                'last_update' => $s['created_at'],
                                'mails'       => $resultData_,
                            );
                        } else {
                            $resultData = array(
                                'respon_code' => '200',
                                'last_update' => "0000-00-00 00:00:00",
                                'mails'       => [],
                            );
                        }
                    }
                }
            } else {
                $resultData = array(
                    'respon_code' => 'RC200',
                    'status'      => 0,
                    'message'     => 'Oops. Token Tidak Valid',
                );
            }
        } else {
            $resultData = array(
                'respon_code' => 'RC401',
                'status'      => 0,
                'message'     => 'Anda tidak menyertakan atau memiliki Access Token',
            );
        }

        return $this->respond($resultData);
    }

    public function get_monitoring_selesai()
    {
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
        $headers = apache_request_headers();
        if (isset($headers['Access-Token'])) {
            $cek = $this->tokenapiModel->check_token_validity($headers['Access-Token'])->first();
            if ($cek) {
                $validity = strtotime($cek['validity_time']) - time();
                if ($validity < 0) {
                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 0,
                        'message'     => 'Oops. Token Expired',
                    );
                } else {
                    $username = $this->request->getGet('username');
                    $result =  $this->authModel->getAuth($username)->first();

                    $category    = $this->request->getGet('category');
                    $date    = $this->request->getGet('date');
                    if ($category == 'in') {
                        $surat = $this->maildispositionModel->api_fetchData(false, 'in', 'selesai', false, false, $date)->findAll();
                        if ($surat) {
                            foreach ($surat as $s) {
                                $resultData_[] = array(
                                    'id_surat'          => $s['mail_id'],
                                    'nomor_surat'       => $s['number'],
                                    'nomor_agenda'      => $s['agenda'],
                                    'opd'               => $s['skpd_asal_nama'],
                                    'tanggal_terima'    => $s['created_at'],
                                    'tanggal_surat'     => $s['date'],
                                    'file_surat'        => $s['file'],
                                    'tujuan_disposisi'  => $s['position_receiver'],
                                    'disposisi_status'  => $s['status'],
                                    'kategori_surat'    => $category
                                );
                            }
                            $resultData = array(
                                'respon_code' => '200',
                                'last_update' => $s['created_at'],
                                'mails'       => $resultData_,
                            );
                        } else {
                            $resultData = array(
                                'respon_code' => '200',
                                'last_update' => "0000-00-00 00:00:00",
                                'mails'       => [],
                            );
                        }
                    } else if ($category == 'out') {
                        $surat = $this->maildispositionModel->api_fetchData(false, 'out', 'selesai', false, false, $date)->findAll();
                        if ($surat) {
                            foreach ($surat as $s) {
                                $resultData_[] = array(
                                    'id_surat'          => $s['mail_id'],
                                    'nomor_surat'       => $s['number'],
                                    'nomor_agenda'      => $s['agenda'],
                                    'opd'               => $s['skpd_tujuan_nama'],
                                    'tanggal_terima'    => $s['created_at'],
                                    'tanggal_surat'     => $s['date'],
                                    'file_surat'        => $s['file'],
                                    'tujuan_disposisi'  => $s['position_receiver'],
                                    'disposisi_status'  => $s['status'],
                                    'kategori_surat'    => $category
                                );
                            }
                            $resultData = array(
                                'respon_code' => '200',
                                'last_update' => $s['created_at'],
                                'mails'       => $resultData_,
                            );
                        } else {
                            $resultData = array(
                                'respon_code' => '200',
                                'last_update' => "0000-00-00 00:00:00",
                                'mails'       => [],
                            );
                        }
                    } else if ($category == 'in_nonskpd') {
                        $surat = $this->maildispositionModel->api_fetchData(false, 'in_nonskpd', 'selesai', false, false, $date)->findAll();
                        if ($surat) {
                            foreach ($surat as $s) {
                                $resultData_[] = array(
                                    'id_surat'          => $s['mail_id'],
                                    'nomor_surat'       => $s['number'],
                                    'nomor_agenda'      => $s['agenda'],
                                    'opd'               => $s['destination_nonskpd'],
                                    'tanggal_terima'    => $s['created_at'],
                                    'tanggal_surat'     => $s['date'],
                                    'file_surat'        => $s['file'],
                                    'tujuan_disposisi'  => $s['position_receiver'],
                                    'disposisi_status'  => $s['status'],
                                    'kategori_surat'    => $category
                                );
                            }
                            $resultData = array(
                                'respon_code' => '200',
                                'last_update' => $s['created_at'],
                                'mails'       => $resultData_,
                            );
                        } else {
                            $resultData = array(
                                'respon_code' => '200',
                                'last_update' => "0000-00-00 00:00:00",
                                'mails'       => [],
                            );
                        }
                    } else {
                        $surat = $this->maildispositionModel->api_fetchData(false, 'out_nonskpd', 'selesai', false, false, $date)->findAll();
                        if ($surat) {
                            foreach ($surat as $s) {
                                $resultData_[] = array(
                                    'id_surat'          => $s['mail_id'],
                                    'nomor_surat'       => $s['number'],
                                    'nomor_agenda'      => $s['agenda'],
                                    'opd'               => $s['destination_nonskpd'],
                                    'tanggal_terima'    => $s['created_at'],
                                    'tanggal_surat'     => $s['date'],
                                    'file_surat'        => $s['file'],
                                    'tujuan_disposisi'  => $s['position_receiver'],
                                    'disposisi_status'  => $s['status'],
                                    'kategori_surat'    => $category
                                );
                            }
                            $resultData = array(
                                'respon_code' => '200',
                                'last_update' => $s['created_at'],
                                'mails'       => $resultData_,
                            );
                        } else {
                            $resultData = array(
                                'respon_code' => '200',
                                'last_update' => "0000-00-00 00:00:00",
                                'mails'       => [],
                            );
                        }
                    }
                }
            } else {
                $resultData = array(
                    'respon_code' => 'RC200',
                    'status'      => 0,
                    'message'     => 'Oops. Token Tidak Valid',
                );
            }
        } else {
            $resultData = array(
                'respon_code' => 'RC401',
                'status'      => 0,
                'message'     => 'Anda tidak menyertakan atau memiliki Access Token',
            );
        }

        return $this->respond($resultData);
    }


    public function teruskan_keatasan()
    {
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
        $headers = apache_request_headers();
        if (isset($headers['Access-Token'])) {
            $cek = $this->tokenapiModel->check_token_validity($headers['Access-Token'])->first();
            if ($cek) {
                $validity = strtotime($cek['validity_time']) - time();
                if ($validity < 0) {
                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 0,
                        'message'     => 'Oops. Token Expired',
                    );
                } else {
                    $category = $this->request->getPost('kategori');
                    $username = $this->request->getPost('username');
                    $result =  $this->authModel->getAuth($username)->first();
                    $getTop            = $this->positionModel->getTopPosition($result['position_id'])->find();
                    $getLastDisposition = $this->maildispositionModel->where('id', $this->request->getPost('disposisi_id'))->find();
                    $dispositionCreate = [
                        'from_user'     => $result['id'],
                        'from_position' => $result['position_id'],
                        'to_user'       => $getTop[0]['id'],
                        'to_position'   => $getTop[0]['parent'],
                        'message'       => $this->request->getPost('komentar'),
                        'status'        => 'proses',
                        'category'      => $category,
                        'mail_id'       => $getLastDisposition[0]['mail_id'],
                    ];
                    $this->maildispositionModel->save($dispositionCreate);

                    // disposition update   
                    $dispositionUpdate = [
                        'id'     => $this->request->getPost('disposisi_id'),
                        'status' => 'selesai',
                    ];

                    $this->maildispositionModel->save($dispositionUpdate);

                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 1,
                        'message'     => 'Berhasil Disposisi Surat',
                    );
                }
            } else {
                $resultData = array(
                    'respon_code' => 'RC200',
                    'status'      => 0,
                    'message'     => 'Oops. Token Tidak Valid',
                );
            }
        } else {
            $resultData = array(
                'respon_code' => 'RC401',
                'status'      => 0,
                'message'     => 'Anda tidak menyertakan atau memiliki Access Token',
            );
        }

        return $this->respond($resultData);
    }

    public function surat_perbaikan()
    {
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
        $headers = apache_request_headers();
        if (isset($headers['Access-Token'])) {
            $cek = $this->tokenapiModel->check_token_validity($headers['Access-Token'])->first();
            if ($cek) {
                $validity = strtotime($cek['validity_time']) - time();
                if ($validity < 0) {
                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 0,
                        'message'     => 'Oops. Token Expired',
                    );
                } else {
                    $username = $this->request->getPost('username');
                    $category = $this->request->getPost('kategori');
                    $result =  $this->authModel->getAuth($username)->first();
                    $getLastDisposition = $this->maildispositionModel->where('id', $this->request->getPost('disposisi_id'))->find();

                    $getFirstDisposition = $this->maildispositionModel->where('mail_id', $getLastDisposition[0]['mail_id'])
                        ->where('category', $category)
                        ->orderBy('id', 'ASC')
                        ->limit(1)
                        ->find();
                    $dispositionCreate = [
                        'from_user'     => $result['id'],
                        'from_position' => $result['position_id'],
                        'to_user'       => $getFirstDisposition[0]['from_user'],
                        'to_position'   => $getFirstDisposition[0]['from_position'],
                        'message'       => $this->request->getPost('komentar'),
                        'status'        => 'perbaikan',
                        'category'      => $category,
                        'mail_id'       => $getLastDisposition[0]['mail_id'],
                    ];
                    $this->maildispositionModel->save($dispositionCreate);

                    // disposition update 
                    $dispositionUpdate = [
                        'id'     => $this->request->getPost('disposisi_id'),
                        'status' => 'selesai',
                    ];

                    $this->maildispositionModel->save($dispositionUpdate);

                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 1,
                        'message'     => 'Berhasil, Surat Dikembalikan dan Diperbaiki',
                    );
                }
            } else {
                $resultData = array(
                    'respon_code' => 'RC200',
                    'status'      => 0,
                    'message'     => 'Oops. Token Tidak Valid',
                );
            }
        } else {
            $resultData = array(
                'respon_code' => 'RC401',
                'status'      => 0,
                'message'     => 'Anda tidak menyertakan atau memiliki Access Token',
            );
        }

        return $this->respond($resultData);
    }

    public function surat_tte()
    {
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
        $headers = apache_request_headers();
        if (isset($headers['Access-Token'])) {
            $cek = $this->tokenapiModel->check_token_validity($headers['Access-Token'])->first();
            if ($cek) {
                $validity = strtotime($cek['validity_time']) - time();
                if ($validity < 0) {
                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 0,
                        'message'     => 'Oops. Token Expired',
                    );
                } else {
                    $getLastDisposition = $this->maildispositionModel->where('id', $this->request->getPost('disposisi_id'))->find();
                    $username_tte = $this->request->getPost('username_tte');
                    $password_tte = $this->request->getPost('password_tte');
                    $file         = './upload/mail/' . $this->request->getPost('file');
                    $qrName       = $getLastDisposition[0]['mail_id'] . '.png';

                    // check is user valid
                    $checkUser = $this->accountValidity($username_tte);

                    if ($checkUser['status'] == 'ISSUE') {
                        $result =  $this->signFile($username_tte, $password_tte, $file, $qrName);
                        if ($result['status'] == 'error') {
                            // create alert
                            $message = 'Gagal TTE, ' . $result['message'];
                            $resultData = array(
                                'respon_code' => 'RC200',
                                'status'      => 0,
                                'message'     => $message,
                            );

                            // redirect based on mail category [out, out_nonskpd, in_skpd]
                        } else {

                            unlink($file);
                            rename('./file-sign/SIGNED/' . $result['message'], $file);

                            // SUCCESS TTE
                            $mailUpdate = [
                                'id'     => $getLastDisposition[0]['mail_id'],
                                'status' => 'selesai',
                            ];

                            $this->mailModel->save($mailUpdate);

                            // disposition update 
                            $dispositionUpdate = [
                                'id'     => $this->request->getPost('disposisi_id'),
                                'status' => 'selesai',
                            ];

                            $this->maildispositionModel->save($dispositionUpdate);

                            // create alert and log
                            $message = 'Surat Berhasil Di TTE';
                            $resultData = array(
                                'respon_code' => 'RC200',
                                'status'      => 1,
                                'message'     => $message,
                            );

                            // redirect based on mail category [out, out_nonskpd, in_skpd]
                        }
                    } else {
                        $message = 'Gagal TTE, ' . $checkUser['message'];
                        $resultData = array(
                            'respon_code' => 'RC200',
                            'status'      => 0,
                            'message'     => $message,
                        );
                    }
                }
            } else {
                $resultData = array(
                    'respon_code' => 'RC200',
                    'status'      => 0,
                    'message'     => 'Oops. Token Tidak Valid',
                );
            }
        } else {
            $resultData = array(
                'respon_code' => 'RC401',
                'status'      => 0,
                'message'     => 'Anda tidak menyertakan atau memiliki Access Token',
            );
        }

        return $this->respond($resultData);
    }

    public function teruskan_kebawahan()
    {
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
        $headers = apache_request_headers();
        if (isset($headers['Access-Token'])) {
            $cek = $this->tokenapiModel->check_token_validity($headers['Access-Token'])->first();
            if ($cek) {
                $validity = strtotime($cek['validity_time']) - time();
                if ($validity < 0) {
                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 0,
                        'message'     => 'Oops. Token Expired',
                    );
                } else {
                    $username = $this->request->getPost('username');
                    $category = $this->request->getPost('kategori');
                    $bawahan = json_decode($this->request->getPost('bawahan'));
                    $result =  $this->authModel->getAuth($username)->first();

                    if ($category == 'in_nonskpd') {
                        $data = [
                            'id' => $this->request->getPost('mail_id'),
                            'status' => 'disposisi'
                        ];

                        $this->mailModel->save($data);
                    } else {
                        $data = [
                            'id' => $this->request->getPost('receiver_id'),
                            'status' => 'disposisi'
                        ];
                        $this->mailreceiverModel->save($data);
                    }

                    // create disposition
                    foreach ($bawahan as $key) {
                        $dataDisposition = [
                            'from_user'     => $result['id'],
                            'from_position' => $result['position_id'],
                            'to_user'       => $key->id,
                            'to_position'   => $key->position_id,
                            'message'       => $result['instruksi'] . '-' . $result['instruksi_detail'],
                            'status'        => 'proses',
                            'category'      => $category,
                            'mail_id'       => $this->request->getPost('mail_id'),
                        ];

                        $this->maildispositionModel->save($dataDisposition);
                    }

                    // disposition update 
                    $dispositionUpdate = [
                        'id'     => $this->request->getPost('disposisi_id'),
                        'status' => 'selesai',
                    ];

                    $this->maildispositionModel->save($dispositionUpdate);

                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 1,
                        'message'     => 'Berhasil Disposisi Surat',
                    );
                }
            } else {
                $resultData = array(
                    'respon_code' => 'RC200',
                    'status'      => 0,
                    'message'     => 'Oops. Token Tidak Valid',
                );
            }
        } else {
            $resultData = array(
                'respon_code' => 'RC401',
                'status'      => 0,
                'message'     => 'Anda tidak menyertakan atau memiliki Access Token',
            );
        }

        return $this->respond($resultData);
    }

    public function surat_selesai()
    {
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
        $headers = apache_request_headers();
        if (isset($headers['Access-Token'])) {
            $cek = $this->tokenapiModel->check_token_validity($headers['Access-Token'])->first();
            if ($cek) {
                $validity = strtotime($cek['validity_time']) - time();
                if ($validity < 0) {
                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 0,
                        'message'     => 'Oops. Token Expired',
                    );
                } else {
                    $username = $this->request->getPost('username');
                    $category = $this->request->getPost('kategori');
                    $result =  $this->authModel->getAuth($username)->first();

                    // disposition update 
                    $dispositionUpdate = [
                        'id'     => $this->request->getPost('disposisi_id'),
                        'status' => 'selesai',
                    ];

                    $this->maildispositionModel->save($dispositionUpdate);

                    // check if all state finish
                    $checkAllDisposition = $this->maildispositionModel->countFinishState($this->request->getPost('mail_id'), 'selesai')->countAllResults();

                    if ($checkAllDisposition == 0) {
                        if ($category == 'in_nonskpd') {
                            // Update mail status 
                            $mailUpdate = [
                                'id'     => $this->request->getPost('mail_id'),
                                'status' => 'selesai',
                            ];

                            $this->mailModel->save($mailUpdate);
                        } else {
                            $getReceiverID = $this->mailreceiverModel->where('mail_id', $this->request->getPost('mail_id'))->where('skpd_id', $result['skpd_id'])->find();
                            // Update mail receiver status 
                            $mailUpdate = [
                                'id'     => $getReceiverID[0]['id'],
                                'status' => 'selesai',
                            ];

                            $this->mailreceiverModel->save($mailUpdate);
                        }
                    }

                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 1,
                        'message'     => 'Berhasil melakukan penyelesaian disposisi data surat dari pimpinan',
                    );
                }
            } else {
                $resultData = array(
                    'respon_code' => 'RC200',
                    'status'      => 0,
                    'message'     => 'Oops. Token Tidak Valid',
                );
            }
        } else {
            $resultData = array(
                'respon_code' => 'RC401',
                'status'      => 0,
                'message'     => 'Anda tidak menyertakan atau memiliki Access Token',
            );
        }

        return $this->respond($resultData);
    }

    public function list_bawahan()
    {
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
        $headers = apache_request_headers();
        if (isset($headers['Access-Token'])) {
            $cek = $this->tokenapiModel->check_token_validity($headers['Access-Token'])->first();
            if ($cek) {
                $validity = strtotime($cek['validity_time']) - time();
                if ($validity < 0) {
                    $resultData = array(
                        'respon_code' => 'RC200',
                        'status'      => 0,
                        'message'     => 'Oops. Token Expired',
                    );
                } else {
                    $username = $this->request->getGet('username');
                    $result =  $this->authModel->getAuth($username)->first();

                    $data = $this->positionModel->getBottomPosition($result['position_id'])->find();

                    if ($data) {
                        $resultData  = $data;
                    } else {
                        $resultData = array(
                            'respon_code' => 'RC200',
                            'status'      => 0,
                            'message'     => 'Data Kosong',
                        );
                    }
                }
            } else {
                $resultData = array(
                    'respon_code' => 'RC200',
                    'status'      => 0,
                    'message'     => 'Oops. Token Tidak Valid',
                );
            }
        } else {
            $resultData = array(
                'respon_code' => 'RC401',
                'status'      => 0,
                'message'     => 'Anda tidak menyertakan atau memiliki Access Token',
            );
        }

        return $this->respond($resultData);
    }







    // ===================================================
    // ================== FOR TTE ========================
    // ===================================================

    public function accountValidity($nik)
    {
        $exec   = shell_exec("java -jar esign_client.jar -m cek_status_user -nik $nik");
        $output = json_decode($exec, TRUE);
        var_dump($exec);
        return $output;
    }

    public function signFile($nik, $password, $path, $qrName)
    {
        $pathSign  = './file-sign';
        $pathImage = './upload/mail/qrcode/' . $qrName;

        $exec   = shell_exec("java -jar esign_client.jar -m sign -f $path -p '$password' -nik $nik -t visible -i TRUE -v  $pathImage -page 1 -height 80 -width 550 -x 43 -y 28 -d $pathSign");

        // Sign Visible
        if (preg_match('/error/i', $exec)) {
            $output = json_decode($exec, TRUE);

            $data = [
                'message' => $output['error'],
                'status' => 'error'
            ];
        } else {
            $output    = json_decode($exec, TRUE);
            $delimiter = $_SERVER['DOCUMENT_ROOT'] . '/./file-sign/SIGNED/';
            $data      = [
                'message' => str_replace($delimiter, '', $output),
                'status' => 'success'
            ];
        }

        return $data;
    }

    public function verificationFile($path)
    {
        $exec   = shell_exec("java -jar esign_client.jar -m verifikasi -f $path");
        $output = json_decode($exec, TRUE);

        return $output;
    }

    public function testingsaja()
    {
        $exec = shell_exec("java -Xmx1024m -Xss1024m -jar esign_client.jar -m cek_status_user -nik 0803202100007062");
        $output = json_decode($exec, TRUE);

        var_dump($output);
    }


    // public function forward()
    // {
    //     $action = $this->request->getPost('action');
    //     $status = $this->request->getPost('status');
    //     $username = $this->request->getPost('username');
    //     $category = $this->request->getPost('category');
    //     $result =  $this->authModel->getAuth($username)->first();
    //     $getTop            = $this->positionModel->getTopPosition($result['position_id'])->find();
    //     $getLastDisposition = $this->maildispositionModel->where('id', $this->request->getPost('disposisi_id'))->find();
    //     if ($action == 'forward') {
    //         if ($status != 'perbaikan') {
    //             $dispositionCreate = [
    //                 'from_user'     => $result['id'],
    //                 'from_position' => $result['position_id'],
    //                 'to_user'       => $getTop[0]['id'],
    //                 'to_position'   => $getTop[0]['parent'],
    //                 'message'       => $this->request->getPost('komentar'),
    //                 'status'        => 'proses',
    //                 'category'      => 'out',
    //                 'mail_id'       => $getLastDisposition[0]['mail_id'],
    //             ];
    //         } else {
    //             $getLastDisposition = $this->maildispositionModel->where('id', $this->request->getPost('disposisi_id'))->find();
    //             $dispositionCreate = [
    //                 'from_user'     => $result['id'],
    //                 'from_position' => $result['position_id'],
    //                 'to_user'       => $getLastDisposition[0]['from_user'],
    //                 'to_position'   => $getLastDisposition[0]['from_position'],
    //                 'message'       => $this->request->getPost('komentar'),
    //                 'status'        => 'proses',
    //                 'category'      => 'out',
    //                 'mail_id'       => $getLastDisposition[0]['mail_id'],
    //             ];
    //         }

    //         $this->maildispositionModel->save($dispositionCreate);

    //         // disposition update 
    //         $dispositionUpdate = [
    //             'id'     => $this->request->getPost('disposisi_id'),
    //             'status' => 'selesai',
    //         ];

    //         $this->maildispositionModel->save($dispositionUpdate);
    //         $resultData = array(
    //             'respon_code' => 'RC200',
    //             'status'      => 1,
    //             'message'     => 'Berhasil Disposisi Surat',
    //         );
    //     } elseif ($action == 'forward_to_staff') {
    //         // check staff from top position skpd
    //         $getTop     = $this->positionModel->getTopPosition(session('user_position'))->find();
    //         $getSkpdTop = $this->positionModel->where('id', $getTop[0]['parent'])->find();
    //         $getStaff   = $this->positionModel->getStaff($getSkpdTop[0]['skpd_id'])->find();

    //         $dispositionCreate  = [
    //             'from_user'     => session('user_id'),
    //             'from_position' => session('user_position'),
    //             'to_user'       => $getStaff[0]['id'],
    //             'to_position'   => $getStaff[0]['position_id'],
    //             'message'       => $this->request->getVar('message'),
    //             'status'        => 'proses',
    //             'category'      => $category,
    //             'mail_id'       => $this->request->getVar('mail_id'),
    //         ];

    //         $this->maildispositionModel->save($dispositionCreate);

    //         // disposition update 
    //         $dispositionUpdate = [
    //             'id'     => $this->request->getVar('id'),
    //             'status' => 'selesai',
    //         ];

    //         $this->maildispositionModel->save($dispositionUpdate);

    //         // create alert and log
    //         $message = session('user_name') . " berhasil melakukan forward disposisi data surat ke pimpinan";
    //         setAlert('success', $message);
    //         createLog($message, $this->request->getIPAddress(), session('user_id'));

    //         // redirect based on mail category [out, out_nonskpd, in_skpd]
    //         return redirect()->to($this->url . '/index/' . $category . '/' . $status);
    //     } elseif ($action == 'tte') {

    //         $username_tte = $this->request->getVar('username_tte');
    //         $password_tte = $this->request->getVar('password_tte');
    //         $file         = './upload/mail/' . $this->request->getVar('file');
    //         $qrName       = $this->request->getVar('mail_id') . '.png';

    //         // check is user valid
    //         $checkUser = $this->accountValidity($username_tte);

    //         if ($checkUser['status'] == 'ISSUE') {

    //             $result =  $this->signFile($username_tte, $password_tte, $file, $qrName);
    //             if ($result['status'] == 'error') {
    //                 // create alert
    //                 $message = 'Gagal TTE, ' . $result['message'];
    //                 setAlert('failed', $message);
    //                 createLog($message, $this->request->getIPAddress(), session('user_id'));

    //                 // redirect based on mail category [out, out_nonskpd, in_skpd]
    //                 return redirect()->to($this->url . '/detail/' . $category . '/' . $status . '/' . $this->request->getVar('mail_id'));
    //             } else {

    //                 unlink($file);
    //                 rename('./file-sign/SIGNED/' . $result['message'], $file);

    //                 // SUCCESS TTE
    //                 $mailUpdate = [
    //                     'id'     => $this->request->getVar('mail_id'),
    //                     'status' => 'selesai',
    //                 ];

    //                 $this->mailModel->save($mailUpdate);

    //                 // disposition update 
    //                 $dispositionUpdate = [
    //                     'id'     => $this->request->getVar('id'),
    //                     'status' => 'selesai',
    //                 ];

    //                 $this->maildispositionModel->save($dispositionUpdate);

    //                 // create alert and log
    //                 $message = session('user_name') . ' Surat Berhasil Di TTE';
    //                 setAlert('success', $message);
    //                 createLog($message, $this->request->getIPAddress(), session('user_id'));

    //                 // redirect based on mail category [out, out_nonskpd, in_skpd]
    //                 return redirect()->to($this->url . '/index/' . $category . '/' . $status);
    //             }
    //         }
    //     }
    // }
}
