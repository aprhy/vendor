<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>


<?= $this->section('content'); ?>

<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
    </li>
    <li class="breadcrumb-item active"><?= $title; ?></li>
</ol>
<?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

<div class="row">
    
    <div class="col-lg-12">
        <div class="card border-info">
            <div class="card-header">
                <h6> Cetak Laporan </h6>
            </div>
            <div class="card-body">
                <?= form_open_multipart('admin/report/print', 'class="form-horizontal"'); ?>
                <?= csrf_field(); ?>

                <div class="form-row">
                    <div class="col-md-4 mb-3">
                        <label>Bulan</label>
                        <?php $month = [1=>"Januari", "Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];?>
                        <select class="form-control select2" name="month" required>
                            <option value="">- Pilih Bulan -</option>
                            <?php foreach($month as $key => $value) { ?>

                            <option value="<?= $key; ?>"><?= $value; ?></option>
                            
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label>Tahun</label>
                        <select class="form-control select2" name="year" required>
                            <option value="">- Pilih Tahun -</option>
                            <?php for($year = date('Y'); $year >= 2020; $year--) { ?>

                            <option value="<?= $year; ?>"><?= $year; ?></option>
                            
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label>SKPD</label>
                        <?php if (session('user_skpd') !="") : ?>
                            <input type="hidden" class="form-control" name="skpd" value="<?= session('user_skpd'); ?>">
                            <input type="text" class="form-control" value="<?= session('user_skpdname'); ?>">
                        <?php else : ?>
                            <select class="form-control select2" name="skpd" required>
                                <option value="">- Pilih SKPD -</option>
                                <?php foreach ($dataSkpd as $skpd) : ?>
                                <option value="<?= $skpd['id']; ?>"><?= $skpd['name']; ?></option>
                                <?php endforeach ?>
                            </select>
                        <?php endif ?>
                    </div>

                    <div class="col-md-12 mb-3">
                        <label>Jenis Surat</label>
                        <select class="form-control select2" name="category" required>
                            <option value="">- Pilih Surat -</option>
                            <option value="out">Surat Keluar</option>
                            <option value="out_nonskpd">Surat Keluar Non-SKPD</option>
                            <option value="in">Surat Masuk</option>
                            <option value="in_nonskpd">Surat MasuK Non-SKPD</option>
                        </select>
                    </div>
                </div>

                <hr>
                <input type="submit" class="btn btn-success" value="Cetak Laporan">

                <?= form_close(); ?>
            </div>
            <div class="card-footer bg-primary text-white">Page Rendered : {elapsed_time} second</div>
        </div>
    </div>
</div>

<?= $this->endSection('content'); ?>