<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>


<?= $this->section('content'); ?>

<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
    </li>
    <li class="breadcrumb-item active">Pengaturan Aplikasi</li>
</ol>
<?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

<div class="row">
    
    <div class="col-lg-9">
        <div class="card border-info">
            <div class="card-header bg-primary text-white">
                <h6> PENGATURAN </h6>
            </div>
            <div class="card-body">
                <?= form_open_multipart('admin/setting/save', 'class="form-horizontal"'); ?>
                <?= csrf_field(); ?>
                <input type="hidden" name="id" value="<?= $setting['id']; ?>">
                <input type="hidden" name="old_logo" value="<?= $setting['logo']; ?>">
                <b class="text-primary">#Data Aplikasi</b><hr>
                <div class="form-row">
                    <div class="col-md-4 mb-3">
                        <label>Nama Aplikasi</label>
                        <input type="text" class="form-control <?= ($validation->hasError('appname')) ? 'is-invalid':''; ?>" placeholder="Nama Aplikasi" name="appname" value="<?= (old('appname')) ? old('appname') : $setting['appname']; ?>">
                        <div class="invalid-feedback">
                            <?= $validation->getError('appname'); ?>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label>Singkatan Aplikasi</label>
                        <input type="text" class="form-control <?= ($validation->hasError('appname_short')) ? 'is-invalid':''; ?>" placeholder="Singkatan Aplikasi" name="appname_short" value="<?= (old('appname_short')) ? old('appname_shor') : $setting['appname_short']; ?>">
                        <div class="invalid-feedback">
                            <?= $validation->getError('appname_short'); ?>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label>Logo Aplikasi</label>
                        <input id="image" type="file" class="form-control <?= ($validation->hasError('logo')) ? 'is-invalid':''; ?>" placeholder="Logo Aplikasi" name="logo" value="<?= (old('logo')) ? old('logo') : $setting['logo']; ?>" onchange="previewImage()">
                        <div class="invalid-feedback">
                            <?= $validation->getError('logo'); ?>
                        </div>
                    </div>
                </div>

                <br><br><b class="text-primary">#Data Pemilik</b><hr>
                <div class="form-row">
                    <div class="col-md-6 mb-3">
                        <label>Pemilik/Kantor/Instansi</label>
                        <input type="text" class="form-control <?= ($validation->hasError('owner')) ? 'is-invalid':''; ?>" placeholder="Pemilik/Kantor/Instansi" name="owner" value="<?= (old('owner')) ? old('owner') : $setting['owner']; ?>">
                        <div class="invalid-feedback">
                            <?= $validation->getError('owner'); ?>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>Asal/Kabupaten/Kota</label>
                        <input type="text" class="form-control <?= ($validation->hasError('origin')) ? 'is-invalid':''; ?>" placeholder="Asal/Kabupaten/Kota" name="origin" value="<?= (old('origin')) ? old('origin') : $setting['origin']; ?>">
                        <div class="invalid-feedback">
                            <?= $validation->getError('origin'); ?>
                        </div>
                    </div>
                </div>

                <div class="form-row">
                    <div class="col-md-6 mb-3">
                        <label>Telephone</label>
                        <input type="text" class="form-control <?= ($validation->hasError('phone')) ? 'is-invalid':''; ?>" placeholder="Nomor Telephone" name="phone" value="<?= (old('phone')) ? old('phone') : $setting['phone']; ?>">
                        <div class="invalid-feedback">
                            <?= $validation->getError('phone'); ?>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>E-mail</label>
                        <input type="text" class="form-control <?= ($validation->hasError('email')) ? 'is-invalid':''; ?>" placeholder="Email" name="email" value="<?= (old('email')) ? old('email') : $setting['email']; ?>">
                        <div class="invalid-feedback">
                            <?= $validation->getError('email'); ?>
                        </div>
                    </div>
                </div>

                
                <hr>
                <input type="submit" class="btn btn-success btn-block" value="Update Pengaturan">

                <?= form_close(); ?>
            </div>
            <div class="card-footer">Page Rendered : {elapsed_time} second</div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card border-info">
            <div class="card-header bg-primary text-white">
                <h6> LOGO PREVIEW </h6>
            </div>
            <div class="card-body">
                <center>
                    <img class="img-preview" src="<?= base_url('upload/setting/'.$setting['logo']); ?>" alt="User Image" height="200px" width="200px">
                </center>
            </div>
        </div>
    </div>
</div>

<script>
    function previewImage() {
    const image      = document.querySelector('#image');
    const imgPreview = document.querySelector('.img-preview');

    const imgOrigin  = new FileReader();
    imgOrigin.readAsDataURL(image.files[0]);
    imgOrigin.onload = function (e) {
        imgPreview.src = e.target.result;
    }
    }
    

</script>

<?= $this->endSection('content'); ?>