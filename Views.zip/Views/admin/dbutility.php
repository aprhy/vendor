<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>


<?= $this->section('content'); ?>

<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
    </li>
    <li class="breadcrumb-item active">DB Utility</li>
</ol>
<?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

<div class="row">
    
    <div class="col-lg-12">
        <div class="card border-info">
            <div class="card-header bg-primary text-white">
                <h6> Backup & Restore :: Database </h6>
            </div>
            <div class="card-body">
                <!-- <div class="row">
                    <div class="col-lg-6">
                        <div style="border: 2px dashed #d2d6de; padding:10px;" class="text-center"> 
                            <img src="<?= base_url('assets/img/_backup.png'); ?>"><br><br>
                            <a href="<?= site_url('admin/dbutility/backupdb/gz'); ?>" class="btn btn-flat btn-danger">Backup Database(.gz)</a>
                            <a href="<?= site_url('admin/dbutility/backupdb/sql'); ?>" class="btn btn-flat btn-danger">Backup Database(.sql)</a>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        
                    </div>
                </div> -->
            </div>
            <div class="card-footer">Page Rendered : {elapsed_time} second</div>
        </div>
    </div>
</div>

<?= $this->endSection('content'); ?>