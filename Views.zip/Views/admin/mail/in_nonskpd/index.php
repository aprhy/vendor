<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>


<?= $this->section('content'); ?>

    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#">Data Surat</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#">Surat Masuk (Non - SKPD)</a>
        </li>
        <li class="breadcrumb-item active"><?= $title; ?></li>
    </ol>
    <?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

    <div class="row">
        
        <div class="col-lg-12">
            <div class="card border-primary">
                
                <div class="card-body">
                    
                    <?= form_open_multipart('admin/mail/urlform', 'class="form-horizontal"'); ?>
                    <?= csrf_field(); ?>

                    <input type="hidden" name="category" value="<?= current_url(true)->getSegment(4); ?>">

                    <div class="mb-3">
                        <label class="form-label">Jenis Surat <b class="text-red">*</b></label>
                        <select id="skpdselectajax" class="form-control select2 <?= ($validation->hasError('draft_id')) ? 'is-invalid':''; ?>" name="draft_id" required>
                            <option value="">:: Pilih Jenis Surat ::</option>
                            <?php foreach ($dataDraft as $draft) : ?>
                            <option value="<?= $draft['id'] ?>"> <?= $draft['name']; ?> </option>
                            <?php endforeach ?>
                        </select>
                        <div class="invalid-feedback">
                            <?= $validation->getError('draft_id'); ?>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Opsi Surat :</label><br>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="option" id="inlineRadio2" value="pdf" checked>
                            <label class="form-check-label" for="inlineRadio2">Upload PDF Surat</label>
                        </div>
                    </div>

                    <hr style="border: 0.5px dashed #d2d6de">

                    <input type="submit" class="btn btn-outline-primary" value="Selanjutnya">
                    <?= form_close(); ?>
                    
                </div>
                <div class="card-footer bg-primary text-white">Page Rendered : {elapsed_time} second</div>
            </div>
        </div>
    </div>

<?= $this->endSection('content'); ?>