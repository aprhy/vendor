<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>


<?= $this->section('content'); ?>

    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#">Data Surat</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#">Surat Masuk (Non - SKPD)</a>
        </li>
        <li class="breadcrumb-item"><a href="#"><?= $data[0]['number']; ?></a></li>
        <li class="breadcrumb-item active"><?= ucfirst(current_url(true)->getSegment(3)); ?></li>
    </ol>
    <?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

    <div class="row">
        
        <div class="col-lg-12">
            <div class="card no-b">
                <div class="card-header orange darken-1 text-white">
                    <h4><i class="icon-mail-envelope-open2 mr-2 mb-5"></i>Detail Surat :: <?= $data[0]['number']; ?></h4>
                    <div class="d-flex justify-content-between">
                        <div class="align-self-end">
                            <ul class="nav nav-material nav-material-white card-header-tabs" role="tablist">
                                <li class="nav-item">
                                    <a href="<?= site_url('admin/inbox/detail/'. current_url(true)->getSegment(4) .'/'. current_url(true)->getSegment(5). '/'. current_url(true)->getSegment(6)); ?>" class="nav-link show active"  role="tab">File Surat</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="w6--tab2" data-toggle="tab" href="#w6-tab2" role="tab" aria-controls="tab2" aria-selected="false">Data Surat</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="w6--tab3" data-toggle="tab" href="#w6-tab3" role="tab" aria-controls="tab3" aria-selected="false">Log Disposisi Surat (Internal SKPD)</a>
                                </li>
                            </ul>
                            <a href="<?= site_url('admin/inbox/index/'. current_url(true)->getSegment(4) .'/'. current_url(true)->getSegment(5)); ?>" class="btn-fab btn-fab fab-right-bottom absolute shadow btn-primary"><i class="icon-arrow-left s-14"></i></a>
                        </div>

                    </div>
                </div>
                <div class="card-body no-p">
                    <div class="tab-content" id="v-pills-tabContent2">
                        <div class="tab-pane fade active show p-5" id="w6-tab1" role="tabpanel" aria-labelledby="w6-tab1">
                            
                            <hr style="border: 0.5px dashed #d2d6de">

                            <object data="<?= base_url(); ?>/upload/mail/<?= $data[0]['file']; ?>" type="application/pdf" width="100%" height="650px"></object>
                        </div>
                        <div class="tab-pane fade p-5" id="w6-tab2" role="tabpanel" aria-labelledby="w6-tab2">
                            <strong class="text-blue">Nomor Surat / Agenda :</strong><br>
                            <?= $data[0]['number']; ?> | <?= $data[0]['agenda']; ?><br><br>

                            <strong class="text-blue">Tanggal Surat :</strong><br>
                            <?= indonesianDate($data[0]['date']); ?><br><br>

                            <strong class="text-blue">Perihal :</strong><br>
                            <?= $data[0]['about']; ?><br><br>

                            <strong class="text-blue">Ringkasan :</strong><br>
                            <?= $data[0]['summary']; ?><br><br>

                            <strong class="text-blue">Penerima / Tujuan Surat :</strong><br>
                            <?= $data[0]['destination_nonskpd']; ?><br><br>

                        </div>
                        <div class="tab-pane fade p-5" id="w6-tab3" role="tabpanel" aria-labelledby="w6-tab3">
                            <div class="table-responsive">
                                <table class="table table-hover earning-box">
                                    <tbody>
                                        <tr class="text-white" style="background-color: #2979ff;">
                                            <td>Dari</td>
                                            <td>Ke</td>
                                            <td>Waktu Disposisi</td>
                                            <td>Status</td>
                                            <td>Catatan</td>
                                        </tr>
                                        <?php foreach ($dataDisposition as $disposition) : ?>
                                        
                                        <tr class="no-b">
                                            <td>
                                                <h6><?= $disposition['sender']; ?></h6>
                                                <small class="text-muted"><?= $disposition['position_sender']; ?></small>
                                            </td>
                                            <td>
                                                <h6><?= $disposition['receiver']; ?></h6>
                                                <small class="text-muted"><?= $disposition['position_receiver']; ?></small>
                                            </td>
                                            <td><?= indonesianDate($disposition['created_at']); ?></td>
                                            <td><?= $disposition['status']; ?></td>
                                            <td><?= $disposition['message']; ?></td>
                                        </tr>

                                        <?php endforeach ?>
                                    
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>

                </div>
                
            </div>
        </div>
    </div>
    
    <?= $this->endSection('content'); ?>