<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>


<?= $this->section('content'); ?>

    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#">Buat Surat</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#"><?= $title.' Keluar Non SKPD'; ?></a>
        </li>
        <li class="breadcrumb-item">
            <a href="#"><?= $dataDraft[0]['name']; ?></a>
        </li>
        <li class="breadcrumb-item">
            <a href="#"><?= $data[0]['number']; ?></a>
        </li>
        <li class="breadcrumb-item active"><?= ucfirst(current_url(true)->getSegment(4)); ?></li>
    </ol>
    <?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

    <div class="row">
        
        <div class="col-lg-12">
            <div class="card border-primary">
                <div class="card-header">
                    <h4><dt class="text-blue"><?= $title.' Keluar Non SKPD'; ?></dt> <small><?= ucfirst(current_url(true)->getSegment(4)); ?></small></h4>
                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="float-left">
                                <a href="<?= site_url('admin/disposition/detail/'.current_url(true)->getSegment(5).'/perbaikan/'.current_url(true)->getSegment(8)); ?>" class="btn btn-sm btn-success" title="Kembali Data"><i class="icon-arrow-left"></i></a>
                                <a href="<?= site_url('admin/mail/form/update/'.current_url(true)->getSegment(5).'/'.current_url(true)->getSegment(6).'/'.current_url(true)->getSegment(7).'/'.current_url(true)->getSegment(8)); ?>" title="Refresh Halaman" class="btn btn-sm btn-success"><i class="icon-refresh"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?= form_open_multipart('admin/mail/save/update', 'class="form-horizontal"'); ?>
                    <?= csrf_field(); ?>
                    
                    <input type="hidden" name="id" value="<?= $data[0]['id']; ?>">
                    <input type="text" name="old_file" value="<?= $data[0]['file']; ?>">
                    <input type="hidden" name="template_draft" value="<?= current_url(true)->getSegment(6); ?>">
                    <input type="hidden" name="status" value="disposisi">
                    <input type="hidden" name="category" value="<?= current_url(true)->getSegment(5); ?>">
                    <input type="hidden" name="draft_id" value="<?= current_url(true)->getSegment(7); ?>">
                    <input type="hidden" name="skpd_id" value="<?= session('user_skpd'); ?>">

                    <strong class="text-blue">1. Data Surat</strong>
                    <hr style="border: 0.5px dashed #d2d6de">

                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Tanggal Surat <b class="text-red">*</b></label>
                                <input type="date" class="form-control <?= ($validation->hasError('date')) ? 'is-invalid':''; ?>" placeholder="Tanggal Surat" name="date" value="<?= (old('date')) ? old('date') : $data[0]['date']; ?>">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('date'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Nomor Surat <b class="text-red">*</b></label>
                                <input type="text" class="form-control <?= ($validation->hasError('number')) ? 'is-invalid':''; ?>" placeholder="Nomor Surat" name="number" value="<?= (old('number')) ? old('number') : $data[0]['number']; ?>">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('number'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Nomor Agenda <b class="text-red">*</b></label>
                                <input type="text" class="form-control <?= ($validation->hasError('agenda')) ? 'is-invalid':''; ?>" placeholder="Nomor Agenda" name="agenda" value="<?= (old('agenda')) ? old('agenda') : $data[0]['agenda']; ?>">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('agenda'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="mb-3">
                                <label class="form-label">Perihal Surat <b class="text-red">*</b></label>
                                <input type="text" class="form-control <?= ($validation->hasError('about')) ? 'is-invalid':''; ?>" placeholder="Perihal Surat" name="about" value="<?= (old('about')) ? old('about') : $data[0]['about']; ?>">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('about'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Penandatangan Surat <b class="text-red">*</b></label>
                                <?php $sign = ['skpd','sekretariat','gubernur'];?>
                                <select class="form-control select2 <?= ($validation->hasError('sign')) ? 'is-invalid':''; ?>" name="sign">
                                    <option value="">:: Pilih Penandatangan ::</option>
                                    <?php for($i = 0; $i < count($sign); $i++) : ?>
                                        <?php if (old('sign')) : ?>
                                            <?php if (old('sign') == $sign[$i]) : ?>
                                                <option value="<?= $sign[$i] ?>" selected> <?= $sign[$i]; ?> </option>
                                            <?php else : ?>
                                                <option value="<?= $sign[$i] ?>"> <?= $sign[$i]; ?> </option>
                                            <?php endif ?>
                                        <?php else : ?>
                                            <?php if ($data[0]['sign'] == $sign[$i]) : ?>
                                                <option value="<?= $sign[$i] ?>" selected> <?= $sign[$i]; ?> </option>
                                            <?php else : ?>
                                                <option value="<?= $sign[$i] ?>"> <?= $sign[$i]; ?> </option>
                                            <?php endif ?>
                                        <?php endif ?>
                                    <?php endfor ?>
                                </select>
                                
                                <div class="invalid-feedback">
                                    <?= $validation->getError('agenda'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label class="form-label">Ringkasan Surat <b class="text-red">*</b></label>
                                <textarea class="form-control <?= ($validation->hasError('summary')) ? 'is-invalid':''; ?>" name="summary" placeholder="Ringkasan Surat" rows="6"><?= (old('summary')) ? old('summary') : $data[0]['summary'] ; ?></textarea>
                                <div class="invalid-feedback">
                                    <?= $validation->getError('summary'); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <strong class="text-blue">2. Penerima Surat</strong>
                    <hr style="border: 0.5px dashed #d2d6de">
                    

                    <div class="row">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label class="form-label">Penerima Surat <b class="text-red">*</b></label>
                                <input type="text" class="form-control <?= ($validation->hasError('destination_nonskpd')) ? 'is-invalid':''; ?>" placeholder="Penerima Surat" name="destination_nonskpd" value="<?= (old('destination_nonskpd')) ? old('destination_nonskpd') : $data[0]['destination_nonskpd']; ?>">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('destination_nonskpd'); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <strong class="text-blue">3. File Surat</strong>
                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="row">

                        <?php if ($data[0]['template'] != "") : ?>
                            <?php 
                                $template = str_replace('skpd.name', strtoupper(session('user_skpdname')), $data[0]['template']);    
                                $template = str_replace('skpd.address', $dataSkpd[0]['address'] , $template);
                                // $template = str_replace('skpd.head.name', $dataLeader[0]['fullname'] , $template);
                                // $template = str_replace('skpd.head.position', $dataLeader[0]['position_name'] , $template);
                                // $template = str_replace('skpd.head.nip', $dataLeader[0]['nip'] , $template);

                                $template_attachment = $data[0]['template_attachment'];
                            ?>

                            <input type="hidden" name="file" value="">
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label class="form-label">Template</label>
                                    <textarea id="editor" class="form-control <?= ($validation->hasError('template')) ? 'is-invalid':''; ?>" name="template" placeholder="Template Surat">
                                        <?php 
                                            if (old('draft')) {
                                                echo old('draft');
                                            }else {
                                                echo $template;
                                            }
                                        ?>
                                    </textarea>
                                    <div class="invalid-feedback">
                                        <?= $validation->getError('tempate'); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label class="form-label"><input type="checkbox" name="validate_attachment" value="yes"/> Template Lampiran <br > <b class="text-red">*jika lampiran dicentang, maka lampiran akan di generate bersama template surat</b></label>
                                    <textarea id="editor1" class="form-control <?= ($validation->hasError('template_attachment')) ? 'is-invalid':''; ?>" name="template_attachment" placeholder="Template Lampiran">
                                        <?php 
                                            if (old('template_attachment')) {
                                                echo old('template_attachment');
                                            }else {
                                                echo $template_attachment;
                                            }
                                        ?>
                                    </textarea>
                                    <div class="invalid-feedback">
                                        <?= $validation->getError('template_attachment'); ?>
                                    </div>
                                </div>
                            </div>
                        <?php else : ?>
                            <input type="hidden" name="template" value="">
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label class="form-label">File PDF Surat <b class="text-red">*</b></label>
                                    <input type="file" class="form-control <?= ($validation->hasError('file')) ? 'is-invalid':''; ?>" placeholder="File PDF Surat" accept=".pdf" name="file" value="<?= old('file'); ?>" required>
                                    <div class="invalid-feedback">
                                        <?= $validation->getError('file'); ?>
                                    </div>

                                    
                                </div>
                            </div>
                        <?php endif ?>
                        
                        <div class="col-md-12">
                            <div class="mb-3">
                                <strong class="text-danger">File Sebelumnya :</strong> <a href="<?= base_url('upload/mail/'.$data[0]['file']); ?>" target="_blank"><?= $data[0]['file']; ?></a>
                            </div>
                        </div>
                        
                    </div>
                    
                    <hr style="border: 0.5px dashed #d2d6de">
                    <input type="submit" class="btn btn-outline-primary" value="Update Data">
                    <?= form_close(); ?>
                    
                </div>
                <div class="card-footer bg-primary text-white">Page Rendered : {elapsed_time} second</div>
            </div>
        </div>
    
        <script>
            $(document).ready(function() {
                CKEDITOR.replace('editor',{
                    toolbar : 'MyToolbar',
                    width:"100%",
                    height:"900px",
                    filebrowserBrowseUrl : '<?= base_url('assets/plugin/ckfinder/ckfinder.html');?>',
                    filebrowserImageBrowseUrl : '<?= base_url('assets/plugin/ckfinder/ckfinder.html?type=Images');?>',
                    filebrowserFlashBrowseUrl : '<?= base_url('assets/plugin/ckfinder/ckfinder.html?type=Flash');?>',
                });

                CKEDITOR.replace('editor1',{
                    toolbar : 'MyToolbar',
                    width:"100%",
                    height:"900px",
                    filebrowserBrowseUrl : '<?= base_url('assets/plugin/ckfinder/ckfinder.html');?>',
                    filebrowserImageBrowseUrl : '<?= base_url('assets/plugin/ckfinder/ckfinder.html?type=Images');?>',
                    filebrowserFlashBrowseUrl : '<?= base_url('assets/plugin/ckfinder/ckfinder.html?type=Flash');?>',
                });
            });
        </script>

    </div>

<?= $this->endSection('content'); ?>