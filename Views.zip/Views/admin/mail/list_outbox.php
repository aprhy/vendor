<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>


<?= $this->section('content'); ?>

    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#">Data Surat</a>
        </li>
        <li class="breadcrumb-item"><a href="#"><?= (current_url(true)->getSegment(4) == 'out') ? 'Surat Keluar SKPD':'Surat Keluar Non-SKPD'; ?></a></li>
        <li class="breadcrumb-item active"><?= ucfirst(current_url(true)->getSegment(5)); ?></li>
    </ol>
    <?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

    <div class="row">
        
        <div class="col-lg-12">
            <div class="card border-primary">
                <div class="card-header">
                    <h4><dt class="text-blue"><?= (current_url(true)->getSegment(4) == 'out') ? 'Surat Keluar SKPD':'Surat Keluar Non-SKPD'; ?></dt> <small><?= ucfirst(current_url(true)->getSegment(5)); ?> </small></h4>
                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="row">
                        <div class="col-lg-5">
                        <?= form_open('admin/outbox/search/'.current_url(true)->getSegment(4).'/'.current_url(true)->getSegment(5)) ?>
                        <?= csrf_field(); ?>
                            <div class="input-group mb-3">
                                <input type="text" class="form-control form-control-sm" name="keyword" placeholder="Masukkan kata kunci pencarian" aria-label="Cari Berdasarakan Nama" aria-describedby="button-addon2">
                                <button class="btn btn-sm btn-outline-primary" type="submit"><i class="icon-search"></i></button>
                            </div>
                        <?= form_close(); ?>
                        </div>
                        <div class="col-lg-7">
                            <div class="float-right">
                                <a href="<?= site_url('admin/outbox/index/out/draft'); ?>" title="Data Surat Keluar" class="btn btn-sm <?= (current_url(true)->getSegment(4) == 'out') ? 'btn-primary':'btn-outline-primary'; ?>">Surat Keluar (SKPD)</a>
                                <a href="<?= site_url('admin/outbox/index/out_nonskpd/draft'); ?>" title="Data Surat Keluar" class="btn btn-sm <?= (current_url(true)->getSegment(4) == 'out_nonskpd') ? 'btn-primary':'btn-outline-primary'; ?> ">Surat Keluar (Non-SKPD)</i></a>
                                <a href="<?= site_url('admin/outbox/index/out/draft'); ?>" title="Refresh Halaman" class="btn btn-sm btn-success"><i class="icon-refresh"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (current_url(true)->getSegment(4) == 'out') : ?>
                        <?= (session('sess_outbox_out')) ? "<p>Kata Kunci Pencarian : <b class='text-danger'>". session('sess_outbox_out') ."</b></p>" : ''; ?>
                    <?php else : ?>
                        <?= (session('sess_outbox_out_nonskpd')) ? "<p>Kata Kunci Pencarian : <b class='text-danger'>". session('sess_outbox_out_nonskpd') ."</b></p>" : ''; ?>
                    <?php endif ?>
                    
                    <a href="<?= site_url('admin/outbox/index/'.current_url(true)->getSegment(4).'/draft'); ?>" title="Surat Status Draft" class="btn btn-xs <?= (current_url(true)->getSegment(5) == 'draft') ? 'btn-success':'btn-outline-success'; ?>">draft</a>
                    <a href="<?= site_url('admin/outbox/index/'.current_url(true)->getSegment(4).'/disposisi'); ?>" title="Surat Status Disposisi" class="btn btn-xs <?= (current_url(true)->getSegment(5) == 'disposisi') ? 'btn-success':'btn-outline-success'; ?>">disposisi</a>
                    <a href="<?= site_url('admin/outbox/index/'.current_url(true)->getSegment(4).'/selesai'); ?>" title="Surat Status Selesai" class="btn btn-xs <?= (current_url(true)->getSegment(5) == 'selesai') ? 'btn-success':'btn-outline-success'; ?>">selesai</a>

                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped table-hover">
                            <tbody>
                                <tr class="bg-primary text-white">
                                    <th style="width: 50px;">No</th>
                                    <th style="width: 25%;">#aksi</th>
                                    <th>Nomor</th>
                                    <th>Perihal</th>
                                    <th>Penandatangan</th>
                                    <?php if(current_url(true)->getSegment(4) == 'out_nonskpd') : ?>
                                    <th>Penerima Surat</th>
                                    <?php endif ?>
                                </tr>
                                <?php $no=1 + (10 * ($currentPage - 1) ); foreach ($data as $key) : ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td>
                                        <a href="<?= site_url('admin/outbox/detail/'. current_url(true)->getSegment(4). '/'. current_url(true)->getSegment(5) .'/'. $key['id']); ?>" class="btn btn-xs btn-primary">detail</a>
                                        
                                        <?php if (session('user_role') != 2) : ?>
                                            <?php if ($key['status'] == 'draft' OR $key['status'] == 'disposisi') : ?>
                                                <button class="btn btn-xs btn-danger" data-toggle="modal" data-target="#deleteModal<?= $key['id'];?>">delete</button>
                                            <?php endif ?>
                                            <?php if ($key['status'] == 'draft') : ?>
                                                <button class="btn btn-xs btn-success" data-toggle="modal" data-target="#forwardModal<?= $key['id'];?>">teruskan ke pimpinan</button>
                                            <?php endif ?>
                                        <?php endif ?>
                                    </td>
                                    <td>
                                        <span class="badge badge-primary">Surat : <?= $key['number']; ?></span><br>
                                        <span class="badge badge-primary">Agenda : <?= $key['agenda']; ?></span>
                                    </td>
                                    <td>
                                        <?= $key['about']; ?><br>
                                        <span class="badge badge-success"><?= $key['name']; ?></span>
                                    </td>
                                    <td><?= $key['sign']; ?></td>
                                    <?php if(current_url(true)->getSegment(4) == 'out_nonskpd') : ?>
                                    <td><?= $key['destination_nonskpd']; ?></td>
                                    <?php endif ?>
                                </tr>

                                <!-- Modal -->
                                <div class="modal fade" id="deleteModal<?= $key['id'];?>" data-backdrop="false" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header bg-danger text-white">
                                                <h5 class="modal-title" id="deleteModalLabel">Hapus Data</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <?= form_open_multipart('admin/outbox/delete/'. current_url(true)->getSegment(4).'/'. current_url(true)->getSegment(5), 'class="form-horizontal"'); ?>
                                                <?= csrf_field(); ?>
                                                    <input type="hidden" value="<?= $key['id']; ?>" name="id">
                                                    <input type="hidden" value="<?= $key['file']; ?>" name="file">
                                                    Apakah anda yakin akan menghapus data ini ?<br><br>
                                                    <b>Jenis Surat :</b><br> <?= $key['name']; ?><br><br>
                                                    <b>Nomor Surat :</b><br> <?= $key['number'].' | '.$key['agenda']; ?><br><br>
                                                    <b>Perihal Surat :</b><br> <?= $key['about']; ?><br><br>
                                                    <hr style="border: 0.5px dashed #d2d6de">
                                                    <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-danger">Ya, Hapus</button>
                                                <?= form_close(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Modal Forward -->
                                <div class="modal fade" id="forwardModal<?= $key['id'];?>" data-backdrop="false" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header bg-success text-white">
                                                <h5 class="modal-title" id="deleteModalLabel">Teruskan Ke Pimpinan</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <?= form_open_multipart('admin/outbox/forward/'. current_url(true)->getSegment(4).'/'. current_url(true)->getSegment(5), 'class="form-horizontal"'); ?>
                                                <?= csrf_field(); ?>
                                                    <input type="hidden" value="<?= $key['id']; ?>" name="id">
                                                    Apakah anda yakin akan meneruskan data ini kepada pimpinan anda ?<br><br>
                                                    <b>Jenis Surat :</b><br> <?= $key['name']; ?><br><br>
                                                    <b>Nomor Surat :</b><br> <?= $key['number'].' | '.$key['agenda']; ?><br><br>
                                                    <b>Perihal Surat :</b><br> <?= $key['about']; ?><br><br>
                                                    <hr style="border: 0.5px dashed #d2d6de">
                                                    <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-success">Ya, Teruskan</button>
                                                <?= form_close(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>

                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="float-left">
                        <p>Tampilkan <?= (($currentPage - 1) * 10) + count($data) ." dari ".$totalData." data"; ?> </p>
                    </div>
                    <?= $pager->links('default','default_pager'); ?>
                </div>
                <div class="card-footer bg-primary text-white">Page Rendered : {elapsed_time} second</div>
            </div>
        </div>
    </div>

<?= $this->endSection('content'); ?>