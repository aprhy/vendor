<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>


<?= $this->section('content'); ?>

    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
        </li>
        <li class="breadcrumb-item active"><?= $title; ?></li>
    </ol>
    <?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

    <div class="row">
        <div class="col-lg-4">
            <div class="card border-success shadow text-center p-5">
                <div class="image mr-3">
                    <i class="icon icon-inbox-upload2 s-48"></i>
                </div>
                <div>
                    <h6 class="p-t-10">Surat Keluar (<strong class="text-danger">SKPD</strong>)</h6>
                </div>
                <a href="<?= site_url('admin/mail/create/out'); ?>" class="btn btn-success btn-sm mt-3">Buat Surat</a>
                <hr style="border: 0.5px dashed #d2d6de">
                <small class="pull-left">
                    <i class="icon icon-information4 text-danger"></i> Catatan : Surat ini dibuat untuk ditujukan pada seluruh SKPD atau Kedinasan yang ada di lingkup Provinsi Sulawesi Tenggara
                </small>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card border-warning shadow text-center p-5">
                <div class="image mr-3">
                    <i class="icon icon-inbox-upload2 s-48"></i>
                </div>
                <div>
                    <h6 class="p-t-10">Surat Keluar (<strong class="text-danger">Non-SKPD</strong>)</h6>
                </div>
                <a href="<?= site_url('admin/mail/create/out_nonskpd'); ?>" class="btn btn-warning btn-sm mt-3">Buat Surat</a>
                <hr style="border: 0.5px dashed #d2d6de">
                <small class="pull-left">
                    <i class="icon icon-information4 text-danger"></i> Catatan : Surat ini dibuat untuk ditujukan pada instansi apapun yang ada diluar lingkup SKPD Provinsi Sulawesi Tenggara
                </small>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card border-warning shadow text-center p-5">
                <div class="image mr-3">
                    <i class="icon icon-inbox-download2 s-48"></i>
                </div>
                <div>
                    <h6 class="p-t-10">Surat Masuk (<strong class="text-danger">Non-SKPD</strong>)</h6>
                </div>
                <a href="<?= site_url('admin/mail/create/in_nonskpd'); ?>" class="btn btn-warning btn-sm mt-3">Buat Surat</a>
                <hr style="border: 0.5px dashed #d2d6de">
                <small class="pull-left">
                    <i class="icon icon-information4 text-danger"></i> Catatan : Ditujukan untuk surat yang masuk dari luar instansi SKPD lingkup Provinsi Sulawesi Tenggara ke SKPD Anda
                </small>
            </div>
        </div>
    </div>

<?= $this->endSection('content'); ?>