<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>


<?= $this->section('content'); ?>

    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#">Core Data</a>
        </li>
        <li class="breadcrumb-item active"><?= $title; ?></li>
    </ol>
    <?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

    <div class="row">
        
        <div class="col-lg-12">
            <div class="card border-primary">
                <div class="card-header">
                    <h4><dt class="text-blue"><?= $title; ?></dt></h4>
                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="row">
                        <div class="col-lg-5">
                        <?= form_open('admin/skpd/search') ?>
                        <?= csrf_field(); ?>
                            <div class="input-group mb-3">
                                <input type="text" class="form-control form-control-sm" name="keyword" placeholder="Masukkan kata kunci pencarian" aria-label="Cari Berdasarakan Nama" aria-describedby="button-addon2">
                                <button class="btn btn-sm btn-outline-primary" type="submit"><i class="icon-search"></i></button>
                            </div>
                        <?= form_close(); ?>
                        </div>
                        <div class="col-lg-7">
                            <div class="float-right">
                                <a href="<?= site_url('admin/skpd/form/create'); ?>" class="btn btn-sm btn-primary" title="Tambah Data">Tambah Data</a>
                                <a href="<?= site_url('admin/skpd/'); ?>" title="Refresh Halaman" class="btn btn-sm btn-success"><i class="icon-refresh"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?= (session('sess_skpd')) ? "<p>Kata Kunci Pencarian : <b class='text-danger'>". session('sess_skpd') ."</b></p>" : ''; ?></p>
                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped table-hover">
                            <tbody>
                                <tr class="bg-primary text-white">
                                    <th style="width: 50px;">No</th>
                                    <th style="width: 25%;">#aksi</th>
                                    <th>SKPD</th>
                                    <th>Alamat</th>
                                    <th>Kategori</th>
                                </tr>
                                <?php $no=1 + (10 * ($currentPage - 1) ); foreach ($data as $key) : ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td>
                                        <a href="<?= site_url('admin/skpd/form/update/'.$key['id']); ?>" class="btn btn-xs btn-warning">update</a>
                                        <button class="btn btn-xs btn-danger" data-toggle="modal" data-target="#deleteModal<?= $key['id'];?>">delete</button>
                                         | <a href="<?= site_url('admin/position/index/'.$key['id']); ?>" class="btn btn-xs btn-primary">Struktur Jabatan</a>
                                    </td>
                                    <td><?= $key['name']; ?></td>
                                    <td><?= $key['address']; ?></td>
                                    <td><?= $key['category']; ?></td>
                                </tr>

                                <!-- Modal -->
                                <div class="modal fade" id="deleteModal<?= $key['id'];?>" data-backdrop="false" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header bg-danger text-white">
                                                <h5 class="modal-title" id="deleteModalLabel">Hapus Data</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <?= form_open_multipart('admin/skpd/delete', 'class="form-horizontal"'); ?>
                                                <?= csrf_field(); ?>
                                                    <input type="hidden" value="<?= $key['id']; ?>" name="id">
                                                    Apakah anda yakin akan menghapus data ini ?<br>
                                                    <b>SKPD : <?= $key['name']; ?></b>
                                                    <hr style="border: 0.5px dashed #d2d6de">
                                                    <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-danger">Ya, Hapus</button>
                                                <?= form_close(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>

                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="float-left">
                        <p>Tampilkan <?= (($currentPage - 1) * 10) + count($data) ." dari ".$totalData." data"; ?> </p>
                    </div>
                    <?= $pager->links('default','default_pager'); ?>
                </div>
                <div class="card-footer bg-primary text-white">Page Rendered : {elapsed_time} second</div>
            </div>
        </div>
    </div>

<?= $this->endSection('content'); ?>