<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>


<?= $this->section('content'); ?>

    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#">Core Data</a>
        </li>
        <li class="breadcrumb-item">
            <a href="<?= site_url('admin/skpd/'); ?>"><?= $title; ?></a>
        </li>
        <li class="breadcrumb-item active"><?= ucfirst(current_url(true)->getSegment(4)); ?></li>
    </ol>
    <?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

    <div class="row">
        
        <div class="col-lg-12">
            <div class="card border-primary">
                <div class="card-header">
                    <h4><dt class="text-blue"><?= $title; ?></dt> <small>Tambah Data </small></h4>
                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="float-left">
                                <a href="<?= site_url('admin/skpd/'); ?>" class="btn btn-sm btn-success" title="Kembali Data"><i class="icon-arrow-left"></i></a>
                                <a href="<?= site_url('admin/skpd/form/create'); ?>" title="Refresh Halaman" class="btn btn-sm btn-success"><i class="icon-refresh"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?= form_open_multipart('admin/skpd/save/create', 'class="form-horizontal"'); ?>
                    <?= csrf_field(); ?>

                    <div class="mb-3">
                        <label class="form-label">SKPD <b class="text-red">*</b></label>
                        <input type="text" class="form-control <?= ($validation->hasError('name')) ? 'is-invalid':''; ?>" placeholder="SKPD" name="name" value="<?= old('name'); ?>">
                        <div class="invalid-feedback">
                            <?= $validation->getError('name'); ?>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Alamat <b class="text-red">*</b></label>
                        <textarea class="form-control <?= ($validation->hasError('address')) ? 'is-invalid':''; ?>" name="address" placeholder="Alamat Dinas"><?= old('address'); ?></textarea>
                        <div class="invalid-feedback">
                            <?= $validation->getError('address'); ?>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Kategori <b class="text-red">*</b></label>
                        <?php $category = ['dinas','badan','sekretariat','gubernur'];?>
                        <select class="form-control select2 <?= ($validation->hasError('category')) ? 'is-invalid':''; ?>" name="category">
                            <option value="">:: Pilih Kategori ::</option>
                            <?php for($i = 0; $i < count($category); $i++) : ?>
                            <?php if (old('category')) : ?>
                                <?php if (old('category') == $category[$i]) : ?>
                                    <option value="<?= $category[$i] ?>" selected> <?= $category[$i]; ?> </option>
                                <?php else : ?>
                                    <option value="<?= $category[$i] ?>"> <?= $category[$i]; ?> </option>
                                <?php endif ?>
                            <?php else : ?>
                                <option value="<?= $category[$i] ?>"> <?= $category[$i]; ?> </option>
                            <?php endif ?>
                            <?php endfor ?>
                        </select>
                        <div class="invalid-feedback">
                            <?= $validation->getError('category'); ?>
                        </div>
                    </div>
                    <hr style="border: 0.5px dashed #d2d6de">
                    <input type="submit" class="btn btn-outline-primary" value="Tambah Data">
                    <?= form_close(); ?>
                    
                </div>
                <div class="card-footer bg-primary text-white">Page Rendered : {elapsed_time} second</div>
            </div>
        </div>
    </div>

<?= $this->endSection('content'); ?>