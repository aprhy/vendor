<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>

<?= $this->section('content'); ?>
<?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

Selamat Datang, <strong><?= session('user_fullname'); ?></strong>

<hr style="border: 0.5px dashed #d2d6de">

<?php if (session('user_role') == 1) : ?>
   
<div class="row">
    <div class="col-lg-3">
        <div class="counter-box blue darken-3 r-3">
            <div class="p-4">
                <div class="float-right">
                    <span class="icon icon-users text-white s-48"></span>
                </div>
                <div class="counter-title text-white">Penguna</div>
                <h5 class="mt-3 text-white"><?= $basicWidget['userTotal']; ?></h5>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="counter-box blue darken-3 r-3">
            <div class="p-4">
                <div class="float-right">
                    <span class="icon icon-building-o text-white s-48"></span>
                </div>
                <div class="counter-title text-white">SKPD</div>
                <h5 class="mt-3 text-white"><?= $basicWidget['skpdTotal']; ?></h5>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="counter-box blue darken-3 r-3">
            <div class="p-4">
                <div class="float-right">
                    <span class="icon icon-tags text-white s-48"></span>
                </div>
                <div class="counter-title text-white">Jenis Surat</div>
                <h5 class="mt-3 text-white"><?= $basicWidget['draftTotal']; ?></h5>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="counter-box blue darken-3 r-3">
            <div class="p-4">
                <div class="float-right">
                    <span class="icon icon-th-list text-white s-48"></span>
                </div>
                <div class="counter-title text-white">Kelas Jabatan</div>
                <h5 class="mt-3 text-white"><?= $basicWidget['positionclassTotal']; ?></h5>
            </div>
        </div>
    </div>
</div>
<br>

<?php endif ?>

<?php if(session('user_role') == 3): ?>
<div class="row">
    <div class="col-lg-12">
        <a href="<?= site_url('admin/dashboard/generateTTDImage'); ?>" class="btn btn-danger btn-sm mt-3">Regenarate TTD Image</a><br><br>
        <?php if (file_exists($_SERVER['DOCUMENT_ROOT'].'/upload/ttd/'.session('user_skpd').'.jpg')) :?>
            <img src="<?= base_url("upload/ttd/".session('user_skpd').".jpg"); ?>">
        <?php else : ?>
            <img src="<?= base_url("upload/file_ttd.png"); ?>">
        <?php endif ?>
        <hr style="border: 0.5px dashed #d2d6de">
    </div>
</div>
<?php endif ?>

<div class="row">
    <div class="col-lg-3">
        <div class="card counter-box white r-3 border-danger">
            <div class="p-4">
                <div class="float-right">
                    <span class="icon icon-inbox-upload2 s-48 text-red"></span>
                </div>
                <div class="counter-title text-red"><dt>Surat Keluar</dt></div>
                <h5 class="mt-3"><?= $mailWidget['outboxSkpdTotal'] + $mailWidget['outboxNonSkpdTotal']; ?></h5>
                
                <hr style="border: 0.5px dashed #d2d6de">

                <div class="row">
                    <div class="col-lg-12">
                        <small>
                            <table class="">
                                <tr>
                                    <td colspan="3"><strong class="text-blue">Berdasarkan Kategori</strong></td>
                                </tr>
                                <tr>
                                    <td> <i class="icon icon-information4 text-danger"></i> <strong>SKPD</strong></td>
                                    <td>:</td>
                                    <td><?= $mailWidget['outboxSkpdTotal']; ?></td>
                                </tr>
                                <tr>
                                    <td><i class="icon icon-information4 text-danger"></i> <strong>Non-SKPD</strong></td>
                                    <td>:</td>
                                    <td><?= $mailWidget['outboxSkpdTotal']; ?></td>
                                </tr>
                                <tr>
                                    <td colspan="3"><br></td>
                                </tr>
                                <tr>
                                    <td colspan="3"><strong class="text-blue">Berdasarkan Status</strong></td>
                                </tr>
                                <tr>
                                    <td> <i class="icon icon-information4 text-danger"></i> <strong>Proses</strong></td>
                                    <td>:</td>
                                    <td><?= $mailWidget['outboxSkpdProcess']; ?></td>
                                </tr>
                                <tr>
                                    <td><i class="icon icon-information4 text-danger"></i> <strong>Selesai</strong></td>
                                    <td>:</td>
                                    <td><?= $mailWidget['outboxSkpdFinish']; ?></td>
                                </tr>
                            </table>
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-3">
        <div class="card counter-box white r-3 b border-success">
            <div class="p-4">
                <div class="float-right">
                    <span class="icon icon-inbox-download2 s-48 text-green"></span>
                </div>
                <div class="counter-title text-green"><dt>Surat Masuk</dt></div>
                <h5 class="mt-3"><?= $mailWidget['inboxSkpdTotal'] + $mailWidget['inboxNonSkpdTotal']; ?></h5>
                <hr style="border: 0.5px dashed #d2d6de">

                <div class="row">
                    <div class="col-lg-12">
                        <small>
                            <table class="">
                                <tr>
                                    <td colspan="3"><strong class="text-blue">Berdasarkan Kategori</strong></td>
                                </tr>
                                <tr>
                                    <td> <i class="icon icon-information4 text-danger"></i> <strong>SKPD</strong></td>
                                    <td>:</td>
                                    <td><?= $mailWidget['inboxSkpdTotal']; ?></td>
                                </tr>
                                <tr>
                                    <td><i class="icon icon-information4 text-danger"></i> <strong>Non-SKPD</strong></td>
                                    <td>:</td>
                                    <td><?= $mailWidget['inboxNonSkpdTotal']; ?></td>
                                </tr>
                                <tr>
                                    <td colspan="3"><br></td>
                                </tr>
                                <tr>
                                    <td colspan="3"><strong class="text-blue">Berdasarkan Status</strong></td>
                                </tr>
                                <tr>
                                    <td> <i class="icon icon-information4 text-danger"></i> <strong>Proses</strong></td>
                                    <td>:</td>
                                    <td><?= $mailWidget['inboxSkpdProcess'] + $mailWidget['inboxNonSkpdProcess']; ?></td>
                                </tr>
                                <tr>
                                    <td><i class="icon icon-information4 text-danger"></i> <strong>Selesai</strong></td>
                                    <td>:</td>
                                    <td><?= $mailWidget['inboxSkpdFinish'] + $mailWidget['inboxNonSkpdFinish']; ?></td>
                                </tr>
                            </table>
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-3">
        <div class="card counter-box white r-3 b border-primary">
            <div class="p-4">
                <div class="float-right">
                    <span class="icon icon-upload s-48 text-blue"></span>
                </div>
                <div class="counter-title text-blue"><dt>Disposisi Keluar</dt></div>
                <h5 class="mt-3"><?= $dispositionWidget['outDisSkpd'] + $dispositionWidget['outDisNonSkpd']; ?></h5>

                <hr style="border: 0.5px dashed #d2d6de">

                <div class="row">
                    <div class="col-lg-12">
                        <small>
                            <table class="">
                                <tr>
                                    <td colspan="3"><strong class="text-blue">Berdasarkan Kategori</strong></td>
                                </tr>
                                <tr>
                                    <td> <i class="icon icon-information4 text-danger"></i> <strong>SKPD</strong></td>
                                    <td>:</td>
                                    <td><?= $dispositionWidget['outDisSkpd']; ?></td>
                                </tr>
                                <tr>
                                    <td><i class="icon icon-information4 text-danger"></i> <strong>Non-SKPD</strong></td>
                                    <td>:</td>
                                    <td><?= $dispositionWidget['outDisNonSkpd']; ?></td>
                                </tr>
                                <tr>
                                    <td colspan="3"><br></td>
                                </tr>
                                <tr>
                                    <td colspan="3"><strong class="text-blue">Berdasarkan Status</strong></td>
                                </tr>
                                <tr>
                                    <td> <i class="icon icon-information4 text-danger"></i> <strong>Proses</strong></td>
                                    <td>:</td>
                                    <td><?= $dispositionWidget['outDisProcess']; ?></td>
                                </tr>
                                <tr>
                                    <td><i class="icon icon-information4 text-danger"></i> <strong>Selesai</strong></td>
                                    <td>:</td>
                                    <td><?= $dispositionWidget['outDisFinish']; ?></td>
                                </tr>
                            </table>
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-3">
        <div class="card counter-box white r-3 b border-primary">
            <div class="p-4">
                <div class="float-right">
                    <span class="icon icon-download s-48 text-blue"></span>
                </div>
                <div class="counter-title text-blue"><dt>Disposisi Masuk</dt></div>
                <h5 class="mt-3"><?= $dispositionWidget['inDisSkpd'] + $dispositionWidget['inDisNonSkpd']; ?></h5>

                <hr style="border: 0.5px dashed #d2d6de">

                <div class="row">
                    <div class="col-lg-12">
                        <small>
                            <table class="">
                                <tr>
                                    <td colspan="3"><strong class="text-blue">Berdasarkan Kategori</strong></td>
                                </tr>
                                <tr>
                                    <td> <i class="icon icon-information4 text-danger"></i> <strong>SKPD</strong></td>
                                    <td>:</td>
                                    <td><?= $dispositionWidget['inDisSkpd']; ?></td>
                                </tr>
                                <tr>
                                    <td><i class="icon icon-information4 text-danger"></i> <strong>Non-SKPD</strong></td>
                                    <td>:</td>
                                    <td><?= $dispositionWidget['inDisNonSkpd']; ?></td>
                                </tr>
                                <tr>
                                    <td colspan="3"><br></td>
                                </tr>
                                <tr>
                                    <td colspan="3"><strong class="text-blue">Berdasarkan Status</strong></td>
                                </tr>
                                <tr>
                                    <td> <i class="icon icon-information4 text-danger"></i> <strong>Proses</strong></td>
                                    <td>:</td>
                                    <td><?= $dispositionWidget['inDisProcess']; ?></td>
                                </tr>
                                <tr>
                                    <td><i class="icon icon-information4 text-danger"></i> <strong>Selesai</strong></td>
                                    <td>:</td>
                                    <td><?= $dispositionWidget['inDisFinish']; ?></td>
                                </tr>
                            </table>
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<br>



<br>
<div class="card">
    <div class="card-body">
        <strong class="text-blue">Grafik</strong>
        <hr style="border: 0.5px dashed #d2d6de">

        <div class="row">
            <div class="col-md-8">
                <div class="card border-primary">
                    <div class="card-header blue text-white">
                            <h6>Total Surat Dikelola <br><small>Bulanan</small></h6>
                        </div>
                    <div class="card-body p-0">
                        <div id="mail_on_month" style="width:100%; height:300px;"></div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card border-primary">
                    <div class="card-header blue text-white">
                        <h6>Total Surat Dikelola <br><small>Tahunan</small></h6>
                    </div>
                    <div class="card-body p-0">
                        <div id="mail_on_year" style="width:100%; height:300px;"></div>
                    </div>
                </div>
            </div>
        </div>

        <br>
        
        <?php if(session('user_role') == 1) : ?>
        <div class="row">
            <div class="col-md-8">
                <div class="card border-success">
                    <div class="card-header green text-white">
                            <h6>Trafik Akses <br><small>Satuan Jam</small></h6>
                        </div>
                    <div class="card-body p-0">
                        <div id="traffic_access" style="width:100%; height:300px;"></div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card border-success">
                    <div class="card-header green text-white">
                        <h6>Hit API TTE <br><small>Tahunan</small></h6>
                    </div>
                    <div class="card-body p-0">
                        <div id="hit_api_tte" style="width:100%; height:300px;"></div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <script>
            $( document ).ready(function() {
                $("#mail_on_month").length && Morris.Bar({
                    element: "mail_on_month",
                    data: [
                        <?php 
                            $arrMonth = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Aug','Sept','Okt','Nov','Des'];
                            for ($mom = 0; $mom < count($mailGraph); $mom++) { ?>
                            {period: "<?= $arrMonth[$mom];?>", inbox: <?= $mailGraph[$mom]['sm'];?>, outbox: <?= $mailGraph[$mom]['sk'];?>},
                        <?php } ?>
                    ],
                    xkey: "period",
                    barColors: ["#2979ff", "#34495E", "#ACADAC", "#3498DB"],
                    ykeys: ["inbox", "outbox"],
                    labels: ["Surat Masuk", "Surat Keluar"],
                    hideHover: "auto",
                    xLabelAngle: 60,
                    resize: !0
                });

                $("#mail_on_year").length && Morris.Donut({
                    element: "mail_on_year",
                    data: [{
                        label: "Surat Masuk",
                        value: <?= $mailWidget['inboxSkpdTotal'] + $mailWidget['inboxNonSkpdTotal']; ?>
                    }, {
                        label: "Surat Keluar",
                        value: <?= $mailWidget['outboxSkpdTotal'] + $mailWidget['outboxNonSkpdTotal']; ?>
                    },],
                    colors: ["#2979ff", "#34495E", "#ACADAC", "#3498DB"],
                    formatter: function(t) {
                        return t
                    },
                    resize: !0
                });


                $("#traffic_access").length && Morris.Bar({
                    element: "traffic_access",
                    data: [
                        <?php for ($i=0; $i < count($trafficGraph); $i++) { ?>
                            // {period: "<?= (strlen($i) == 1) ? '0'.$i .':00 - 0'.$i.':59' : $i .':00 - '.$i.':59'; ?>",access: <?= $trafficGraph[$i] ?>},
                            {period: "<?= (strlen($i) == 1) ? '0'.$i .':00' : $i .':00'; ?>",access: <?= $trafficGraph[$i] ?>},
                        <?php } ?>
                    ],
                    xkey       : "period",
                    barColors  : ["#34495E"],
                    ykeys      : ["access"],
                    labels     : ["Total Akses"],
                    hideHover  : "auto",
                    xLabelAngle: 60,
                    resize     : !0
                });

                $("#hit_api_tte").length && Morris.Donut({
                    element: "hit_api_tte",
                    data: [{
                        label: "SKPD",
                        value: <?= $mailWidget['outboxSkpdTotal']; ?>
                    }, {
                        label: "Non-SKPD",
                        value: <?= $mailWidget['outboxNonSkpdTotal']; ?>
                    },],
                    colors: ["#34495E", "#ACADAC"],
                    formatter: function(t) {
                        return t + " TTE "
                    },
                    resize: !0
                });
            });
        </script>

        


    </div>
</div>
<?= $this->endSection('content'); ?>