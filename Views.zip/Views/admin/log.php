<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>

<?= $this->section('content'); ?>
    
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
        </li>
        <li class="breadcrumb-item active"><?= $title; ?></li>
    </ol>
    <?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

    <div class="row">
        <div class="col-lg-12">
            <div class="card border-primary">
                <div class="card-header">
                    <h4><dt class="text-blue"><?= $title; ?></dt></h4>
                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="row">
                        <div class="col-lg-5">
                        <?= form_open('admin/log/search') ?>
                        <?= csrf_field(); ?>
                            <div class="input-group mb-3">
                                <input type="text" class="form-control form-control-sm" name="keyword" placeholder="Masukkan kata kunci pencarian" aria-label="Cari Berdasarakan Nama" aria-describedby="button-addon2">
                                <button class="btn btn-sm btn-outline-primary" type="submit"><i class="icon-search"></i></button>
                            </div>
                        <?= form_close(); ?>
                        </div>
                        <div class="col-lg-7">
                            <div class="float-right">
                                <a href="<?= site_url('admin/log/'); ?>" title="Refresh Halaman" class="btn btn-sm btn-success"><i class="icon-refresh"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?= (session('sess_log')) ? "<p>Kata Kunci Pencarian : <b class='text-danger'>". session('sess_log') ."</b></p>" : ''; ?></p>
                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <tbody>
                                <tr class="bg-primary text-white">
                                    <th style="width: 50px;">No</th>
                                    <th>Record Log</th>
                                </tr>

                                <?php $no=1 + (10 * ($currentPage - 1) ); foreach ($data as $key) : ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td>
                                        <span class="badge badge-danger"><?= $key['fullname']; ?></span>
                                        <span class="badge badge-success"><?= $key['time']; ?></span>
                                        <span class="badge badge-success"><?= $key['ipaddress']; ?></span>
                                        <br>
                                        <?= $key['message']; ?>
                                    </td>
                                </tr>
                                <?php endforeach ?>
                                
                            </tbody>
                        </table>
                    </div>
                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="float-left">
                        <p>Tampilkan <?= (($currentPage - 1) * 10) + count($data) ." dari ".$totalData." data"; ?> </p>
                    </div>
                    <?= $pager->links('default','default_pager'); ?>
                </div>
                <div class="card-footer bg-primary text-white">Page Rendered : {elapsed_time} second</div>
            </div>
        </div>
    </div>
<?= $this->endSection('content'); ?>