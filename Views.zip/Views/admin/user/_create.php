<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>


<?= $this->section('content'); ?>

    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#">Previllege Data</a>
        </li>
        <li class="breadcrumb-item">
            <a href="<?= site_url('admin/user/'); ?>"><?= $title; ?></a>
        </li>
        <li class="breadcrumb-item active"><?= ucfirst(current_url(true)->getSegment(4)); ?></li>
    </ol>
    <?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

    <div class="row">
        
        <div class="col-lg-12">
            <div class="card border-primary">
                <div class="card-header">
                    <h4><dt class="text-blue"><?= $title; ?></dt> <small>Tambah Data </small></h4>
                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="float-left">
                                <a href="<?= site_url('admin/user/'); ?>" class="btn btn-sm btn-success" title="Kembali Data"><i class="icon-arrow-left"></i></a>
                                <a href="<?= site_url('admin/user/form/create'); ?>" title="Refresh Halaman" class="btn btn-sm btn-success"><i class="icon-refresh"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?= form_open_multipart('admin/user/save/create', 'class="form-horizontal"'); ?>
                    <?= csrf_field(); ?>
                    
                    <input type="hidden" name="status" value="1">

                    <h3 class="text-blue">#Data Pengguna</h3>
                    <hr style="border: 0.5px dashed #d2d6de">

                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Nama Lengkap <b class="text-red">*</b></label>
                                <input type="text" class="form-control <?= ($validation->hasError('fullname')) ? 'is-invalid':''; ?>" placeholder="Nama Lengkap" name="fullname" value="<?= old('fullname'); ?>">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('fullname'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Email <b class="text-red">*</b></label>
                                <input type="text" class="form-control <?= ($validation->hasError('email')) ? 'is-invalid':''; ?>" placeholder="Email" name="email" value="<?= old('email'); ?>">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('email'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">NIP</label>
                                <input type="text" class="form-control <?= ($validation->hasError('nip')) ? 'is-invalid':''; ?>" placeholder="Nomor Induk Pegawai" name="nip" value="<?= old('nip'); ?>">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">SKPD <b class="text-red">*</b></label>
                                <select id="skpdselectajax" class="form-control select2 <?= ($validation->hasError('skpd_id')) ? 'is-invalid':''; ?>" name="skpd_id">
                                    <option value="">:: Pilih SKPD ::</option>
                                    <?php foreach ($dataSkpd as $skpd) : ?>
                                    
                                    <option value="<?= $skpd['id'] ?>"> <?= $skpd['name']; ?> </option>
                                        
                                    <?php endforeach ?>
                                </select>
                                <div class="invalid-feedback">
                                    <?= $validation->getError('skpd_id'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">   
                            <div class="mb-3">
                                <label class="form-label">Jabatan <b class="text-red">*</b></label>
                                <select id="positionselectajax" class="form-control select2 <?= ($validation->hasError('position_id')) ? 'is-invalid':''; ?>" name="position_id">
                                    <option value="">- Pilih Jabatan -</option>
                                    
                                </select>
                                <div class="invalid-feedback">
                                    <?= $validation->getError('position_id'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Unit Jabatan</label>
                                <input type="text" class="form-control <?= ($validation->hasError('unit')) ? 'is-invalid':''; ?>" placeholder="Unit Jabatan" name="unit" value="<?= old('unit'); ?>">
                            </div>
                        </div>

                        
                    </div>

                    <h3 class="text-blue">#Akun Pengguna</h3>
                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Username <b class="text-red">*</b></label>
                                <input type="text" class="form-control <?= ($validation->hasError('username')) ? 'is-invalid':''; ?>" placeholder="Username" name="username" value="<?= old('username'); ?>">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('username'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Password <b class="text-red">*</b></label>
                                <input type="password" class="form-control <?= ($validation->hasError('password')) ? 'is-invalid':''; ?>" placeholder="Password" name="password">
                                <div class="invalid-feedback">
                                    <?= $validation->getError('password'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Role <b class="text-red">*</b></label>
                                <select class="form-control select2 <?= ($validation->hasError('role_id')) ? 'is-invalid':''; ?>" name="role_id">
                                    <option value="">:: Pilih Role ::</option>
                                    <?php foreach ($dataRole as $role) : ?>
                                    <?php if (old('role_id')) : ?>
                                        <?php if (old('role_id') == $role['id']) : ?>
                                            <option value="<?= $role['id'] ?>" selected> <?= $role['role']; ?> </option>
                                        <?php else : ?>
                                            <option value="<?= $role['id'] ?>"> <?= $role['role']; ?> </option>
                                        <?php endif ?>
                                        
                                    <?php else : ?>
                                        <option value="<?= $role['id'] ?>"> <?= $role['role']; ?> </option>
                                    <?php endif ?>
                                    <?php endforeach ?>
                                </select>
                                <div class="invalid-feedback">
                                    <?= $validation->getError('role_id'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    

                    
                    <hr style="border: 0.5px dashed #d2d6de">
                    <input type="submit" class="btn btn-outline-primary" value="Tambah Data">
                    <?= form_close(); ?>
                    
                </div>
                <div class="card-footer bg-primary text-white">Page Rendered : {elapsed_time} second</div>
            </div>
        </div>
    </div>

<?= $this->endSection('content'); ?>