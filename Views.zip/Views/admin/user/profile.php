<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>


<?= $this->section('content'); ?>

<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
    </li>
    <li class="breadcrumb-item active">Profil Pengguna</li>
</ol>
<?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

<div class="row">
    <div class="col-lg-4">
        <div class="card border-info">
            <ul class="list-group list-group-flush">
                <li class="list-group-item">
                    <div class="image mr-3 float-left">
                        <img class="user_avatar img-preview" src="<?= base_url('upload/profile/'.((session('user_photo')) ? session('user_photo') : 'noimage.jpeg')); ?>" alt="User Image">
                    </div>
                    <div>
                        <h6 class="p-t-10"><?= $profile['username']; ?></h6>
                        <?= $profile['email']; ?>
                    </div>
                </li>
                <li class="list-group-item"><strong class="s-12 text-primary">Nama Pengguna</strong> <span class="float-right s-12"><?= $profile['fullname']; ?></span></li>
                <li class="list-group-item"><strong class="s-12 text-primary">Role</strong> <span class="float-right s-12"><?= $profile['role']; ?></span></li>
                <li class="list-group-item"><strong class="s-12 text-primary">Login Terakhir</strong> <span class="float-right s-12"><?= $profile['lastlogin']; ?></span></li>
                <li class="list-group-item">
                    
                    <?php foreach ($myLog as $key) : ?>
                        <div class="activity-item activity-warning">
                            <div class="activity-content">
                                <small class="text-success"><b><?= timeElapsed($key['time']); ?></b></small>
                                <p><?= $key['message']; ?></p>
                            </div>
                        </div>
                    <?php endforeach ?>  
                        
                </li>
            </ul>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="card border-info">
            <div class="card-header bg-primary text-white">
                <h6> PROFILE : <?= strtoupper(session('user_name')); ?> </h6>
            </div>
            <div class="card-body">
                <?= form_open_multipart('admin/profile/save', 'class="form-horizontal"'); ?>
                <?= csrf_field(); ?>
                <input type="hidden" name="old_photo" value="<?= $profile['photo']; ?>">
                <input type="hidden" name="password" value="<?= session('user_password'); ?>">

                <div class="form-group">
                    <label for="inputName" class="control-label">Nama Pengguna</label>
                    <div class="focused">
                        <input class="form-control <?= ($validation->hasError('fullname')) ? 'is-invalid':''; ?>" placeholder="Nama Pengguna" type="text" name="fullname" value="<?= (old('fullname')) ? old('fullname') : $profile['fullname']; ?>">
                        <div class="invalid-feedback">
                            <?= $validation->getError('fullname'); ?>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputName" class="control-label">Email Pengguna</label>
                    <div class="focused">
                        <input class="form-control <?= ($validation->hasError('email')) ? 'is-invalid':''; ?>" placeholder="Email Pengguna" type="text" name="email" value="<?= (old('email')) ? old('email') : $profile['email']; ?>">
                        <div class="invalid-feedback">
                            <?= $validation->getError('email'); ?>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputName" class="control-label">Foto Pengguna</label>
                    <div class="focused">
                        <input id="image" class="form-control <?= ($validation->hasError('photo')) ? 'is-invalid':''; ?>" placeholder="Foto Pengguna" type="file" name="photo" value="<?= (old('photo')) ? old('photo') : $profile['photo']; ?>" onchange="previewImage()">
                        <div class="invalid-feedback">
                            <?= $validation->getError('photo'); ?>
                        </div>
                    </div>
                </div>

                <hr>
                <p class="text-info">#catatan : silahkan <b>kosongkan field password dibawah</b> jika tidak ingin mengubah password anda</p>
                <div class="form-group">
                    <label for="inputName" class="control-label">Password Lama</label>
                    <div class="focused">
                        <input class="form-control" placeholder="Password Lama" type="password" name="old_password">
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputName" class="control-label">Password Baru</label>
                    <div class="focused">
                        <input class="form-control" placeholder="Password Baru" type="password" name="new_password">
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputName" class="control-label">Konfirmasi Password Baru</label>
                    <div class="focused">
                        <input class="form-control" placeholder="Password Baru" type="password" name="validate_new_password">
                    </div>
                </div>

                <hr>
                <input type="submit" class="btn btn-success btn-block" value="Update Porfile">

                <?= form_close(); ?>
            </div>
            <div class="card-footer">Page Rendered : {elapsed_time} second</div>
        </div>
    </div>
</div>

<script>
      function previewImage() {
        const image      = document.querySelector('#image');
        const imgPreview = document.querySelector('.img-preview');

        const imgOrigin  = new FileReader();
        imgOrigin.readAsDataURL(image.files[0]);
        imgOrigin.onload = function (e) {
          imgPreview.src = e.target.result;
        }
      }
        

    </script>

<?= $this->endSection('content'); ?>