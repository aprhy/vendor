<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>


<?= $this->section('content'); ?>

    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#">Previllege Data</a>
        </li>
        <li class="breadcrumb-item active"><?= $title; ?></li>
    </ol>
    <?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

    <div class="row">
        
        <div class="col-lg-12">
            <div class="card border-primary">
                <div class="card-header">
                    <h4><dt class="text-blue"><?= $title; ?></dt></h4>
                    <hr style="border: 0.5px dashed #d2d6de">

                    <div class="row">
                        <div class="col-lg-5">
                        <?= form_open('admin/user/search') ?>
                        <?= csrf_field(); ?>
                            <div class="input-group mb-3">
                                <input type="text" class="form-control form-control-sm" name="keyword" placeholder="Masukkan kata kunci pencarian" aria-label="Cari Berdasarakan Nama" aria-describedby="button-addon2">
                                <button class="btn btn-sm btn-outline-primary" type="submit"><i class="icon-search"></i></button>
                            </div>
                        <?= form_close(); ?>
                        </div>
                        <div class="col-lg-7">
                            <div class="float-right">
                                <a href="<?= site_url('admin/user/form/create'); ?>" class="btn btn-sm btn-primary" title="Tambah Data">Tambah Data</a>
                                <a href="<?= site_url('admin/user/'); ?>" title="Refresh Halaman" class="btn btn-sm btn-success"><i class="icon-refresh"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?= (session('sess_user')) ? "<p>Kata Kunci Pencarian : <b class='text-danger'>". session('sess_user') ."</b></p>" : ''; ?></p>
                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped table-hover">
                            <tbody>
                                <tr class="bg-primary text-white">
                                    <th style="width: 50px;">No</th>
                                    <th style="width: 20%;">#aksi</th>
                                    <th>Pengguna</th>
                                    <th>NIP</th>
                                    <th>SKPD</th>
                                    <th>Role</th>
                                </tr>
                                <?php $no=1 + (10 * ($currentPage - 1) ); foreach ($data as $key) : ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td>
                                        <a href="<?= site_url('admin/user/form/update/'.$key['id'].'/'.$key['skpd_id']); ?>" class="btn btn-xs btn-warning">update</a>
                                        <button class="btn btn-xs btn-danger" data-toggle="modal" data-target="#deleteModal<?= $key['id'];?>">delete</button> |
                                        
                                        <?php if($key['status'] == 0) { ?>
                                            <a href="<?= site_url('admin/user/status/1/'.$key['id']); ?>" class="btn btn-xs btn-success" title="Aktifkan"><i class="icon-check-circle"></i></a>
                                        <?php }elseif($key['status'] == 1){?>
                                            <a href="<?= site_url('admin/user/status/0/'.$key['id']); ?>" class="btn btn-xs btn-danger" title="Non-Aktifkan"><i class="icon-minus-circle"></i></a>
                                        <?php } ?>
                                    </td>
                                    <td>
                                        <strong class="text-blue"><?= $key['fullname']; ?></strong><br>
                                        <small><?= $key['username']; ?></small>
                                    </td> 
                                    <td>
                                        <?= ($key['status'] == 0) ? '<span class="icon icon-circle text-danger"></span> Non-Aktif' : '<span class="icon icon-circle s-9 text-success"></span> Aktif'; ?> <br>
                                        <span class="r-3 badge badge-success "><?= ($key['nip'] != '') ? $key['nip'] : ''; ?></span>
                                    </td>
                                    <td>
                                        <?= $key['position_name']; ?> <br> 
                                        <small><?= $key['skpd_name']; ?></small>
                                    </td>
                                    <td>   
                                    <?= $key['role']; ?>
                                    
                                    </td>
                                    
                                </tr>

                                <!-- Modal -->
                                <div class="modal fade" id="deleteModal<?= $key['id'];?>" data-backdrop="false" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header bg-danger text-white">
                                                <h5 class="modal-title" id="deleteModalLabel">Hapus Data</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <?= form_open_multipart('admin/user/delete', 'class="form-horizontal"'); ?>
                                                <?= csrf_field(); ?>
                                                    <input type="hidden" value="<?= $key['id']; ?>" name="id">
                                                    <input type="hidden" value="<?= $key['photo']; ?>" name="photo">
                                                    Apakah anda yakin akan menghapus data ini ?<br>
                                                    <b>Fullname : <?= $key['fullname']; ?></b>
                                                    <hr style="border: 0.5px dashed #d2d6de">
                                                    <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-danger">Ya, Hapus</button>
                                                <?= form_close(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>

                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="float-left">
                        <p>Tampilkan <?= (($currentPage - 1) * 10) + count($data) ." dari ".$totalData." data"; ?> </p>
                    </div>
                    <?= $pager->links('default','default_pager'); ?>
                </div>
                <div class="card-footer bg-primary text-white">Page Rendered : {elapsed_time} second</div>
            </div>
        </div>
    </div>

<?= $this->endSection('content'); ?>