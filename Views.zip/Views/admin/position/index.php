<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>


<?= $this->section('content'); ?>

    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#">Core Data</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#"><?= $title; ?></a>
        </li>
        <li class="breadcrumb-item">
            <a href="#">Struktur Jabatan</a>
        </li>
        <li class="breadcrumb-item active"><?= $dataSkpd['name']; ?></li>
    </ol>
    <?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

    <div class="row">
        
        <div class="col-lg-12">
            <div class="card border-primary">
                <div class="card-header">
                    <h4><dt class="text-blue"><?= $title; ?></dt> <small><?= $dataSkpd['name']; ?></small></h4>
                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="float-left">
                                <a href="<?= site_url('admin/skpd/'); ?>" title="Kembali" class="btn btn-sm btn-success"><i class="icon-arrow-left"></i></a>
                                <a href="<?= site_url('admin/position/index/'.$dataSkpd['id']); ?>" title="Refresh Halaman" class="btn btn-sm btn-success"><i class="icon-refresh"></i></a>
                                <?php if (!$data) : ?>
                                    <button class="btn btn-sm btn-primary" title="Tambah Data" data-toggle="modal" data-target="#addModal">Tambah Data</button>
                                    
                                    <!-- Modal -->
                                    <div class="modal fade" id="addModal" data-backdrop="false" aria-labelledby="deleteModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="deleteModalLabel">Tambah Data</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <?= form_open_multipart('admin/position/save/create', 'class="form-horizontal"'); ?>
                                                    <?= csrf_field(); ?>

                                                        <input type="hidden" name="skpd_id" value="<?= $dataSkpd['id']; ?>">
                                                        <input type="hidden" name="positionclass_id" value="1">
                                                        <input type="hidden" name="leader" value="1">
                                                        
                                                        <div class="mb-3">
                                                            <label class="form-label">Nama Jabatan *</label>
                                                            <input type="text" class="form-control" placeholder="Nama Jabatan" name="name" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label">Atasan *</label>
                                                            <select class="form-control select2" name="parent">
                                                                <option value="">:: Pilih Atasan ::</option>
                                                                <option value="0">Tidak Ada</option>
                                                                <option value="1">Gubernur</option>
                                                                <option value="2">Wakil Gubernur</option>
                                                                <option value="3">Sekretaris Daerah</option>
                                                                
                                                            </select>
                                                        </div>

                                                        <hr style="border: 0.5px dashed #d2d6de">
                                                        <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Batal</button>
                                                        <button type="submit" class="btn btn-success">Tambah</button>
                                                    <?= form_close(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body" style="min-height: 500px;">
                    
                    <hr style="border: 0.5px dashed #d2d6de">
                    <?= (!$data) ? '' : $data; ?>
                    
                </div>
                <div class="card-footer bg-primary text-white">Page Rendered : {elapsed_time} second</div>
            </div>
        </div>
    </div>

<?= $this->endSection('content'); ?>