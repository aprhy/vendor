<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>


<?= $this->section('content'); ?>

    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#">Core Data</a>
        </li>
        <li class="breadcrumb-item">
            <a href="<?= site_url('admin/draft/'); ?>"><?= $title; ?></a>
        </li>
        <li class="breadcrumb-item active"><?= ucfirst(current_url(true)->getSegment(4)); ?></li>
    </ol>
    <?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

    <div class="row">
        
        <div class="col-lg-12">
            <div class="card border-primary">
                <div class="card-header">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="float-left">
                                <a href="<?= site_url('admin/draft/'); ?>" class="btn btn-sm btn-success" title="Kembali Data"><i class="icon-arrow-left"></i></a>
                                <a href="<?= site_url('admin/draft/form/create'); ?>" title="Refresh Halaman" class="btn btn-sm btn-success"><i class="icon-refresh"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?= form_open_multipart('admin/draft/save/create', 'class="form-horizontal"'); ?>
                    <?= csrf_field(); ?>

                    <div class="mb-3">
                        <label class="form-label">Klasifikasi Surat</label>
                        <input type="text" class="form-control <?= ($validation->hasError('name')) ? 'is-invalid':''; ?>" placeholder="Klasifikasi Surat" name="name" value="<?= old('name'); ?>">
                        <div class="invalid-feedback">
                            <?= $validation->getError('name'); ?>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Draft Surat</label>
                        <textarea id="editor" class="form-control <?= ($validation->hasError('draft')) ? 'is-invalid':''; ?>" name="draft" placeholder="Draft Surat"><?= old('draft'); ?></textarea>
                        <div class="invalid-feedback">
                            <?= $validation->getError('draft'); ?>
                        </div>
                    </div>

                    <hr style="border: 0.5px dashed #d2d6de">
                    <input type="submit" class="btn btn-outline-primary" value="Tambah Data">
                    <?= form_close(); ?>
                    
                </div>
                <div class="card-footer bg-primary text-white">Page Rendered : {elapsed_time} second</div>
            </div>
        </div>

        <script>
            $(document).ready(function() {
                CKEDITOR.replace('editor',{
                    toolbar : 'MyToolbar',
                    width:"100%",
                    height:800,
                    filebrowserBrowseUrl : '<?= base_url('assets/plugin/ckfinder/ckfinder.html');?>',
                    filebrowserImageBrowseUrl : '<?= base_url('assets/plugin/ckfinder/ckfinder.html?type=Images');?>',
                    filebrowserFlashBrowseUrl : '<?= base_url('assets/plugin/ckfinder/ckfinder.html?type=Flash');?>',
                });
            });
        </script>
    </div>

<?= $this->endSection('content'); ?>