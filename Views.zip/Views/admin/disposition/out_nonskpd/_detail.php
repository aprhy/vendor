<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>


<?= $this->section('content'); ?>

    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#">Disposisi Surat</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#"><?= $title; ?></a>
        </li>
        <li class="breadcrumb-item"><a href="#"><?= $data[0]['number']; ?></a></li>
        <li class="breadcrumb-item active"><?= ucfirst(current_url(true)->getSegment(3)); ?></li>
    </ol>
    <?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : session()->getFlashdata('alert'); ?>

    <div class="row">
        
        <div class="col-lg-12">
            <div class="card no-b">
                <div class="card-header green darken-1 text-white">
                    <h4><i class="icon-mail-envelope-open2 mr-2 mb-5"></i>Detail Surat Disposisi :: <?= $data[0]['number']; ?></h4>
                    <div class="d-flex justify-content-between">
                        <div class="align-self-end">
                            <ul class="nav nav-material nav-material-white card-header-tabs" role="tablist">
                                <li class="nav-item">
                                    <a href="<?= site_url('admin/disposition/detail/'. current_url(true)->getSegment(4) .'/'. current_url(true)->getSegment(5). '/'. current_url(true)->getSegment(6)); ?>" class="nav-link show active"  role="tab">File Surat</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="w6--tab2" data-toggle="tab" href="#w6-tab2" role="tab" aria-controls="tab2" aria-selected="false">Data Surat</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="w6--tab3" data-toggle="tab" href="#w6-tab3" role="tab" aria-controls="tab3" aria-selected="false">Log Disposisi Surat</a>
                                </li>
                            </ul>
                            <a href="<?= site_url('admin/disposition/index/'. current_url(true)->getSegment(4) .'/'. current_url(true)->getSegment(5)); ?>" class="btn-fab btn-fab fab-right-bottom absolute shadow btn-primary"><i class="icon-arrow-left s-14"></i></a>
                        </div>

                    </div>
                </div>
                <div class="card-body no-p">
                    <div class="tab-content" id="v-pills-tabContent2">
                        <div class="tab-pane fade active show p-5" id="w6-tab1" role="tabpanel" aria-labelledby="w6-tab1">
                            
                            <!-- <?php if ($data[0]['status'] != 'selesai') : ?>
                                <?php if ($action['stateButton'] == 'tte') : ?>
                                    <button class="btn btn-danger" data-toggle="modal" data-target="#TTEModal<?= $data[0]['id'];?>"><?= $action['btnName']; ?></button>
                                <?php else : ?>
                                    <button class="btn btn-success" data-toggle="modal" data-target="#forwardModal<?= $data[0]['id'];?>"><?= $action['btnName']; ?></button>
                                <?php endif ?>
                                
                            <?php endif ?> -->

                            <?php if ($data[0]['status'] != 'selesai') : ?>
                                <?php if ($action['stateButton'] == 'tte') : ?>
                                    <button class="btn btn-danger" data-toggle="modal" data-target="#TTEModal<?= $data[0]['id'];?>"><?= $action['btnName']; ?></button>
                                    <button class="btn btn-warning" data-toggle="modal" data-target="#repairModal<?= $data[0]['id'];?>">Perbaikan</button>
                                <?php else : ?>
                                    <button class="btn btn-success" data-toggle="modal" data-target="#forwardModal<?= $data[0]['id'];?>"><?= $action['btnName']; ?></button>
                                    <?php if (session('user_role') != 3) : ?>
                                        <button class="btn btn-warning" data-toggle="modal" data-target="#repairModal<?= $data[0]['id'];?>">Perbaikan</button>
                                    <?php else : ?>
                                        <a href="<?= site_url('admin/mail/form/update/out_nonskpd/pdf/'.$data[0]['draft_id'].'/'.$data[0]['mail_id']); ?>" class="btn btn-danger" >Lakukan Perbaikan</a>
                                    <?php endif ?>

                                    
                                <?php endif ?>
                            <?php endif ?>
                            
                            <div class="modal fade" id="forwardModal<?= $data[0]['id'];?>" data-backdrop="false" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-success text-white">
                                            <h5 class="modal-title" id="deleteModalLabel">Teruskan Ke Pimpinan</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <?= form_open_multipart('admin/disposition/forward/'. current_url(true)->getSegment(4).'/'. current_url(true)->getSegment(5), 'class="form-horizontal"'); ?>
                                            <?= csrf_field(); ?>
                                                <input type="hidden" value="<?= $data[0]['mail_id']; ?>" name="mail_id">
                                                <input type="hidden" value="<?= $action['stateButton']; ?>" name="action">
                                                <input type="hidden" value="<?= $data[0]['id']; ?>" name="id">
                                                
                                                Apakah anda yakin akan meneruskan data ini kepada pimpinan anda ?<br><br>
                                                <b>Jenis Surat :</b><br> <?= $data[0]['name']; ?><br><br>
                                                <b>Nomor Surat :</b><br> <?= $data[0]['number'].' | '.$data[0]['agenda']; ?><br><br>
                                                <b>Perihal Surat :</b><br> <?= $data[0]['about']; ?><br><br>
                                                
                                                <hr style="border: 0.5px dashed #d2d6de">
                                                <textarea placeholder="Pesan pada pimpinan" class="form-control" name="message" rows="4"></textarea>

                                                <hr style="border: 0.5px dashed #d2d6de">
                                                <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-success">Ya, Teruskan</button>
                                            <?= form_close(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="modal fade" id="TTEModal<?= $data[0]['id'];?>" data-backdrop="false" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-danger text-white">
                                            <h5 class="modal-title" id="deleteModalLabel">TTE Surat</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <?= form_open_multipart('admin/disposition/forward/'. current_url(true)->getSegment(4).'/'. current_url(true)->getSegment(5), 'class="form-horizontal"'); ?>
                                            <?= csrf_field(); ?>
                                                <input type="hidden" value="<?= $data[0]['mail_id']; ?>" name="mail_id">
                                                <input type="hidden" value="<?= $data[0]['file']; ?>" name="file">
                                                <input type="hidden" value="<?= $action['stateButton']; ?>" name="action">
                                                <input type="hidden" value="<?= $data[0]['id']; ?>" name="id">
                                                
                                                Apakah anda yakin akan melakukan TTE pada Surat ini ?<br><br>
                                                <b>Jenis Surat :</b><br> <?= $data[0]['name']; ?><br><br>
                                                <b>Nomor Surat :</b><br> <?= $data[0]['number'].' | '.$data[0]['agenda']; ?><br><br>
                                                <b>Perihal Surat :</b><br> <?= $data[0]['about']; ?><br><br>
                                                
                                                <hr style="border: 0.5px dashed #d2d6de">
                                                <div class="mb-3">
                                                    <label class="form-label">Username TTE</label>
                                                    <input type="text" class="form-control" placeholder="Username TTE" name="username_tte">
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Password TTE</label>
                                                    <input type="password" class="form-control" placeholder="Password TTE" name="password_tte">
                                                </div>

                                                <hr style="border: 0.5px dashed #d2d6de">
                                                <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-success">Ya, TTE Surat</button>
                                            <?= form_close(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="modal fade" id="repairModal<?= $data[0]['id'];?>" data-backdrop="false" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-warning text-white">
                                            <h5 class="modal-title" id="deleteModalLabel">Ajukan Perbaikan</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <?= form_open_multipart('admin/disposition/repair/'. current_url(true)->getSegment(4).'/'. current_url(true)->getSegment(5), 'class="form-horizontal"'); ?>
                                            <?= csrf_field(); ?>
                                                <input type="hidden" value="<?= $data[0]['mail_id']; ?>" name="mail_id">
                                                <input type="hidden" value="<?= $data[0]['id']; ?>" name="id">
                                                
                                                Apakah anda yakin akan mengajukan perbaikan pada surat ini ? Jika iya, silahkan berikan keterangan/pesan kepada staff mengenai perbaikan surat.<br><br>
                                                <b>Jenis Surat :</b><br> <?= $data[0]['name']; ?><br><br>
                                                <b>Nomor Surat :</b><br> <?= $data[0]['number'].' | '.$data[0]['agenda']; ?><br><br>
                                                <b>Perihal Surat :</b><br> <?= $data[0]['about']; ?><br><br>
                                                
                                                <hr style="border: 0.5px dashed #d2d6de">
                                                <textarea placeholder="Pesan perbaikan" class="form-control" name="message" rows="4"></textarea>

                                                <hr style="border: 0.5px dashed #d2d6de">
                                                <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-warning">Ya, Ajukan Perbaikan</button>
                                            <?= form_close(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <hr style="border: 0.5px dashed #d2d6de">

                            <object data="<?= base_url(); ?>/upload/mail/<?= $data[0]['file']; ?>" type="application/pdf" width="100%" height="850px"></object>
                        </div>
                        <div class="tab-pane fade p-5" id="w6-tab2" role="tabpanel" aria-labelledby="w6-tab2">
                            <strong class="text-blue">Nomor Surat / Agenda :</strong><br>
                            <?= $data[0]['number']; ?> | <?= $data[0]['agenda']; ?><br><br>

                            <strong class="text-blue">Tanggal Surat :</strong><br>
                            <?= indonesianDate($data[0]['date']); ?><br><br>

                            <strong class="text-blue">Perihal :</strong><br>
                            <?= $data[0]['about']; ?><br><br>

                            <strong class="text-blue">Ringkasan :</strong><br>
                            <?= $data[0]['summary']; ?><br><br>

                            <strong class="text-blue">Penerima / Tujuan Surat :</strong><br>
                            <?= $data[0]['destination_nonskpd']; ?>
                            <br><br>

                            <strong class="text-blue">Penandatangan TTE :</strong><br>
                            <?= strtoupper($data[0]['sign']); ?><br><br>
                        </div>
                        <div class="tab-pane fade p-5" id="w6-tab3" role="tabpanel" aria-labelledby="w6-tab3">
                            <div class="table-responsive">
                                <table class="table table-hover earning-box">
                                    <tbody>
                                        <tr class="text-white" style="background-color: #2979ff;">
                                            <td>Dari</td>
                                            <td>Ke</td>
                                            <td>Waktu Disposisi</td>
                                            <td>Status</td>
                                            <td>Catatan</td>
                                        </tr>
                                        <?php foreach ($dataDisposition as $disposition) : ?>
                                        
                                        <tr class="no-b">
                                            <td>
                                                <h6><?= $disposition['sender']; ?></h6>
                                                <small class="text-muted"><?= $disposition['position_sender']; ?></small>
                                            </td>
                                            <td>
                                                <h6><?= $disposition['receiver']; ?></h6>
                                                <small class="text-muted"><?= $disposition['position_receiver']; ?></small>
                                            </td>
                                            <td><?= indonesianDate($disposition['created_at']); ?></td>
                                            <td><?= $disposition['status']; ?></td>
                                            <td><?= $disposition['message']; ?></td>
                                        </tr>

                                        <?php endforeach ?>
                                    
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                
            </div>
        </div>
    </div>
    
    <?= $this->endSection('content'); ?>