<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>


<?= $this->section('content'); ?>

    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#">Disposisi Surat</a>
        </li>
        <li class="breadcrumb-item"><a href="#"><?= $title; ?></a></li>
        <li class="breadcrumb-item active"><?= ucfirst(current_url(true)->getSegment(5)); ?></li>
    </ol>
    <?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

    <div class="row">
        
        <div class="col-lg-12">
            <div class="card border-primary">
                <div class="card-header">
                    <h4><dt class="text-blue"><?= (current_url(true)->getSegment(4) == 'in') ? 'Disposisi Surat Masuk SKPD':'Disposisi Surat Masuk Non-SKPD'; ?></dt> <small><?= ucfirst(current_url(true)->getSegment(5)); ?> </small></h4>
                    <hr style="border: 0.5px dashed #d2d6de">

                    <div class="row">
                        <div class="col-lg-5">
                        <?= form_open('admin/disposition/search/'.current_url(true)->getSegment(4).'/'.current_url(true)->getSegment(5)) ?>
                        <?= csrf_field(); ?>
                            <div class="input-group mb-3">
                                <input type="text" class="form-control form-control-sm" name="keyword" placeholder="Masukkan kata kunci pencarian" aria-label="Cari Berdasarakan Nama" aria-describedby="button-addon2">
                                <button class="btn btn-sm btn-outline-primary" type="submit"><i class="icon-search"></i></button>
                            </div>
                        <?= form_close(); ?>
                        </div>
                        <div class="col-lg-7">
                            <div class="float-right">
                                <a href="<?= site_url('admin/disposition/index/in/proses'); ?>" title="Data Surat Keluar" class="btn btn-sm <?= (current_url(true)->getSegment(4) == 'in') ? 'btn-primary':'btn-outline-primary'; ?>">Disposisi Masuk (SKPD)</a>
                                <a href="<?= site_url('admin/disposition/index/in_nonskpd/proses'); ?>" title="Data Surat Keluar" class="btn btn-sm <?= (current_url(true)->getSegment(4) == 'in_nonskpd') ? 'btn-primary':'btn-outline-primary'; ?> ">Disposisi Masuk (Non-SKPD)</i></a>
                                <a href="<?= site_url('admin/disposition/index/in/proses'); ?>" title="Refresh Halaman" class="btn btn-sm btn-success"><i class="icon-refresh"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    
                    <?= (session('sess_disposition')) ? "<p>Kata Kunci Pencarian : <b class='text-danger'>". session('sess_disposition') ."</b></p>" : ''; ?></p>
                    
                    <a href="<?= site_url('admin/disposition/index/'.current_url(true)->getSegment(4).'/proses'); ?>" title="Surat Status Draft" class="btn btn-xs <?= (current_url(true)->getSegment(5) == 'proses') ? 'btn-success':'btn-outline-success'; ?>">proses</a>
                    <!-- <a href="<?= site_url('admin/disposition/index/'.current_url(true)->getSegment(4).'/perbaikan'); ?>" title="Surat Status Disposisi" class="btn btn-xs <?= (current_url(true)->getSegment(5) == 'perbaikan') ? 'btn-success':'btn-outline-success'; ?>">perbaikan</a> -->
                    <a href="<?= site_url('admin/disposition/index/'.current_url(true)->getSegment(4).'/selesai'); ?>" title="Surat Status Selesai" class="btn btn-xs <?= (current_url(true)->getSegment(5) == 'selesai') ? 'btn-success':'btn-outline-success'; ?>">selesai</a>

                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped table-hover">
                            <tbody>
                                <tr class="bg-primary text-white">
                                    <th style="width: 50px;">No</th>
                                    <th style="width: 10%;">#aksi</th>
                                    <th>Nomor</th>
                                    <th>Perihal</th>
                                    <th>Pengirim Disposisi</th>
                                </tr>
                                <?php $no=1 + (10 * ($currentPage - 1) ); foreach ($data as $key) : ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td>
                                        <a href="<?= site_url('admin/disposition/detail/'. current_url(true)->getSegment(4). '/'. current_url(true)->getSegment(5) .'/'. $key['mail_id']); ?>" class="btn btn-xs btn-primary">detail</a>
                                    </td>
                                    <td>
                                        <span class="badge badge-primary">Surat : <?= $key['number']; ?></span><br>
                                        <span class="badge badge-primary">Agenda : <?= $key['agenda']; ?></span>
                                    </td>
                                    <td>
                                        <?= $key['about']; ?><br>
                                        <span class="badge badge-success"><?= $key['name']; ?></span>
                                    </td>
                                    <td>
                                        <?= $key['sender']; ?><br>
                                        <strong> Catatan :</strong> <?= $key['message']; ?>
                                    </td>
                                </tr>

                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>

                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="float-left">
                        <p>Tampilkan <?= (($currentPage - 1) * 10) + count($data) ." dari ".$totalData." data"; ?> </p>
                    </div>
                    <?= $pager->links('default','default_pager'); ?>
                </div>
                <div class="card-footer bg-primary text-white">Page Rendered : {elapsed_time} second</div>
            </div>
        </div>
    </div>

<?= $this->endSection('content'); ?>