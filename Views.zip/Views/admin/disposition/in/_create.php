<!-- Reload Template -->
<?= $this->extend('templates/backend'); ?>


<?= $this->section('content'); ?>

    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?= site_url('admin/dashboard/'); ?>">Home</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#">Disposisi Surat</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#"><?= $title; ?></a>
        </li>
        <li class="breadcrumb-item">
            <a href="#"><?= $data[0]['name']; ?></a>
        </li>
        <li class="breadcrumb-item">
            <a href="#"><?= $data[0]['number']; ?></a>
        </li>
        <li class="breadcrumb-item">
           Buat Disposisi
        </li>
    </ol>
    <?= (session()->getFlashdata('alert')) ? session()->getFlashdata('alert') : ''; ?>

    <div class="row">
        
        <div class="col-lg-12">
            <div class="card border-primary">
                <div class="card-header">
                    <h4><dt class="text-blue"><?= (current_url(true)->getSegment(4) == 'in') ? 'Disposisi Surat Masuk SKPD':' Disposisi Surat Masuk Non-SKPD'; ?></dt> <small>Buat Disposisi </small></h4>
                    <hr style="border: 0.5px dashed #d2d6de">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="float-left">
                                <a href="<?= site_url('admin/disposition/detail/'.current_url(true)->getSegment(4).'/'.current_url(true)->getSegment(5).'/'.current_url(true)->getSegment(6)); ?>" class="btn btn-sm btn-success" title="Kembali Data"><i class="icon-arrow-left"></i></a>
                                <a href="<?= site_url('admin/disposition/create/'.current_url(true)->getSegment(4).'/'.current_url(true)->getSegment(5).'/'.current_url(true)->getSegment(6)); ?>" title="Refresh Halaman" class="btn btn-sm btn-success"><i class="icon-refresh"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?= form_open_multipart('admin/disposition/save/'.current_url(true)->getSegment(4).'/'.current_url(true)->getSegment(5) , 'class="form-horizontal"'); ?>
                    <?= csrf_field(); ?>
                    
                    <input type="hidden" name="mail_id" value="<?= $data[0]['mail_id']; ?>">
                    <input type="hidden" name="id" value="<?= $data[0]['id']; ?>">

                    <strong class="text-blue">Pilih Target Disposisi</strong>
                    <hr style="border: 0.5px dashed #d2d6de">

                    <div class="row">
                        

                        <?php
                            $instruksi = [
                                "Hadiri dan Laporkan",
                                "Teliti dan Tindak Lanjut",
                                "Ikuti Perkembangannya"	,
                                "Pedomani",
                                "Siapkan Konsep Surat",
                                "Siapkan Konsep Laporan",
                                "Berikan Pertimbangan Pada Pemimpin",
                                "Laksanakan Sesuai isi Surat/Maksud Surat",
                                "Konsultasi Dengan ......",
                                "Diagendakan",
                                "Untuk Digandakan",
                                "Untuk Diketahui",
                                "File Khusus",
                                "Diproses sesuai peraturan",
                                "Teruskan Kepada ....",
                                "Kordinasikan dengan Bidang-Bidang",
                            ];
                        ?>

                        <div class="col-md-12">
                            
                                <?php $no=0; foreach ($dataChild as $child) : ?>

                                    <input type="hidden" name="position[<?= $no; ?>]" value="<?= $child['position_id']; ?>">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="mb-3">
                                                <div class="form-check">
                                                    <input class="form-check-input gubernur" type="checkbox" value="<?= $child['id']; ?>" name="receiver[<?= $no; ?>]">
                                                    <label class="form-check-label text-red" for="defaultCheck1">
                                                        <?= $child['fullname']; ?>
                                                    </label>
                                                </div> 
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Instruksi</label>
                                                <select class="form-control select2" name="instruksi[<?= $no; ?>]">
                                                    <?php for($i = 0; $i < count($instruksi); $i++) { ?>
                                                    <option value="<?= $instruksi[$i]; ?>"><?= $instruksi[$i]; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="mb-3">
                                                <label class="form-label">Detail Instruksi</label>
                                                <textarea class="form-control" rows="3" name="message[<?= $no; ?>]" placeholder="Masukkan Detail Instruksi"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    <hr>
                                <?php $no++; endforeach ?>
                            
                        </div>
                        
                    </div>

                    <hr style="border: 0.5px dashed #d2d6de">
                    <input type="submit" class="btn btn-outline-primary" value="Tambah Data">
                    <?= form_close(); ?>
                    
                </div>
                <div class="card-footer bg-primary text-white">Page Rendered : {elapsed_time} second</div>
            </div>
        </div>
        
        
        

    </div>

<?= $this->endSection('content'); ?>