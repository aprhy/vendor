
<!DOCTYPE html>
<html lang="zxx">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="<?= base_url("upload/setting/".$setting['logo']); ?>" type="image/x-icon">
        <title><?= $setting['appname_short']." :: ".$title; ?></title>
        
        <!-- CSS -->
        <link rel="stylesheet" href="<?= base_url('assets/css/app.css'); ?>">
        <style>
            .loader {
                position: fixed;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: #F5F8FA;
                z-index: 9998;
                text-align: center;
            }

            .plane-container {
                position: absolute;
                top: 50%;
                left: 50%;
            }

            hr {
                background-color: #1240b1;
            }
        </style>
        
    </head>
    <body class="light">

        <!-- PRE-LOADER -->
        <div id="loader" class="loader">
            <div class="plane-container">
                <div class="preloader-wrapper big active">
                    <div class="spinner-layer spinner-blue">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div><div class="gap-patch">
                        <div class="circle"></div>
                    </div><div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                    </div>

                    <div class="spinner-layer spinner-red">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div><div class="gap-patch">
                        <div class="circle"></div>
                    </div><div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                    </div>

                    <div class="spinner-layer spinner-yellow">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div><div class="gap-patch">
                        <div class="circle"></div>
                    </div><div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                    </div>

                    <div class="spinner-layer spinner-green">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div><div class="gap-patch">
                        <div class="circle"></div>
                    </div><div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- APPS -->
        <div id="app">
            <main>
                <div id="primary" class="blue4 p-t-b-100 height-full responsive-phone">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">
                                <img src="<?= base_url('assets/img/icon/icon-stone.png'); ?>" alt="">
                            </div>
                            <div class="col-lg-6 p-t-100">
                                <div class="text-white">
                                    <h1>E-OFFICE SULTRA</h1>
                                    <p class="s-18 p-t-b-20 font-weight-lighter">Silahkan masukkan email anda yang terdaftar pada sistem untuk mereset akun anda</p>
                                </div>
                                <form action="">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group has-icon"><i class="icon-envelope"></i>
                                                <input type="text" class="form-control form-control-lg no-b" placeholder="Email">
                                            </div>
                                        </div>
                                        
                                        <div class="col-lg-12">
                                            <input type="submit" class="btn btn-danger btn-lg btn-block" value="Reset Akun">
                                        </div>
                                    </div>
                                </form>
                                
                                <hr>
                                
                                <p class="text-white">
                                    <a href="<?= site_url('page/contact'); ?>" target="_blank" class="btn btn-outline-danger btn-xs">Kontak</a>
                                    <a href="<?= site_url('page/privacy_policy'); ?>" target="_blank" class="btn btn-outline-danger btn-xs">Privacy Policy</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
        
        <!-- JAVASCRIPT -->
        <script src="<?= base_url('assets/js/app.js'); ?>"></script>
    </body>
</html>