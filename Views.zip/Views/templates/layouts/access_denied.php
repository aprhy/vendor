<!DOCTYPE html>
<html lang="zxx">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?= $title; ?></title>
        
        <!-- CSS -->
        <link rel="stylesheet" href="<?= base_url('assets/css/app.css'); ?>">
        <style>
            .loader {
                position: fixed;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: #F5F8FA;
                z-index: 9998;
                text-align: center;
            }

            .plane-container {
                position: absolute;
                top: 50%;
                left: 50%;
            }
        </style>
        
    </head>
    <body class="light">
        <!-- Pre loader -->
        <div id="loader" class="loader">
            <div class="plane-container">
                <div class="preloader-wrapper big active">
                    <div class="spinner-layer spinner-blue">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div><div class="gap-patch">
                        <div class="circle"></div>
                    </div><div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="app">
            <div class="height-full light">
                <div id="primary" class="content-area"
                    data-bg-possition="center"
                    data-bg-repeat="false"
                    style="background: url('<?= base_url('assets/img/icon/icon-circles.png'); ?>');">
                    <div class="container">
                        <div class="col-xl-8 mx-lg-auto p-t-b-80">
                            <header class="text-center mb-5">
                                <h1>Access Denied!</h1>
                                <p class="section-subtitle">Anda tidak memiliki hak akses pada menu atau fitur ini</p>
                                <a href="<?= site_url('admin/dashboard/'); ?>" class="btn btn-outline-primary"><i class="icon icon-arrow_back"></i> Kembali ke Beranda</a>
                            </header>
                            <div class="pt-5 p-t-100 text-center">
                                <p class="s-256">403</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="<?= base_url('assets/js/app.js'); ?>"></script>
    </body>
</html>