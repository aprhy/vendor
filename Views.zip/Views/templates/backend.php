<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?= base_url("upload/setting/" . $setting['logo']); ?>" type="image/x-icon">
    <title><?= $setting['appname_short'] . " :: " . $title; ?></title>

    <!-- CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/css/app.css'); ?>">
    <style>
        .loader {
            position: fixed;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: #F5F8FA;
            z-index: 9998;
            text-align: center;
        }

        .plane-container {
            position: absolute;
            top: 50%;
            left: 50%;
        }
    </style>
    <!-- Js -->
    <!--
            --- Head Part - Use Jquery anywhere at page.
            --- http://writing.colin-gourlay.com/safely-using-ready-before-including-jquery/
            -->
    <script>
        (function(w, d, u) {
            w.readyQ = [];
            w.bindReadyQ = [];

            function p(x, y) {
                if (x == "ready") {
                    w.bindReadyQ.push(y);
                } else {
                    w.readyQ.push(x);
                }
            };
            var a = {
                ready: p,
                bind: p
            };
            w.$ = w.jQuery = function(f) {
                if (f === d || f === u) {
                    return a
                } else {
                    p(f)
                }
            }
        })(window, document)
    </script>
</head>

<body class="light">
    <!-- Pre loader -->
    <div id="loader" class="loader">
        <div class="plane-container">
            <div class="preloader-wrapper big active">
                <div class="spinner-layer spinner-blue">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div><div class="gap-patch">
                    <div class="circle"></div>
                </div><div class="circle-clipper right">
                    <div class="circle"></div>
                </div>
                </div>

                <div class="spinner-layer spinner-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div><div class="gap-patch">
                    <div class="circle"></div>
                </div><div class="circle-clipper right">
                    <div class="circle"></div>
                </div>
                </div>

                <div class="spinner-layer spinner-yellow">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div><div class="gap-patch">
                    <div class="circle"></div>
                </div><div class="circle-clipper right">
                    <div class="circle"></div>
                </div>
                </div>

                <div class="spinner-layer spinner-green">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div><div class="gap-patch">
                    <div class="circle"></div>
                </div><div class="circle-clipper right">
                    <div class="circle"></div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <div id="app">
        <aside class="main-sidebar fixed offcanvas shadow" data-toggle='offcanvas'>
            <section class="sidebar">
                <div class="w-200px mt-3 mb-3 ml-3">
                    <img src="<?= base_url('upload/setting/' . $setting['logo']); ?>" alt="" height="25px"> <b><?= $setting['appname_short']; ?></b>
                </div>
                <div class="relative">
                    <a data-toggle="collapse" href="#userSettingsCollapse" role="button" aria-expanded="false" aria-controls="userSettingsCollapse" class="btn-fab btn-fab-sm absolute fab-right-bottom fab-top btn-primary shadow1 ">
                        <i class="icon icon-cogs"></i>
                    </a>
                    <div class="user-panel p-3 light mb-2">
                        <div>
                            <div class="float-left image">
                                <img class="user_avatar" src="<?= base_url('upload/profile/' . ((session('user_photo')) ? session('user_photo') : 'noimage.jpeg')); ?>" alt="User Image">
                            </div>
                            <div class="float-left info">
                                <h6 class="font-weight-light mt-2 mb-1"><?= session('user_fullname'); ?></h6>
                                <a href="#"><i class="icon-circle text-primary blink"></i> Online</a>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="collapse multi-collapse" id="userSettingsCollapse">
                            <div class="list-group mt-3 shadow">
                                <a href="<?= site_url('admin/profile/index/' . session('user_name')); ?>" class="list-group-item list-group-item-action ">
                                    <i class="mr-2 icon-image text-blue"></i>Profil Saya
                                </a>

                                <?php if (session('user_role') == 1) { ?>
                                    <a href="<?= site_url('admin/setting/'); ?>" class="list-group-item list-group-item-action">
                                        <i class="mr-2 icon-gear text-yellow"></i>Setting
                                    </a>
                                    <a href="<?= site_url('admin/log/'); ?>" class="list-group-item list-group-item-action">
                                        <i class="mr-2 icon-list2 text-red"></i>Log Sistem
                                    </a>
                                <?php } ?>

                            </div>
                        </div>
                    </div>
                </div>
                <ul class="sidebar-menu">
                    <li class="header"><strong>MAIN NAVIGATION</strong></li>
                    <li class="treeview">
                        <a href="<?= site_url('admin/dashboard/'); ?>">
                            <i class="icon icon-dashboard2 text-blue s-18"></i> <span>Dashboard</span>
                        </a>
                    </li>

                    <li class="header light mt-3"><strong>PERSURATAN</strong> </li>

                    <?php if (session('user_role') == 3) { ?>
                        <li class="treeview">
                            <a href="<?= site_url('admin/mail/index'); ?>">
                                <i class="icon icon-plus text-green s-18"></i> <span>Buat Surat</span>
                            </a>
                        </li>
                    <?php } ?>

                    <li class="treeview ">
                        <a href="#">
                            <i class="icon icon-mail-envelope-open2 text-lime s-18"></i> <span>Data Surat</span>
                            <i class="icon icon-angle-left s-18 pull-right"></i>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="<?= site_url('admin/inbox/index/in/validasi'); ?>"><i class="icon icon-circle-o"></i>Surat Masuk</a></li>
                            <li><a href="<?= site_url('admin/outbox/index/out/draft'); ?>"><i class="icon icon-circle-o"></i>Surat Keluar</a></li>
                        </ul>
                    </li>

                    <?php if (session('user_role') != 1) { ?>
                        <li class="treeview ">
                            <a href="#">
                                <i class="icon icon-check-square-o text-lime s-18"></i> <span>Disposisi Surat</span>
                                <i class="icon icon-angle-left s-18 pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="<?= site_url('admin/disposition/index/in/proses'); ?>"><i class="icon icon-circle-o"></i>Surat Masuk</a></li>
                                <li><a href="<?= site_url('admin/disposition/index/out/proses'); ?>"><i class="icon icon-circle-o"></i>Surat Keluar</a></li>
                            </ul>
                        </li>
                    <?php } ?>

                    <?php if (session('user_role') != 2) { ?>
                        <li class="treeview">
                            <a href="<?= site_url('admin/report/'); ?>">
                                <i class="icon icon-document-diagrams2 text-lime s-18"></i> <span>Report</span>
                            </a>
                        </li>
                    <?php } ?>

                    <?php if (session('user_role') == 3) { ?>
                        <li class="header light"><strong>ADMIN PANEL</strong></li>
                        <li class="treeview ">
                            <a href="#">
                                <i class="icon icon-verified_user text-red s-18"></i> <span>Manajemen Data Pegawai</span>
                                <i class="icon icon-angle-left s-18 pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="<?= site_url('admin/user/'); ?>"><i class="icon icon-circle-o"></i>Users</a></li>
                            </ul>
                        </li>
                    <?php } ?>

                    <?php if (session('user_role') == 1) { ?>
                        <li class="header light"><strong>ADMIN PANEL</strong></li>
                        <li class="treeview ">
                            <a href="#">
                                <i class="icon icon-view_list text-lime s-18"></i> <span>Core Data</span>
                                <i class="icon icon-angle-left s-18 pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="<?= site_url('admin/skpd/'); ?>"><i class="icon icon-circle-o"></i>SKPD</a></li>
                                <li><a href="<?= site_url('admin/positionclass/'); ?>"><i class="icon icon-circle-o"></i>Kelas Jabatan</a></li>
                                <li><a href="<?= site_url('admin/draft/'); ?>"><i class="icon icon-circle-o"></i>Klasifikasi Surat</a></li>
                            </ul>
                        </li>
                        <li class="treeview ">
                            <a href="#">
                                <i class="icon icon-verified_user text-red s-18"></i> <span>Previllege Data</span>
                                <i class="icon icon-angle-left s-18 pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="<?= site_url('admin/role/'); ?>"><i class="icon icon-circle-o"></i>Role</a></li>
                                <li><a href="<?= site_url('admin/user/'); ?>"><i class="icon icon-circle-o"></i>Users</a></li>
                            </ul>
                        </li>
                        <li class="treeview ">
                            <a href="<?= site_url('admin/dbutility/'); ?>">
                                <i class="icon icon-settings_backup_restore text-red s-18"></i> <span>Backup & Restore <span class="badge badge-pill badge-danger">Soon</span></span>
                            </a>
                        </li>
                    <?php } ?>
                </ul>
            </section>
        </aside>

        <div class="page has-sidebar-left">
            <div class="navbar navbar-expand d-flex navbar-dark justify-content-between bd-navbar blue accent-3 shadow">
                <div class="relative">
                    <div class="d-flex">
                        <div>
                            <a href="#" data-toggle="push-menu" class="paper-nav-toggle pp-nav-toggle">
                                <i></i>
                            </a>
                        </div>

                    </div>
                </div>

                <!--Top Menu Start -->
                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">

                        <?php if (session('user_role') == 3) : ?>
                            <!-- Staff -->
                            <li class="dropdown custom-dropdown notifications-menu">
                                <a href="#" class=" nav-link" data-toggle="dropdown" aria-expanded="false" title="Surat Masuk">
                                    <i class="icon-mail-envelope-closed2 "></i>
                                    <span class="badge badge-success badge-mini" id="inboxNotif">0</span>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    <li class="header">Surat Masuk SKPD Anda</li>
                                    <li>
                                        <!-- inner menu: contains the actual data -->
                                        <ul class="menu">
                                            <li>
                                                <a href="<?= site_url('admin/inbox/index/in/validasi'); ?>">
                                                    <i class="icon icon-data_usage text-success"></i> <b id="inboxDetail">0</b> Surat Masuk
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li class="dropdown custom-dropdown notifications-menu">
                                <a href="#" class=" nav-link" data-toggle="dropdown" aria-expanded="false" title="Perbaikan">
                                    <i class="icon-mail-error2 "></i>
                                    <span class="badge badge-warning darken badge-mini" id="dispositionRepair">0</span>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    <li class="header">Perbaikan Surat Anda</li>
                                    <li>
                                        <!-- inner menu: contains the actual data -->
                                        <ul class="menu">
                                            <li>
                                                <a href="<?= site_url('admin/disposition/index/out/perbaikan'); ?>">
                                                    <i class="icon icon-data_usage text-warning"></i> <b id="dispositionOutRepair">0</b> Perbaikan Surat Keluar SKPD
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?= site_url('admin/disposition/index/out_nonskpd/perbaikan'); ?>">
                                                    <i class="icon icon-data_usage text-warning"></i> <b id="dispositionOutNonRepair">0</b> Perbaikan Surat Keluar Non-SKPD
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>

                        <?php if (session('user_role') != 1) : ?>
                            <!-- Notifications -->
                            <li class="dropdown custom-dropdown notifications-menu">
                                <a href="#" class=" nav-link" data-toggle="dropdown" aria-expanded="false" title="Disposisi">
                                    <i class="icon-notifications "></i>
                                    <span class="badge badge-danger badge-mini" id="dispositionNotif">0</span>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    <li class="header">Disposisi Surat Anda</li>
                                    <li>
                                        <!-- inner menu: contains the actual data -->
                                        <ul class="menu">
                                            <li>
                                                <a href="<?= site_url('admin/disposition/index/out/proses'); ?>">
                                                    <i class="icon icon-data_usage text-danger"></i> <b id="dispositionOut">0</b> Disposisi Surat Keluar SKPD
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?= site_url('admin/disposition/index/out_nonskpd/proses'); ?>">
                                                    <i class="icon icon-data_usage text-danger"></i> <b id="dispositionOutNon">0</b> Disposisi Surat Keluar Non-SKPD
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?= site_url('admin/disposition/index/in/proses'); ?>">
                                                    <i class="icon icon-data_usage text-danger"></i> <b id="dispositionIn">0</b> Disposisi Surat Masuk SKPD
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?= site_url('admin/disposition/index/in_nonskpd/proses'); ?>">
                                                    <i class="icon icon-data_usage text-danger"></i> <b id="dispositionInNon">0</b> Disposisi Surat Masuk Non-SKPD
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>



                        <!-- Right Sidebar Toggle Button -->
                        <li>
                            <a href="<?= site_url('auth/logout'); ?>" class="nav-link ml-2" title="Logout">
                                <i class="icon-power-off "></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="content-wrapper animatedParent animateOnce">
                <div class="animated fadeInUpShort">
                    <div class="container">
                        <?= $this->renderSection('content'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/#app -->
    <script src="<?= base_url('assets/js/app.js'); ?>"></script>
    <script src="<?= base_url('assets/plugin/ckeditor/ckeditor.js'); ?>"></script>
    <script src="<?= base_url('assets/plugin/ckfinder/ckfinder.js'); ?>"></script>

    <script type="text/javascript">
        $(document).ready(function() {

            $("#skpdselectajax").change(function() {
                var skpd = $("#skpdselectajax").val();
                $.ajax({
                    type: "POST",
                    url: "<?= site_url('ajax/getPositionDataBySkpd'); ?>",
                    data: {
                        skpd: skpd
                    },
                    success: function(msg) {
                        $("#positionselectajax").html(msg);
                    }
                });
            });


            function getDispositionNotif(userID) {
                url = "<?= site_url('ajax/getDispositionNotif/') ?>" + userID;
                $.get(url, function(data, status) {
                    data = JSON.parse(data);
                    // console.log(data['total']);
                    $("#dispositionNotif").html(data['total']);
                    $("#dispositionOut").html(data['out']);
                    $("#dispositionIn").html(data['in']);
                    $("#dispositionOutNon").html(data['out_nonskpd']);
                    $("#dispositionInNon").html(data['in_nonskpd']);
                    setTimeout(function() {
                        getDispositionNotif("<?= session('user_id'); ?>");
                    }, 10000);
                });
            }

            function getDispositionRepair(userID) {
                url = "<?= site_url('ajax/getDispositionRepair/') ?>" + userID;
                $.get(url, function(data, status) {
                    data = JSON.parse(data);
                    // console.log(data['total']);
                    $("#dispositionRepair").html(data['total']);
                    $("#dispositionOutRepair").html(data['out']);
                    $("#dispositionOutNonRepair").html(data['out_nonskpd']);
                    setTimeout(function() {
                        getDispositionRepair("<?= session('user_id'); ?>");
                    }, 10000);
                });
            }

            function getInboxNotif(skpdID) {
                url = "<?= site_url('ajax/getInboxNotif/') ?>" + skpdID;
                $.get(url, function(data, status) {
                    data = JSON.parse(data);

                    $('#inboxNotif').html(data);
                    $('#inboxDetail').html(data);
                    setTimeout(function() {
                        getInboxNotif("<?= session('user_skpd'); ?>");
                    }, 10000);
                });
            }


            getDispositionNotif("<?= session('user_id'); ?>");
            getDispositionRepair("<?= session('user_id'); ?>");
            getInboxNotif("<?= session('user_skpd'); ?>")
        });
    </script>
    <!--
            --- Footer Part - Use Jquery anywhere at page.
            --- http://writing.colin-gourlay.com/safely-using-ready-before-including-jquery/
            -->
    <script>
        (function($, d) {
            $.each(readyQ, function(i, f) {
                $(f)
            });
            $.each(bindReadyQ, function(i, f) {
                $(d).bind("ready", f)
            })
        })(jQuery, document)
    </script>
</body>

</html>