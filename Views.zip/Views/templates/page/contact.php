
<!DOCTYPE html>
<html lang="zxx">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="<?= base_url("upload/setting/".$setting['logo']); ?>" type="image/x-icon">
        <title><?= $setting['appname_short']." :: ".$title; ?></title>
        
        <!-- CSS -->
        <link rel="stylesheet" href="<?= base_url('assets/css/app.css'); ?>">
        <style>
            .loader {
                position: fixed;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: #F5F8FA;
                z-index: 9998;
                text-align: center;
            }

            .plane-container {
                position: absolute;
                top: 50%;
                left: 50%;
            }

            hr {
                background-color: #1240b1;
            }
        </style>
        
    </head>
    <body class="light">

        <!-- PRE-LOADER -->
        <div id="loader" class="loader">
            <div class="plane-container">
                <div class="preloader-wrapper big active">
                    <div class="spinner-layer spinner-blue">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div><div class="gap-patch">
                        <div class="circle"></div>
                    </div><div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                    </div>

                    <div class="spinner-layer spinner-red">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div><div class="gap-patch">
                        <div class="circle"></div>
                    </div><div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                    </div>

                    <div class="spinner-layer spinner-yellow">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div><div class="gap-patch">
                        <div class="circle"></div>
                    </div><div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                    </div>

                    <div class="spinner-layer spinner-green">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div><div class="gap-patch">
                        <div class="circle"></div>
                    </div><div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- APPS -->
        <div id="app">
            <main>
                <div id="primary" class="blue4 p-t-b-100 height-full responsive-phone">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card border-info">
                                    <div class="card-header">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <?= $title; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <table class="table table-bordered table-checkable">
                                            <thead>
                                                <tr>
                                                    <th style="width:20%">Owner</th>
                                                    <th><code><?= $setting['owner']; ?></code></th>
                                                </tr>
                                                <tr>
                                                    <th style="width:20%">Phone</th>
                                                    <th><code><?= $setting['phone']; ?></code></th>
                                                </tr>
                                                <tr>
                                                    <th style="width:20%">Email</th>
                                                    <th><code><?= $setting['email']; ?></code></th>
                                                </tr>
                                            </thead>
                                        </table>  
                                        
                                    </div>
                                    <div class="card-footer">Page Rendered : {elapsed_time} second</div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </main>
        </div>
        
        <!-- JAVASCRIPT -->
        <script src="<?= base_url('assets/js/app.js'); ?>"></script>
    </body>
</html>