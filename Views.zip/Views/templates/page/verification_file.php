
<!DOCTYPE html>
<html lang="zxx">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="<?= base_url("upload/setting/".$setting['logo']); ?>" type="image/x-icon">
        <title><?= $setting['appname_short']." :: ".$title; ?></title>
        
        <!-- CSS -->
        <link rel="stylesheet" href="<?= base_url('assets/css/app.css'); ?>">
        <style>
            .loader {
                position: fixed;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: #F5F8FA;
                z-index: 9998;
                text-align: center;
            }

            .plane-container {
                position: absolute;
                top: 50%;
                left: 50%;
            }

            hr {
                background-color: #1240b1;
            }
        </style>
        
    </head>
    <body class="light">

        <!-- PRE-LOADER -->
        <div id="loader" class="loader">
            <div class="plane-container">
                <div class="preloader-wrapper big active">
                    <div class="spinner-layer spinner-blue">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div><div class="gap-patch">
                        <div class="circle"></div>
                    </div><div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                    </div>

                    <div class="spinner-layer spinner-red">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div><div class="gap-patch">
                        <div class="circle"></div>
                    </div><div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                    </div>

                    <div class="spinner-layer spinner-yellow">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div><div class="gap-patch">
                        <div class="circle"></div>
                    </div><div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                    </div>

                    <div class="spinner-layer spinner-green">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div><div class="gap-patch">
                        <div class="circle"></div>
                    </div><div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- APPS -->
        <div id="app">
            <main>
                <div id="primary" class="blue4 p-t-b-100 height-full responsive-phone">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card border-info">
                                    <div class="card-header bg-success text-white">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <?= $title; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <?php if($data) : ?>
                                                <div class="col-md-8">
                                                    
                                                    <table class="table table-bordered table-checkable">
                                                        <thead>
                                                            <tr>
                                                                <th style="width:20%">Nomor Surat</th>
                                                                <th><b class="text-red"><?= $data[0]['number']; ?></b></th>
                                                            </tr>
                                                            <tr>
                                                                <th style="width:20%">Tanggal</th>
                                                                <th><b class="text-red"><?= indonesianDate($data[0]['date']); ?></b></th>
                                                            </tr>
                                                            <tr>
                                                                <th style="width:20%">Perihal</th>
                                                                <th><b class="text-red"><?= $data[0]['about']; ?></b></th>
                                                            </tr>
                                                            <tr>
                                                                <th style="width:20%">Pembuat Surat</th>
                                                                <th><?= $data[0]['name']; ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th style="width:20%">Penerima Surat</th>
                                                                <th>
                                                                    <?php foreach ($dataReceiver as $receiver) : ?>
                                                                    <?= $receiver['name'] ?>
                                                                    <?php endforeach ?>
                                                                </th>
                                                            </tr>

                                                        </thead>
                                                    </table>  
                                                </div>
                                                <div class="col-md-4">
                                                    
                        
                                                    <?php if ($tteStatus['summary'] == null) {?>
                                                        
                                                        <div class="card-body slimScroll" data-height="400" style="overflow: hidden; width: auto; height: 400px;">
                                                            
                                                            <div class="activity-item activity-danger">
                                                                <div class="activity-content">
                                                                    <small class="text-muted">
                                                                        <i class="icon icon-file position-left"></i> Status Dokumen
                                                                    </small>
                                                                    <p><b class="text-danger">Dokumen Tidak Valid / Tidak melalui proses TTE</b></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php }else { ?>

                                                        <div class="card-body slimScroll" data-height="400" style="overflow: hidden; width: auto; height: 400px;">
                                                            
                                                            <div class="activity-item activity-danger">
                                                                <div class="activity-content">
                                                                    <small class="text-muted">
                                                                        <i class="icon icon-file position-left"></i> Status Dokumen
                                                                    </small>
                                                                    <p>
                                                                        <b class="text-success"><?= $tteStatus['summary']; ?></b>
                                                                        <hr style="border: 0.5px dashed #d2d6de">
                                                                        <?= "<b>Ditandatangani Oleh : <br></b>". $tteStatus['details'][0]['info_signer']['signer_name']; ?>
                                                                        <hr style="border: 0.5px dashed #d2d6de">
                                                                        <?= "<b>Waktu TTE : <br></b>". $tteStatus['details'][0]['signature_document']['signed_in']; ?>
                                                                        <hr style="border: 0.5px dashed #d2d6de">
                                                                        <?= "<b>Penerbit : <br></b>". $tteStatus['details'][0]['info_signer']['issuer_dn']; ?>
                                                                        <hr style="border: 0.5px dashed #d2d6de">
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        
                                                        
                                                    <?php }?>
                                                    
                                                </div>
                                            <?php else :?>
                                                <div class="col-md-12">
                                                    <b class="text-danger">Mohon Maaf, Dokumen yang anda cari tidak ada atau tidak terdaftar pada sistem kami</b>
                                                </div>
                                            <?php endif?>
                                        </div>
                                        
                                    </div>
                                    <div class="card-footer">Page Rendered : {elapsed_time} second</div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </main>
        </div>
        
        <!-- JAVASCRIPT -->
        <script src="<?= base_url('assets/js/app.js'); ?>"></script>
    </body>
</html>