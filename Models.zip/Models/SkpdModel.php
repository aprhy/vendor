<?php

namespace App\Models;

use CodeIgniter\Model;

class SkpdModel extends Model
{
	protected $table         = 'tbl_skpd';
	protected $allowedFields = ['name','address','category'];
	protected $useTimestamps = true;

	public function fetchData($keyword = false)
	{
		$search = ($keyword) ? $keyword : '';
		return $this->select('id, name, address, category')->like('name', $search)->orderBy('id', 'ASC');
	}
}
