<?php

namespace App\Models;

use CodeIgniter\Model;

class MailreceiverModel extends Model
{
	protected $table         = 'tbl_mail_receiver';
	protected $allowedFields = ['skpd_id','mail_id','status'];
	protected $useTimestamps = true;

	public function fetchData($mail_id = false)
	{
		$this->select('tbl_mail_receiver.id,
						tbl_mail_receiver.skpd_id,
						tbl_mail_receiver.mail_id,
						tbl_mail_receiver.status,
						tbl_skpd.name,

					');
		$this->join('tbl_skpd', 'tbl_mail_receiver.skpd_id = tbl_skpd.id' , 'left');
		
		if ($mail_id != false) {
			$this->where('tbl_mail_receiver.mail_id', $mail_id);
		}

		return $this;
	}

	
}
