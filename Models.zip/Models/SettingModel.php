<?php

namespace App\Models;

use CodeIgniter\Model;

class SettingModel extends Model
{
	protected $table         = 'tbl_setting';
	protected $allowedFields = ['appname','appname_short','owner','origin','phone','email','logo'];
	protected $useTimestamps = true;
}
