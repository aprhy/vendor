<?php

namespace App\Models;

use Michalsn\Uuid\UuidModel;

class UserModel extends UuidModel
{
	protected $table         = 'tbl_user';
	protected $uuidUseBytes  = false;
	protected $allowedFields = ['username', 'password', 'email', 'fullname', 'photo', 'nip', 'unit', 'lastlogin', 'status', 'role_id', 'position_id'];
	protected $useTimestamps = true;

	public function fetchData($username = false, $keyword = false)
	{

		$this->select('tbl_user.id,
						tbl_user.username,
						tbl_user.fullname,
						tbl_user.photo,
						tbl_user.email,
						tbl_user.nip,
						tbl_user.unit,
						tbl_user.lastlogin,
						tbl_user.status,
						tbl_user.role_id,
						tbl_user.position_id,
						tbl_role.role,
						tbl_skpd.id as skpd_id,
						tbl_skpd.name as skpd_name,
						tbl_position.name as position_name
					');
		$this->join('tbl_role', 'tbl_user.role_id = tbl_role.id', 'left');
		$this->join('tbl_position', 'tbl_user.position_id = tbl_position.id', 'left');
		$this->join('tbl_skpd', 'tbl_position.skpd_id = tbl_skpd.id', 'left');

		if ($keyword != false) {
			$this->like('tbl_user.username', $keyword);
			$this->orLike('tbl_user.fullname', $keyword);
			$this->orLike('tbl_user.email', $keyword);
			$this->orLike('tbl_role.role', $keyword);
		}
		if ($username != false) {
			$this->where('tbl_user.username', $username);
		}
		$this->orderBy('tbl_user.created_at', 'DESC');

		return $this;
	}

	public function fetchDataSkpd($skpd = false)
	{

		$this->select('tbl_user.id,
						tbl_user.username,
						tbl_user.fullname,
						tbl_user.photo,
						tbl_user.email,
						tbl_user.nip,
						tbl_user.unit,
						tbl_user.lastlogin,
						tbl_user.status,
						tbl_user.role_id,
						tbl_user.position_id,
						tbl_role.role,
						tbl_skpd.id as skpd_id,
						tbl_skpd.name as skpd_name,
						tbl_position.name as position_name
					');
		$this->join('tbl_role', 'tbl_user.role_id = tbl_role.id', 'left');
		$this->join('tbl_position', 'tbl_user.position_id = tbl_position.id', 'left');
		$this->join('tbl_skpd', 'tbl_position.skpd_id = tbl_skpd.id', 'left');

		if ($skpd != false) {
			$this->where('tbl_skpd.id', $skpd);
		}
		$this->orderBy('tbl_user.created_at', 'DESC');

		return $this;
	}
}
