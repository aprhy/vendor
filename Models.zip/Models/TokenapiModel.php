<?php

namespace App\Models;

use CodeIgniter\Model;

class TokenapiModel extends Model
{
	protected $table         = 'tbl_api_client';
	protected $primaryKey 	 = 'client_id';
	protected $allowedFields = ['client_id', 'client_secret', 'access_token', 'validity_time'];
	protected $useTimestamps = true;
	// protected $allowedFields = ['lastlogin'];

	/* TOKEN SECTION */
	public function check_token($client_id, $client_secret)
	{
		$this->select('*');
		$this->where('client_id', $client_id);
		$this->where('client_secret', $client_secret);
		return $this;
	}

	public function check_token_validity($token)
	{
		$this->select('*');
		$this->where('access_token', $token);
		return $this;
	}
}
