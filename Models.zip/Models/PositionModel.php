<?php

namespace App\Models;

use CodeIgniter\Model;

class PositionModel extends Model
{
	protected $table         = 'tbl_position';
	protected $allowedFields = ['name','parent','leader','skpd_id','positionclass_id'];
	protected $useTimestamps = true;

	public function fetchData($skpd = false)
	{
		$this->select('id, name');
		$this->orderBy('id', 'ASC');
		($skpd) ? $this->where('skpd_id', $skpd) : '';
		
		return $this;
	}

	public function generateTree($skpd, $leader, $parent)
	{
		$this->select('id, name, leader, parent, positionclass_id, skpd_id');
		$this->where('skpd_id' , $skpd);
		$this->orderBy('id', 'ASC');
		($leader == 1) ? $this->where('leader', $leader) : $this->where('parent', $parent);

		return $this;
	}

	public function getTopPosition($position)
	{
		$this->select('
			tbl_position.parent,
			tbl_user.id
		');
		$this->join('tbl_user','tbl_user.position_id = tbl_position.parent','left');
		$this->where('tbl_position.id', $position);
		return $this;
	}

	public function getBottomPosition($position)
	{
		$this->select('
			tbl_user.id,
			tbl_user.fullname,
			tbl_user.nip,
			tbl_user.position_id,
			tbl_position.name,
		');
		$this->join('tbl_user', 'tbl_user.position_id = tbl_position.id', 'LEFT');
		$this->where('tbl_position.parent', $position);

		return $this;
	}

	public function getLeader($skpd)
	{
		$this->select('
			tbl_position.id as position_id,
			tbl_position.name as position_name,
			tbl_user.id,
			tbl_user.nip,
			tbl_user.fullname
		');
		$this->join('tbl_user','tbl_user.position_id = tbl_position.id','left');
		$this->where('tbl_position.leader', 1);
		$this->where('tbl_position.skpd_id', $skpd);
		return $this;
	}

	public function getStaff($skpd)
	{
		$this->select('
			tbl_position.id as position_id,
			tbl_user.id,
		');
		$this->join('tbl_user','tbl_user.position_id = tbl_position.id','left');
		$this->where('tbl_user.role_id', 3);
		$this->where('tbl_position.skpd_id', $skpd);
		return $this;
	}
}
