<?php

namespace App\Models;

use CodeIgniter\Model;

class LogModel extends Model
{
	protected $table         = 'tbl_log';
	protected $allowedFields = ['time','message','ipaddress','user_id'];
	protected $useTimestamps = true;

	public function fetchData($user = false, $keyword = false)
	{
		
		if ($user == false) {
			$this->select('tbl_log.message, 
								tbl_log.time, 
								tbl_log.ipaddress, 
								tbl_user.fullname');
			$this->join('tbl_user' ,'tbl_log.user_id = tbl_user.id', 'left');

			if ($keyword != false) {
				$this->like('message', $keyword);
			}

			$this->orderBy('tbl_log.time','DESC');

			return $this;
		}

		return $this->where(['user_id' => $user])->limit(5)->orderBy('time','DESC');
	}
}
