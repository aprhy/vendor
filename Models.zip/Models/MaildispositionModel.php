<?php

namespace App\Models;

use CodeIgniter\Model;

class MaildispositionModel extends Model
{
    protected $table         = 'tbl_mail_disposition';
    protected $allowedFields = ['from_user', 'from_position', 'to_user', 'to_position', 'message', 'category', 'status', 'mail_id'];
    protected $useTimestamps = true;

    public function fetchData($mail_id = false, $category = false, $status = false,  $user_id = false, $keyword = false)
    {
        $this->select('tbl_mail_disposition.id,
						tbl_mail_disposition.status,
						tbl_mail_disposition.mail_id,
						tbl_mail_disposition.message,
						tbl_mail_disposition.created_at,
						tbl_mail_disposition.updated_at,
						tbl_mail.id as mail_id,
						tbl_mail.number,
						tbl_mail.agenda,
						tbl_mail.date,
						tbl_mail.status as mail_status,
						tbl_mail.sign,
						tbl_mail.about,
						tbl_mail.summary,
						tbl_mail.file,
						tbl_mail.category,
						tbl_mail.destination_nonskpd,
						tbl_draft.id as draft_id,
						tbl_draft.name,
						user_from.fullname as sender,
						user_to.fullname as receiver,
						position_from.name as position_sender,
						position_to.name as position_receiver,
						position_from.skpd_id
					');
        $this->join('tbl_mail', 'tbl_mail_disposition.mail_id = tbl_mail.id', 'left');
        $this->join('tbl_draft', 'tbl_mail.draft_id = tbl_draft.id', 'left');
        $this->join('tbl_user user_from', 'tbl_mail_disposition.from_user = user_from.id', 'left');
        $this->join('tbl_user user_to', 'tbl_mail_disposition.to_user = user_to.id', 'left');
        $this->join('tbl_position position_from', 'tbl_mail_disposition.from_position = position_from.id', 'left');
        $this->join('tbl_position position_to', 'tbl_mail_disposition.to_position = position_to.id', 'left');


        if ($mail_id != false) {
            $this->where('tbl_mail.id', $mail_id);
        }

        if ($status != false) {
            $this->where('tbl_mail_disposition.status', $status);
        }

        if ($user_id != false) {
            $this->where('user_to.id', $user_id);
        }

        if ($category != false) {
            $this->where('tbl_mail_disposition.category', $category);
        }

        if ($keyword != false) {
            $like = "(tbl_mail.number LIKE '%$keyword%'
						OR  tbl_mail.agenda LIKE '%$keyword%' 
						OR  tbl_mail.about LIKE '%$keyword%')";

            $this->where($like);
        }

        $this->orderBy('tbl_mail.date', 'DESC');

        return $this;
    }


    public function countFinishState($mail_id, $status)
    {
        return $this->select('id')
            ->where('mail_id', $mail_id)
            ->where('status != ', $status);
    }

    // Api
    public function api_fetchData($mail_id = false, $category = false, $status = false,  $user_id = false, $keyword = false, $datee = '0000-00-00')
    {
        $m = explode("-", $datee);
        $year =  $m[0];
        $monthh =  $m[1];
        $date =  $m[2];
        $this->select('tbl_mail_disposition.id,
						tbl_mail_disposition.status,
						tbl_mail_disposition.mail_id,
						tbl_mail_disposition.message,
						tbl_mail_disposition.created_at,
						tbl_mail_disposition.updated_at,
						tbl_mail.id as mail_id,
						tbl_mail.number,
						tbl_mail.agenda,
						tbl_mail.date,
						tbl_mail.status as mail_status,
						tbl_mail.sign,
						tbl_mail.about,
						tbl_mail.summary,
						tbl_mail.file,
						tbl_mail.category,
						tbl_mail.destination_nonskpd,
						tbl_draft.id as draft_id,
						tbl_draft.name,
						user_from.fullname as sender,
						user_to.fullname as receiver,
						position_from.name as position_sender,
						position_to.name as position_receiver,
						position_from.skpd_id,
                        tbl_mail_receiver.skpd_id as skpd_tujuan,
                        skpd_from.name as skpd_asal_nama,
                        skpd_to.name as skpd_tujuan_nama,
						
					');

        $this->join('tbl_mail', 'tbl_mail_disposition.mail_id = tbl_mail.id', 'left');
        $this->join('tbl_mail_receiver', 'tbl_mail_disposition.mail_id = tbl_mail_receiver.mail_id', 'left');
        $this->join('tbl_draft', 'tbl_mail.draft_id = tbl_draft.id', 'left');
        $this->join('tbl_user user_from', 'tbl_mail_disposition.from_user = user_from.id', 'left');
        $this->join('tbl_user user_to', 'tbl_mail_disposition.to_user = user_to.id', 'left');
        $this->join('tbl_position position_from', 'tbl_mail_disposition.from_position = position_from.id', 'left');
        $this->join('tbl_position position_to', 'tbl_mail_disposition.to_position = position_to.id', 'left');
        $this->join('tbl_skpd skpd_from', 'skpd_from.id = tbl_mail.skpd_id', 'left');
        $this->join('tbl_skpd skpd_to', 'skpd_to.id = tbl_mail_receiver.skpd_id', 'left');


        if ($mail_id != false) {
            $this->where('tbl_mail.id', $mail_id);
        }

        if ($status != false) {
            $this->where('tbl_mail_disposition.status', $status);
        }

        if ($user_id != false) {
            $this->where('user_to.id', $user_id);
        }

        if ($category != false) {
            $this->where('tbl_mail_disposition.category', $category);
        }

        if ($datee != '0000-00-00') {
            $this->where('DAY(tbl_mail_disposition.created_at)', $date);
            $this->where('MONTH(tbl_mail_disposition.created_at)', $monthh);
            $this->where('YEAR(tbl_mail_disposition.created_at)', $year);
        }

        if ($keyword != false) {
            $like = "(tbl_mail.number LIKE '%$keyword%'
						OR  tbl_mail.agenda LIKE '%$keyword%' 
						OR  tbl_mail.about LIKE '%$keyword%')";

            $this->where($like);
        }

        $this->orderBy('tbl_mail.date', 'DESC');
        if ($datee == '0000-00-00') {
            $this->groupBy('tbl_mail_disposition.mail_id');
        }

        return $this;
    }
}
