<?php

namespace App\Models;

use CodeIgniter\Model;

class WidgetModel extends Model
{
	public function basicWidget()
	{
		$query = $this->db->query("SELECT
				(SELECT count(id) FROM tbl_user WHERE status = 1) as userTotal,
				(SELECT count(id) FROM tbl_skpd) as skpdTotal,
				(SELECT count(id) FROM tbl_draft) as draftTotal,
				(SELECT count(id) FROM tbl_positionclass) as positionclassTotal
			");
		
		return $query->getResultArray();
	}

	public function mailWidget($skpd)
	{
		$currentSkpd = ($skpd == '') ? '': "AND skpd_id ='$skpd'";

		$query = $this->db->query("SELECT
			(SELECT count(id) FROM tbl_mail WHERE category ='out' $currentSkpd ) as outboxSkpdTotal,
			(SELECT count(id) FROM tbl_mail WHERE (category ='out' OR category ='out_nonskpd') AND status !='selesai'  $currentSkpd ) as outboxSkpdProcess,
			(SELECT count(id) FROM tbl_mail WHERE (category ='out' OR category ='out_nonskpd') AND status ='selesai' $currentSkpd ) as outboxSkpdFinish,

			(SELECT count(id) FROM tbl_mail WHERE category ='out_nonskpd' $currentSkpd ) as outboxNonSkpdTotal,

			(SELECT count(id) FROM tbl_mail_receiver WHERE status !='x' $currentSkpd ) as inboxSkpdTotal,
			(SELECT count(id) FROM tbl_mail_receiver WHERE status !='selesai'  $currentSkpd ) as inboxSkpdProcess,
			(SELECT count(id) FROM tbl_mail_receiver WHERE status ='selesai' $currentSkpd ) as inboxSkpdFinish,

			(SELECT count(id) FROM tbl_mail WHERE category ='in_nonskpd' $currentSkpd ) as inboxNonSkpdTotal,
			(SELECT count(id) FROM tbl_mail WHERE category ='in_nonskpd' AND status !='selesai'  $currentSkpd ) as inboxNonSkpdProcess,
			(SELECT count(id) FROM tbl_mail WHERE category ='in_nonskpd' AND status ='selesai' $currentSkpd ) as inboxNonSkpdFinish
			
		");

		return $query->getResultArray();
	}

	public function dispositionWidget($userID)
	{
		$currentID = ($userID == 'a5768fc1-6e26-4114-a8f2-b32070c2cb1d') ? '':"AND to_user='$userID'";
		
		$query = $this->db->query("SELECT
			(SELECT count(id) FROM tbl_mail_disposition WHERE category ='out' $currentID) as outDisSkpd,
			(SELECT count(id) FROM tbl_mail_disposition WHERE category ='out_nonskpd' $currentID) as outDisNonSkpd,
			(SELECT count(id) FROM tbl_mail_disposition WHERE category ='in' $currentID) as inDisSkpd,
			(SELECT count(id) FROM tbl_mail_disposition WHERE category ='in_nonskpd' $currentID) as inDisNonSkpd,
			
			
			(SELECT count(id) FROM tbl_mail_disposition WHERE (category ='out' OR category ='out_nonskpd') AND (status ='proses' OR status ='perbaikan') $currentID) as outDisProcess,
			(SELECT count(id) FROM tbl_mail_disposition WHERE (category ='out' OR category ='out_nonskpd') AND status='selesai' $currentID) as outDisFinish,
			(SELECT count(id) FROM tbl_mail_disposition WHERE (category ='in' OR category ='in_nonskpd') AND (status ='proses' OR status ='perbaikan') $currentID) as inDisProcess,
			(SELECT count(id) FROM tbl_mail_disposition WHERE (category ='in' OR category ='in_nonskpd') AND status='selesai' $currentID) as inDisFinish
		");

		return $query->getResultArray();
	}

	public function trafficGraph($dateFormat)
	{
		$query = $this->db->query("SELECT count(id) as total FROM tbl_log WHERE time LIKE '$dateFormat%'");
		
		return $query->getResultArray();
	}

	public function mailGraph($dateFormat, $skpd)
	{
		$currentSkpd = ($skpd == '') ? '': "AND skpd_id ='$skpd'";

		$query = $this->db->query("SELECT 
			((SELECT count(id) FROM tbl_mail WHERE category ='out' $currentSkpd AND created_at LIKE '$dateFormat%') + (SELECT count(id) FROM tbl_mail WHERE category ='out_nonskpd' $currentSkpd AND created_at LIKE '$dateFormat%')) as outboxTotal,
			((SELECT count(id) FROM tbl_mail_receiver WHERE status !='x' $currentSkpd AND created_at LIKE '$dateFormat%') + (SELECT count(id) FROM tbl_mail WHERE category ='in_nonskpd' $currentSkpd AND created_at LIKE '$dateFormat%')) as inboxTotal
		");
		
		return $query->getResultArray();
	}
}
