<?php

namespace App\Models;

use CodeIgniter\Model;

class AuthModel extends Model
{
	protected $table         = 'tbl_user';
	protected $allowedFields = ['lastlogin'];
	protected $useTimestamps = true;

	public function getAuth($username)
	{
		$this->select('tbl_user.id,
						tbl_user.username,
						tbl_user.fullname,
						tbl_user.photo,
						tbl_user.password,
						tbl_user.email,
						tbl_user.nip,
						tbl_user.unit,
						tbl_user.status,
						tbl_user.lastlogin,
						tbl_user.role_id,
						tbl_user.position_id,
						tbl_role.role,
						tbl_skpd.id as skpd_id,
						tbl_skpd.name as skpd_name,
						tbl_position.name as position_name,
						tbl_position.leader,
						tbl_position.parent,
					');
		$this->join('tbl_role', 'tbl_user.role_id = tbl_role.id', 'left');
		$this->join('tbl_position', 'tbl_user.position_id = tbl_position.id', 'left');
		$this->join('tbl_skpd', 'tbl_position.skpd_id = tbl_skpd.id', 'left');

		$this->where('tbl_user.username', $username);
		$this->where('tbl_user.status', 1);
		$this->orderBy('tbl_user.created_at', 'DESC');

		return $this;
	}
}
