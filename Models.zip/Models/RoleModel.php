<?php

namespace App\Models;

use CodeIgniter\Model;

class RoleModel extends Model
{
	protected $table         = 'tbl_role';
	protected $allowedFields = ['role'];
	protected $useTimestamps = true;

	public function fetchData($keyword = false)
	{
		$search = ($keyword) ? $keyword : '';
		return $this->select('id, role')->like('role', $search)->orderBy('id', 'ASC');
	}
}
