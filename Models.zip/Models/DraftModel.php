<?php

namespace App\Models;

use CodeIgniter\Model;

class DraftModel extends Model
{
	protected $table         = 'tbl_draft';
	protected $allowedFields = ['name','draft'];
	protected $useTimestamps = true;

	public function fetchData($keyword = false)
	{
		$search = ($keyword) ? $keyword : '';
		return $this->select('id, name')->like('name', $search)->orderBy('id', 'ASC');
	}
}
