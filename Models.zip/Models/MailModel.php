<?php

namespace App\Models;

use Michalsn\Uuid\UuidModel;

class MailModel extends UuidModel
{
	protected $table         = 'tbl_mail';
	protected $uuidUseBytes  = false;
	protected $allowedFields = ['number', 'agenda', 'date', 'about', 'summary', 'template', 'file', 'category', 'status', 'sign', 'destination_nonskpd', 'draft_id', 'skpd_id'];
	protected $useTimestamps = true;

	public function fetchData($category, $status = false, $skpd = 0,  $keyword = false, $mail_id = false)
	{
		$this->select('tbl_mail.id,
						tbl_mail.number,
						tbl_mail.agenda,
						tbl_mail.date,
						tbl_mail.status,
						tbl_mail.sign,
						tbl_mail.about,
						tbl_mail.summary,
						tbl_mail.file,
						tbl_mail.destination_nonskpd,
						tbl_draft.name,
					');
		$this->join('tbl_skpd', 'tbl_mail.skpd_id = tbl_skpd.id', 'left');
		$this->join('tbl_draft', 'tbl_mail.draft_id = tbl_draft.id', 'left');

		if ($keyword != false) {
			$like = "(tbl_mail.number LIKE '%$keyword%'
						OR  tbl_mail.agenda LIKE '%$keyword%' 
						OR  tbl_mail.about LIKE '%$keyword%')";

			$this->where($like);
		}

		if ($skpd != 0) {
			$this->where('tbl_mail.skpd_id', $skpd);
		}

		if ($mail_id != false) {
			$this->where('tbl_mail.id', $mail_id);
		}

		if ($status != false) {
			$this->where('tbl_mail.status', $status);
		}

		$this->where('tbl_mail.category', $category);
		$this->orderBy('tbl_mail.date', 'DESC');
		return $this;
	}


	public function fetchDataInbox($status = false, $skpd = 0,  $keyword = false, $mail_id = false)
	{
		$this->select('tbl_mail_receiver.id,
						tbl_mail_receiver.mail_id,
						tbl_mail_receiver.status,
						tbl_mail.number,
						tbl_mail.agenda,
						tbl_mail.date,
						tbl_mail.status as mail_status,
						tbl_mail.sign,
						tbl_mail.about,
						tbl_mail.summary,
						tbl_mail.file,
						tbl_mail.destination_nonskpd,
						tbl_draft.name,
						skpd_sender.name as skpd_sender,
					');
		$this->join('tbl_mail_receiver', 'tbl_mail_receiver.mail_id = tbl_mail.id', 'left');
		$this->join('tbl_skpd', 'tbl_mail_receiver.skpd_id = tbl_skpd.id', 'left');
		$this->join('tbl_skpd skpd_sender', 'tbl_mail.skpd_id = skpd_sender.id', 'left');
		$this->join('tbl_draft', 'tbl_mail.draft_id = tbl_draft.id', 'left');

		if ($keyword != false) {
			$like = "(tbl_mail.number LIKE '%$keyword%'
						OR  tbl_mail.agenda LIKE '%$keyword%' 
						OR  tbl_mail.about LIKE '%$keyword%')";

			$this->where($like);
		}

		if ($skpd != 0) {
			$this->where('tbl_mail_receiver.skpd_id', $skpd);
		}

		if ($mail_id != false) {
			$this->where('tbl_mail.id', $mail_id);
		}

		if ($status != false) {
			$this->where('tbl_mail_receiver.status', $status);
		}

		$this->where('tbl_mail.status', 'selesai');
		$this->orderBy('tbl_mail.date', 'DESC');
		return $this;
	}

	// Api

	public function api_fetchDataInbox($mail_id = false, $kpd_id = false)
	{
		$this->select('tbl_mail_receiver.id,
						tbl_mail_receiver.mail_id,
						tbl_skpd.name as skpd_receiver,
						skpd_sender.name as skpd_sender,
					');
		$this->join('tbl_mail_receiver', 'tbl_mail_receiver.mail_id = tbl_mail.id', 'left');
		$this->join('tbl_skpd', 'tbl_mail_receiver.skpd_id = tbl_skpd.id', 'left');
		$this->join('tbl_skpd skpd_sender', 'tbl_mail.skpd_id = skpd_sender.id', 'left');

		if ($mail_id != false) {
			$this->where('tbl_mail.id', $mail_id);
		}

		if ($kpd_id != false) {
			$this->where('tbl_mail_receiver.skpd_id', $kpd_id);
		}

		// $this->where('tbl_mail.status', 'selesai');
		$this->orderBy('tbl_mail.date', 'DESC');
		// $this->groupBy('tbl_mail_receiver.id');
		return $this;
	}
}
